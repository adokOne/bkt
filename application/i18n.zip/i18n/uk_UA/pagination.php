<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => 'Група %s не визначена конфігурацією нумератора сторінок.',
	'page'     => 'сторінка',
	'pages'    => 'сторінки',
	'item'     => 'пункт',
	'items'    => 'пунктів',
	'of'       => 'з',
	'first'    => 'перша',
	'last'     => 'Ост',
	'previous' => 'Попер',
	'next'     => 'Наст',
);
