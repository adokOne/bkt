<?php defined('SYSPATH') or die('No direct script access.'); ?>

2013-08-29 13:25:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-29 13:25:48 +03:00 --- debug: Session Library initialized
2013-08-29 13:25:48 +03:00 --- debug: Auth Library loaded
2013-08-29 13:25:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-29 13:25:49 +03:00 --- debug: Database Library initialized
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: core.uncaught_exception
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-29 13:25:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-29 13:25:49 +03:00 --- debug: Session Library initialized
2013-08-29 13:25:49 +03:00 --- debug: Auth Library loaded
2013-08-29 13:25:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-29 13:25:49 +03:00 --- debug: Database Library initialized
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: core.uncaught_exception
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-29 13:25:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-29 13:26:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-29 13:26:18 +03:00 --- debug: Session Library initialized
2013-08-29 13:26:18 +03:00 --- debug: Auth Library loaded
2013-08-29 13:26:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-29 13:26:18 +03:00 --- debug: Database Library initialized
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry database.connection for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: core.uncaught_exception
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-29 13:26:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-29 13:26:18 +03:00 --- debug: Session Library initialized
2013-08-29 13:26:18 +03:00 --- debug: Auth Library loaded
2013-08-29 13:26:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-29 13:26:18 +03:00 --- debug: Database Library initialized
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry database.connection for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: core.uncaught_exception
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-29 13:26:18 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-29 13:27:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-29 13:27:47 +03:00 --- debug: Session Library initialized
2013-08-29 13:27:47 +03:00 --- debug: Auth Library loaded
2013-08-29 13:27:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-29 13:27:47 +03:00 --- debug: Database Library initialized
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry database.error for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: core.uncaught_exception
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-29 13:27:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-29 13:27:48 +03:00 --- debug: Session Library initialized
2013-08-29 13:27:48 +03:00 --- debug: Auth Library loaded
2013-08-29 13:27:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-29 13:27:48 +03:00 --- debug: Database Library initialized
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry database.error for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: core.uncaught_exception
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-29 13:27:48 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-29 13:28:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-29 13:28:48 +03:00 --- debug: Session Library initialized
2013-08-29 13:28:48 +03:00 --- debug: Auth Library loaded
2013-08-29 13:28:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-29 13:28:48 +03:00 --- debug: Database Library initialized
2013-08-29 13:28:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-29 13:28:56 +03:00 --- debug: Session Library initialized
2013-08-29 13:28:56 +03:00 --- debug: Auth Library loaded
2013-08-29 13:28:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-29 13:28:56 +03:00 --- debug: Database Library initialized
