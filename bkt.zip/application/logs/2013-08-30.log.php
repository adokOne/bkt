<?php defined('SYSPATH') or die('No direct script access.'); ?>

2013-08-30 10:52:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 10:52:04 +03:00 --- debug: Session Library initialized
2013-08-30 10:52:04 +03:00 --- debug: Auth Library loaded
2013-08-30 10:52:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 10:52:04 +03:00 --- debug: Database Library initialized
2013-08-30 10:53:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 10:53:45 +03:00 --- debug: Session Library initialized
2013-08-30 10:53:45 +03:00 --- debug: Auth Library loaded
2013-08-30 10:53:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 10:53:45 +03:00 --- debug: Database Library initialized
2013-08-30 10:54:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 10:54:07 +03:00 --- debug: Session Library initialized
2013-08-30 10:54:07 +03:00 --- debug: Auth Library loaded
2013-08-30 10:54:07 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-30 10:54:07 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 10:54:07 +03:00 --- error: core.uncaught_exception
2013-08-30 10:54:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 10:54:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 10:54:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 10:54:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 10:54:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 10:54:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 10:54:08 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 10:54:08 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 10:54:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 10:54:08 +03:00 --- debug: Session Library initialized
2013-08-30 10:54:08 +03:00 --- debug: Auth Library loaded
2013-08-30 10:54:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 10:54:08 +03:00 --- debug: Database Library initialized
2013-08-30 11:03:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:03:08 +03:00 --- debug: Session Library initialized
2013-08-30 11:03:08 +03:00 --- debug: Auth Library loaded
2013-08-30 11:03:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:03:08 +03:00 --- debug: Database Library initialized
2013-08-30 11:03:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:03:11 +03:00 --- debug: Session Library initialized
2013-08-30 11:03:11 +03:00 --- debug: Auth Library loaded
2013-08-30 11:03:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:03:11 +03:00 --- debug: Database Library initialized
2013-08-30 11:06:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:06:55 +03:00 --- debug: Session Library initialized
2013-08-30 11:06:55 +03:00 --- debug: Auth Library loaded
2013-08-30 11:06:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:06:55 +03:00 --- debug: Database Library initialized
2013-08-30 11:07:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:07:09 +03:00 --- debug: Session Library initialized
2013-08-30 11:07:09 +03:00 --- debug: Auth Library loaded
2013-08-30 11:07:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:07:09 +03:00 --- debug: Database Library initialized
2013-08-30 11:07:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:07:13 +03:00 --- debug: Session Library initialized
2013-08-30 11:07:13 +03:00 --- debug: Auth Library loaded
2013-08-30 11:07:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:07:13 +03:00 --- debug: Database Library initialized
2013-08-30 11:07:14 +03:00 --- debug: Captcha Library initialized
2013-08-30 11:07:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:07:16 +03:00 --- debug: Session Library initialized
2013-08-30 11:07:16 +03:00 --- debug: Auth Library loaded
2013-08-30 11:07:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:07:16 +03:00 --- debug: Database Library initialized
2013-08-30 11:07:16 +03:00 --- debug: Captcha Library initialized
2013-08-30 11:07:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:07:17 +03:00 --- debug: Session Library initialized
2013-08-30 11:07:17 +03:00 --- debug: Auth Library loaded
2013-08-30 11:07:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:07:17 +03:00 --- debug: Database Library initialized
2013-08-30 11:07:17 +03:00 --- debug: Captcha Library initialized
2013-08-30 11:07:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:07:44 +03:00 --- debug: Session Library initialized
2013-08-30 11:07:44 +03:00 --- debug: Auth Library loaded
2013-08-30 11:07:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:07:44 +03:00 --- debug: Database Library initialized
2013-08-30 11:07:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:07:46 +03:00 --- debug: Session Library initialized
2013-08-30 11:07:46 +03:00 --- debug: Auth Library loaded
2013-08-30 11:07:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:07:46 +03:00 --- debug: Database Library initialized
2013-08-30 11:08:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:08:00 +03:00 --- debug: Session Library initialized
2013-08-30 11:08:00 +03:00 --- debug: Auth Library loaded
2013-08-30 11:08:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:08:00 +03:00 --- debug: Database Library initialized
2013-08-30 11:12:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:12:21 +03:00 --- debug: Session Library initialized
2013-08-30 11:12:21 +03:00 --- debug: Auth Library loaded
2013-08-30 11:12:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:12:21 +03:00 --- debug: Database Library initialized
2013-08-30 11:12:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:12:27 +03:00 --- debug: Session Library initialized
2013-08-30 11:12:27 +03:00 --- debug: Auth Library loaded
2013-08-30 11:12:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:12:27 +03:00 --- debug: Database Library initialized
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: core.uncaught_exception
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:12:27 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:12:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:12:27 +03:00 --- debug: Session Library initialized
2013-08-30 11:12:27 +03:00 --- debug: Auth Library loaded
2013-08-30 11:12:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:12:27 +03:00 --- debug: Database Library initialized
2013-08-30 11:12:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: core.uncaught_exception
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:12:53 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:12:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:12:53 +03:00 --- debug: Session Library initialized
2013-08-30 11:12:53 +03:00 --- debug: Auth Library loaded
2013-08-30 11:12:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:12:53 +03:00 --- debug: Database Library initialized
2013-08-30 11:12:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:12:55 +03:00 --- debug: Session Library initialized
2013-08-30 11:12:55 +03:00 --- debug: Auth Library loaded
2013-08-30 11:12:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:12:55 +03:00 --- debug: Database Library initialized
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.invalid_method for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: core.uncaught_exception
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:12:55 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:12:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:12:55 +03:00 --- debug: Session Library initialized
2013-08-30 11:12:55 +03:00 --- debug: Auth Library loaded
2013-08-30 11:12:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:12:55 +03:00 --- debug: Database Library initialized
2013-08-30 11:13:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: core.uncaught_exception
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:13:25 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:13:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:13:25 +03:00 --- debug: Session Library initialized
2013-08-30 11:13:25 +03:00 --- debug: Auth Library loaded
2013-08-30 11:13:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:13:25 +03:00 --- debug: Database Library initialized
2013-08-30 11:13:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:13:26 +03:00 --- debug: Session Library initialized
2013-08-30 11:13:26 +03:00 --- debug: Auth Library loaded
2013-08-30 11:13:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:13:26 +03:00 --- debug: Database Library initialized
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.invalid_method for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: core.uncaught_exception
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:13:26 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:13:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:13:26 +03:00 --- debug: Session Library initialized
2013-08-30 11:13:26 +03:00 --- debug: Auth Library loaded
2013-08-30 11:13:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:13:26 +03:00 --- debug: Database Library initialized
2013-08-30 11:14:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:14:03 +03:00 --- debug: Session Library initialized
2013-08-30 11:14:03 +03:00 --- debug: Auth Library loaded
2013-08-30 11:14:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:14:03 +03:00 --- debug: Database Library initialized
2013-08-30 11:14:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:14:03 +03:00 --- debug: Session Library initialized
2013-08-30 11:14:03 +03:00 --- debug: Auth Library loaded
2013-08-30 11:14:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:14:03 +03:00 --- debug: Database Library initialized
2013-08-30 11:14:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:14:11 +03:00 --- debug: Session Library initialized
2013-08-30 11:14:11 +03:00 --- debug: Auth Library loaded
2013-08-30 11:14:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:14:11 +03:00 --- debug: Database Library initialized
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: core.uncaught_exception
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:14:12 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:14:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:14:12 +03:00 --- debug: Session Library initialized
2013-08-30 11:14:12 +03:00 --- debug: Auth Library loaded
2013-08-30 11:14:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:14:12 +03:00 --- debug: Database Library initialized
2013-08-30 11:14:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:14:31 +03:00 --- debug: Session Library initialized
2013-08-30 11:14:31 +03:00 --- debug: Auth Library loaded
2013-08-30 11:14:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:14:31 +03:00 --- debug: Database Library initialized
2013-08-30 11:14:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:14:32 +03:00 --- debug: Session Library initialized
2013-08-30 11:14:32 +03:00 --- debug: Auth Library loaded
2013-08-30 11:14:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:14:32 +03:00 --- debug: Database Library initialized
2013-08-30 11:14:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:14:39 +03:00 --- debug: Session Library initialized
2013-08-30 11:14:39 +03:00 --- debug: Auth Library loaded
2013-08-30 11:14:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:14:39 +03:00 --- debug: Database Library initialized
2013-08-30 11:16:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:16:05 +03:00 --- debug: Session Library initialized
2013-08-30 11:16:05 +03:00 --- debug: Auth Library loaded
2013-08-30 11:16:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:16:05 +03:00 --- debug: Database Library initialized
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: core.uncaught_exception
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:16:05 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:16:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:16:05 +03:00 --- debug: Session Library initialized
2013-08-30 11:16:05 +03:00 --- debug: Auth Library loaded
2013-08-30 11:16:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:16:05 +03:00 --- debug: Database Library initialized
2013-08-30 11:16:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:16:45 +03:00 --- debug: Session Library initialized
2013-08-30 11:16:45 +03:00 --- debug: Auth Library loaded
2013-08-30 11:16:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:16:45 +03:00 --- debug: Database Library initialized
2013-08-30 11:17:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:17:44 +03:00 --- debug: Session Library initialized
2013-08-30 11:17:44 +03:00 --- debug: Auth Library loaded
2013-08-30 11:17:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:17:44 +03:00 --- debug: Database Library initialized
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: core.uncaught_exception
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:17:44 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:17:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:17:44 +03:00 --- debug: Session Library initialized
2013-08-30 11:17:44 +03:00 --- debug: Auth Library loaded
2013-08-30 11:17:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:17:44 +03:00 --- debug: Database Library initialized
2013-08-30 11:17:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:17:59 +03:00 --- debug: Session Library initialized
2013-08-30 11:17:59 +03:00 --- debug: Auth Library loaded
2013-08-30 11:17:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:17:59 +03:00 --- debug: Database Library initialized
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: core.uncaught_exception
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:17:59 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:17:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:17:59 +03:00 --- debug: Session Library initialized
2013-08-30 11:17:59 +03:00 --- debug: Auth Library loaded
2013-08-30 11:17:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:17:59 +03:00 --- debug: Database Library initialized
2013-08-30 11:18:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:18:23 +03:00 --- debug: Session Library initialized
2013-08-30 11:18:23 +03:00 --- debug: Auth Library loaded
2013-08-30 11:18:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:18:23 +03:00 --- debug: Database Library initialized
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: core.uncaught_exception
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:18:23 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:18:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:18:23 +03:00 --- debug: Session Library initialized
2013-08-30 11:18:23 +03:00 --- debug: Auth Library loaded
2013-08-30 11:18:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:18:23 +03:00 --- debug: Database Library initialized
2013-08-30 11:18:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:18:48 +03:00 --- debug: Session Library initialized
2013-08-30 11:18:48 +03:00 --- debug: Auth Library loaded
2013-08-30 11:18:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:18:48 +03:00 --- debug: Database Library initialized
2013-08-30 11:19:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:19:18 +03:00 --- debug: Session Library initialized
2013-08-30 11:19:18 +03:00 --- debug: Auth Library loaded
2013-08-30 11:19:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:19:18 +03:00 --- debug: Database Library initialized
2013-08-30 11:19:18 +03:00 --- error: Не пойманное Kohana_404_Exception: Запрошенная страница, blog/fantastic_notebook.html, не найдена. в файле system/core/Kohana.php, на строке 841
2013-08-30 11:19:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:19:18 +03:00 --- debug: Session Library initialized
2013-08-30 11:19:18 +03:00 --- debug: Auth Library loaded
2013-08-30 11:19:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:19:18 +03:00 --- debug: Database Library initialized
2013-08-30 11:23:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:23:14 +03:00 --- debug: Session Library initialized
2013-08-30 11:23:14 +03:00 --- debug: Auth Library loaded
2013-08-30 11:23:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:23:14 +03:00 --- debug: Database Library initialized
2013-08-30 11:24:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: core.uncaught_exception
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:24:18 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:24:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:24:18 +03:00 --- debug: Session Library initialized
2013-08-30 11:24:18 +03:00 --- debug: Auth Library loaded
2013-08-30 11:24:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:24:18 +03:00 --- debug: Database Library initialized
2013-08-30 11:24:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:24:20 +03:00 --- debug: Session Library initialized
2013-08-30 11:24:20 +03:00 --- debug: Auth Library loaded
2013-08-30 11:24:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:24:20 +03:00 --- debug: Database Library initialized
2013-08-30 11:24:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:24:35 +03:00 --- debug: Session Library initialized
2013-08-30 11:24:35 +03:00 --- debug: Auth Library loaded
2013-08-30 11:24:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:24:35 +03:00 --- debug: Database Library initialized
2013-08-30 11:24:35 +03:00 --- debug: Captcha Library initialized
2013-08-30 11:24:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:24:39 +03:00 --- debug: Session Library initialized
2013-08-30 11:24:39 +03:00 --- debug: Auth Library loaded
2013-08-30 11:24:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:24:39 +03:00 --- debug: Database Library initialized
2013-08-30 11:24:39 +03:00 --- debug: Captcha Library initialized
2013-08-30 11:26:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:26:27 +03:00 --- debug: Session Library initialized
2013-08-30 11:26:27 +03:00 --- debug: Auth Library loaded
2013-08-30 11:26:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:26:27 +03:00 --- debug: Database Library initialized
2013-08-30 11:27:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:27:03 +03:00 --- debug: Session Library initialized
2013-08-30 11:27:03 +03:00 --- debug: Auth Library loaded
2013-08-30 11:27:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:27:03 +03:00 --- debug: Database Library initialized
2013-08-30 11:27:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:27:42 +03:00 --- debug: Session Library initialized
2013-08-30 11:27:42 +03:00 --- debug: Auth Library loaded
2013-08-30 11:27:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:27:42 +03:00 --- debug: Database Library initialized
2013-08-30 11:28:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:28:10 +03:00 --- debug: Session Library initialized
2013-08-30 11:28:10 +03:00 --- debug: Auth Library loaded
2013-08-30 11:28:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:28:10 +03:00 --- debug: Database Library initialized
2013-08-30 11:28:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:28:18 +03:00 --- debug: Session Library initialized
2013-08-30 11:28:18 +03:00 --- debug: Auth Library loaded
2013-08-30 11:28:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:28:18 +03:00 --- debug: Database Library initialized
2013-08-30 11:29:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:29:10 +03:00 --- debug: Session Library initialized
2013-08-30 11:29:10 +03:00 --- debug: Auth Library loaded
2013-08-30 11:29:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:29:10 +03:00 --- debug: Database Library initialized
2013-08-30 11:30:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:30:31 +03:00 --- debug: Session Library initialized
2013-08-30 11:30:31 +03:00 --- debug: Auth Library loaded
2013-08-30 11:30:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:30:31 +03:00 --- debug: Database Library initialized
2013-08-30 11:31:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:31:47 +03:00 --- debug: Session Library initialized
2013-08-30 11:31:47 +03:00 --- debug: Auth Library loaded
2013-08-30 11:31:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:31:47 +03:00 --- debug: Database Library initialized
2013-08-30 11:32:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:32:02 +03:00 --- debug: Session Library initialized
2013-08-30 11:32:02 +03:00 --- debug: Auth Library loaded
2013-08-30 11:32:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:32:02 +03:00 --- debug: Database Library initialized
2013-08-30 11:32:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:32:28 +03:00 --- debug: Session Library initialized
2013-08-30 11:32:28 +03:00 --- debug: Auth Library loaded
2013-08-30 11:32:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:32:28 +03:00 --- debug: Database Library initialized
2013-08-30 11:33:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:33:12 +03:00 --- debug: Session Library initialized
2013-08-30 11:33:12 +03:00 --- debug: Auth Library loaded
2013-08-30 11:33:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: core.uncaught_exception
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:33:12 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:33:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:33:21 +03:00 --- debug: Session Library initialized
2013-08-30 11:33:21 +03:00 --- debug: Auth Library loaded
2013-08-30 11:33:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:33:21 +03:00 --- debug: Database Library initialized
2013-08-30 11:33:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:33:35 +03:00 --- debug: Session Library initialized
2013-08-30 11:33:35 +03:00 --- debug: Auth Library loaded
2013-08-30 11:33:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:33:35 +03:00 --- debug: Database Library initialized
2013-08-30 11:33:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:33:35 +03:00 --- debug: Session Library initialized
2013-08-30 11:33:35 +03:00 --- debug: Auth Library loaded
2013-08-30 11:33:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:33:35 +03:00 --- debug: Database Library initialized
2013-08-30 11:34:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:34:30 +03:00 --- debug: Session Library initialized
2013-08-30 11:34:30 +03:00 --- debug: Auth Library loaded
2013-08-30 11:34:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:34:30 +03:00 --- debug: Database Library initialized
2013-08-30 11:34:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:34:44 +03:00 --- debug: Session Library initialized
2013-08-30 11:34:44 +03:00 --- debug: Auth Library loaded
2013-08-30 11:34:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:34:44 +03:00 --- debug: Database Library initialized
2013-08-30 11:34:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:34:44 +03:00 --- debug: Session Library initialized
2013-08-30 11:34:44 +03:00 --- debug: Auth Library loaded
2013-08-30 11:34:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:34:44 +03:00 --- debug: Database Library initialized
2013-08-30 11:36:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:36:28 +03:00 --- debug: Session Library initialized
2013-08-30 11:36:28 +03:00 --- debug: Auth Library loaded
2013-08-30 11:36:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:36:28 +03:00 --- debug: Session Library initialized
2013-08-30 11:36:28 +03:00 --- debug: Auth Library loaded
2013-08-30 11:36:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:36:28 +03:00 --- debug: Database Library initialized
2013-08-30 11:36:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:36:40 +03:00 --- debug: Session Library initialized
2013-08-30 11:36:40 +03:00 --- debug: Auth Library loaded
2013-08-30 11:36:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:36:40 +03:00 --- debug: Database Library initialized
2013-08-30 11:36:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:36:50 +03:00 --- debug: Session Library initialized
2013-08-30 11:36:50 +03:00 --- debug: Auth Library loaded
2013-08-30 11:36:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:36:50 +03:00 --- debug: Database Library initialized
2013-08-30 11:36:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:36:50 +03:00 --- debug: Session Library initialized
2013-08-30 11:36:50 +03:00 --- debug: Auth Library loaded
2013-08-30 11:36:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:36:50 +03:00 --- debug: Database Library initialized
2013-08-30 11:38:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:38:37 +03:00 --- debug: Session Library initialized
2013-08-30 11:38:37 +03:00 --- debug: Auth Library loaded
2013-08-30 11:38:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:38:37 +03:00 --- debug: Database Library initialized
2013-08-30 11:38:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:38:42 +03:00 --- debug: Session Library initialized
2013-08-30 11:38:42 +03:00 --- debug: Auth Library loaded
2013-08-30 11:38:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:38:42 +03:00 --- debug: Database Library initialized
2013-08-30 11:38:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:38:52 +03:00 --- debug: Session Library initialized
2013-08-30 11:38:52 +03:00 --- debug: Auth Library loaded
2013-08-30 11:38:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:38:52 +03:00 --- debug: Database Library initialized
2013-08-30 11:40:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:40:14 +03:00 --- debug: Session Library initialized
2013-08-30 11:40:14 +03:00 --- debug: Auth Library loaded
2013-08-30 11:40:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:40:14 +03:00 --- debug: Database Library initialized
2013-08-30 11:40:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:40:18 +03:00 --- debug: Session Library initialized
2013-08-30 11:40:18 +03:00 --- debug: Auth Library loaded
2013-08-30 11:40:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:40:18 +03:00 --- debug: Database Library initialized
2013-08-30 11:40:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:40:24 +03:00 --- debug: Session Library initialized
2013-08-30 11:40:24 +03:00 --- debug: Auth Library loaded
2013-08-30 11:40:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:40:24 +03:00 --- debug: Database Library initialized
2013-08-30 11:41:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:41:42 +03:00 --- debug: Session Library initialized
2013-08-30 11:41:42 +03:00 --- debug: Auth Library loaded
2013-08-30 11:41:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:41:42 +03:00 --- debug: Database Library initialized
2013-08-30 11:41:42 +03:00 --- error: Missing i18n entry database.error for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: core.uncaught_exception
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:41:43 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:41:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:41:43 +03:00 --- debug: Session Library initialized
2013-08-30 11:41:43 +03:00 --- debug: Auth Library loaded
2013-08-30 11:41:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:41:43 +03:00 --- debug: Database Library initialized
2013-08-30 11:43:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:43:28 +03:00 --- debug: Session Library initialized
2013-08-30 11:43:28 +03:00 --- debug: Auth Library loaded
2013-08-30 11:43:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:43:28 +03:00 --- debug: Database Library initialized
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: core.uncaught_exception
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:43:28 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:43:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:43:28 +03:00 --- debug: Session Library initialized
2013-08-30 11:43:28 +03:00 --- debug: Auth Library loaded
2013-08-30 11:43:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:43:28 +03:00 --- debug: Database Library initialized
2013-08-30 11:43:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:43:37 +03:00 --- debug: Session Library initialized
2013-08-30 11:43:37 +03:00 --- debug: Auth Library loaded
2013-08-30 11:43:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:43:37 +03:00 --- debug: Database Library initialized
2013-08-30 11:44:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:44:51 +03:00 --- debug: Session Library initialized
2013-08-30 11:44:51 +03:00 --- debug: Auth Library loaded
2013-08-30 11:44:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:44:51 +03:00 --- debug: Database Library initialized
2013-08-30 11:45:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:45:49 +03:00 --- debug: Session Library initialized
2013-08-30 11:45:49 +03:00 --- debug: Auth Library loaded
2013-08-30 11:45:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:45:49 +03:00 --- debug: Database Library initialized
2013-08-30 11:46:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:46:16 +03:00 --- debug: Session Library initialized
2013-08-30 11:46:16 +03:00 --- debug: Auth Library loaded
2013-08-30 11:46:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:46:16 +03:00 --- debug: Database Library initialized
2013-08-30 11:46:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:46:32 +03:00 --- debug: Session Library initialized
2013-08-30 11:46:32 +03:00 --- debug: Auth Library loaded
2013-08-30 11:46:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:46:32 +03:00 --- debug: Database Library initialized
2013-08-30 11:47:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:47:21 +03:00 --- debug: Session Library initialized
2013-08-30 11:47:21 +03:00 --- debug: Auth Library loaded
2013-08-30 11:47:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:47:21 +03:00 --- debug: Database Library initialized
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.invalid_method for language uk_UA
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 11:47:21 +03:00 --- error: core.uncaught_exception
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 11:47:21 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 11:47:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:47:21 +03:00 --- debug: Session Library initialized
2013-08-30 11:47:21 +03:00 --- debug: Auth Library loaded
2013-08-30 11:47:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:47:21 +03:00 --- debug: Database Library initialized
2013-08-30 11:47:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:47:27 +03:00 --- debug: Session Library initialized
2013-08-30 11:47:27 +03:00 --- debug: Auth Library loaded
2013-08-30 11:47:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:47:27 +03:00 --- debug: Database Library initialized
2013-08-30 11:47:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:47:35 +03:00 --- debug: Session Library initialized
2013-08-30 11:47:35 +03:00 --- debug: Auth Library loaded
2013-08-30 11:47:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:47:35 +03:00 --- debug: Database Library initialized
2013-08-30 11:47:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:47:52 +03:00 --- debug: Session Library initialized
2013-08-30 11:47:52 +03:00 --- debug: Auth Library loaded
2013-08-30 11:47:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:47:52 +03:00 --- debug: Database Library initialized
2013-08-30 11:47:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:47:52 +03:00 --- debug: Session Library initialized
2013-08-30 11:47:52 +03:00 --- debug: Auth Library loaded
2013-08-30 11:47:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:47:52 +03:00 --- debug: Database Library initialized
2013-08-30 11:50:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:50:10 +03:00 --- debug: Session Library initialized
2013-08-30 11:50:10 +03:00 --- debug: Auth Library loaded
2013-08-30 11:50:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:50:10 +03:00 --- debug: Database Library initialized
2013-08-30 11:51:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:51:31 +03:00 --- debug: Session Library initialized
2013-08-30 11:51:31 +03:00 --- debug: Auth Library loaded
2013-08-30 11:51:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:51:31 +03:00 --- debug: Database Library initialized
2013-08-30 11:51:31 +03:00 --- error: Missing i18n entry admin.error.default_login_error for language uk_UA
2013-08-30 11:51:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:51:31 +03:00 --- debug: Session Library initialized
2013-08-30 11:51:31 +03:00 --- debug: Auth Library loaded
2013-08-30 11:51:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:51:31 +03:00 --- debug: Database Library initialized
2013-08-30 11:51:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:51:56 +03:00 --- debug: Session Library initialized
2013-08-30 11:51:56 +03:00 --- debug: Auth Library loaded
2013-08-30 11:51:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:51:56 +03:00 --- debug: Database Library initialized
2013-08-30 11:51:56 +03:00 --- error: Missing i18n entry admin.error.default_login_error for language uk_UA
2013-08-30 11:51:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:51:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:51:56 +03:00 --- debug: Database Library initialized
2013-08-30 11:51:56 +03:00 --- debug: Session Library initialized
2013-08-30 11:51:56 +03:00 --- debug: Auth Library loaded
2013-08-30 11:51:56 +03:00 --- debug: Pagination Library initialized
2013-08-30 11:51:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 11:51:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 11:51:56 +03:00 --- debug: Database Library initialized
2013-08-30 11:51:56 +03:00 --- debug: Session Library initialized
2013-08-30 11:51:56 +03:00 --- debug: Auth Library loaded
2013-08-30 12:08:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:08:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:08:28 +03:00 --- debug: Database Library initialized
2013-08-30 12:08:28 +03:00 --- debug: Session Library initialized
2013-08-30 12:08:28 +03:00 --- debug: Auth Library loaded
2013-08-30 12:08:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:08:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:08:29 +03:00 --- debug: Database Library initialized
2013-08-30 12:08:29 +03:00 --- debug: Session Library initialized
2013-08-30 12:08:29 +03:00 --- debug: Auth Library loaded
2013-08-30 12:08:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:08:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:08:30 +03:00 --- debug: Database Library initialized
2013-08-30 12:08:30 +03:00 --- debug: Session Library initialized
2013-08-30 12:08:30 +03:00 --- debug: Auth Library loaded
2013-08-30 12:08:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:08:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:08:30 +03:00 --- debug: Database Library initialized
2013-08-30 12:08:30 +03:00 --- debug: Session Library initialized
2013-08-30 12:08:30 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:07 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:07 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:07 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:08 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:08 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:08 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:09 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:09 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:09 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:09 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:09 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:09 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:11 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:11 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:11 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:33 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:33 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:33 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:34 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:34 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:34 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:36 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:36 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:36 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:36 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:36 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:36 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:43 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:43 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:43 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:43 +03:00 --- debug: Pagination Library initialized
2013-08-30 12:09:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:43 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:43 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:43 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:45 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:45 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:45 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:45 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:45 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:45 +03:00 --- debug: Auth Library loaded
2013-08-30 12:09:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:09:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:09:45 +03:00 --- debug: Database Library initialized
2013-08-30 12:09:45 +03:00 --- debug: Session Library initialized
2013-08-30 12:09:45 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:21 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:21 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:21 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:21 +03:00 --- debug: Pagination Library initialized
2013-08-30 12:11:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:22 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:22 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:22 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:23 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: core.uncaught_exception
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:11:23 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:11:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:27 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:27 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:27 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:27 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:27 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:27 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:27 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:27 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:27 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:53 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:53 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:53 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:54 +03:00 --- debug: Pagination Library initialized
2013-08-30 12:11:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:54 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:54 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:54 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:55 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:55 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:55 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:56 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:56 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:56 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:57 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:57 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:57 +03:00 --- debug: Auth Library loaded
2013-08-30 12:11:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:11:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:11:57 +03:00 --- debug: Database Library initialized
2013-08-30 12:11:57 +03:00 --- debug: Session Library initialized
2013-08-30 12:11:57 +03:00 --- debug: Auth Library loaded
2013-08-30 12:12:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:12:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:12:15 +03:00 --- debug: Database Library initialized
2013-08-30 12:12:15 +03:00 --- debug: Session Library initialized
2013-08-30 12:12:15 +03:00 --- debug: Auth Library loaded
2013-08-30 12:12:16 +03:00 --- debug: Pagination Library initialized
2013-08-30 12:12:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:12:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:12:16 +03:00 --- debug: Database Library initialized
2013-08-30 12:12:16 +03:00 --- debug: Session Library initialized
2013-08-30 12:12:16 +03:00 --- debug: Auth Library loaded
2013-08-30 12:12:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:12:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:12:17 +03:00 --- debug: Database Library initialized
2013-08-30 12:12:17 +03:00 --- debug: Session Library initialized
2013-08-30 12:12:17 +03:00 --- debug: Auth Library loaded
2013-08-30 12:12:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:12:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:12:18 +03:00 --- debug: Database Library initialized
2013-08-30 12:12:18 +03:00 --- debug: Session Library initialized
2013-08-30 12:12:18 +03:00 --- debug: Auth Library loaded
2013-08-30 12:12:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:12:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:12:18 +03:00 --- debug: Database Library initialized
2013-08-30 12:12:18 +03:00 --- debug: Session Library initialized
2013-08-30 12:12:18 +03:00 --- debug: Auth Library loaded
2013-08-30 12:12:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:12:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:12:18 +03:00 --- debug: Database Library initialized
2013-08-30 12:12:18 +03:00 --- debug: Session Library initialized
2013-08-30 12:12:18 +03:00 --- debug: Auth Library loaded
2013-08-30 12:13:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:13:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:13:48 +03:00 --- debug: Database Library initialized
2013-08-30 12:13:48 +03:00 --- debug: Session Library initialized
2013-08-30 12:13:48 +03:00 --- debug: Auth Library loaded
2013-08-30 12:13:48 +03:00 --- debug: Pagination Library initialized
2013-08-30 12:13:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:13:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:13:49 +03:00 --- debug: Database Library initialized
2013-08-30 12:13:49 +03:00 --- debug: Session Library initialized
2013-08-30 12:13:49 +03:00 --- debug: Auth Library loaded
2013-08-30 12:13:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:13:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:13:50 +03:00 --- debug: Database Library initialized
2013-08-30 12:13:50 +03:00 --- debug: Session Library initialized
2013-08-30 12:13:50 +03:00 --- debug: Auth Library loaded
2013-08-30 12:13:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:13:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:13:51 +03:00 --- debug: Database Library initialized
2013-08-30 12:13:51 +03:00 --- debug: Session Library initialized
2013-08-30 12:13:51 +03:00 --- debug: Auth Library loaded
2013-08-30 12:13:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:13:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:13:51 +03:00 --- debug: Database Library initialized
2013-08-30 12:13:51 +03:00 --- debug: Session Library initialized
2013-08-30 12:13:51 +03:00 --- debug: Auth Library loaded
2013-08-30 12:13:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:13:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:13:55 +03:00 --- debug: Database Library initialized
2013-08-30 12:13:55 +03:00 --- debug: Session Library initialized
2013-08-30 12:13:55 +03:00 --- debug: Auth Library loaded
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: core.uncaught_exception
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:13:56 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:13:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:13:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:13:56 +03:00 --- debug: Database Library initialized
2013-08-30 12:13:56 +03:00 --- debug: Session Library initialized
2013-08-30 12:13:56 +03:00 --- debug: Auth Library loaded
2013-08-30 12:15:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:15:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:15:20 +03:00 --- debug: Database Library initialized
2013-08-30 12:15:20 +03:00 --- debug: Session Library initialized
2013-08-30 12:15:20 +03:00 --- debug: Auth Library loaded
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.invalid_property for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: core.uncaught_exception
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:15:20 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:15:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:15:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:15:20 +03:00 --- debug: Database Library initialized
2013-08-30 12:15:20 +03:00 --- debug: Session Library initialized
2013-08-30 12:15:20 +03:00 --- debug: Auth Library loaded
2013-08-30 12:15:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:15:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:15:36 +03:00 --- debug: Database Library initialized
2013-08-30 12:15:36 +03:00 --- debug: Session Library initialized
2013-08-30 12:15:36 +03:00 --- debug: Auth Library loaded
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.invalid_property for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: core.uncaught_exception
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:15:36 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:15:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:15:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:15:36 +03:00 --- debug: Database Library initialized
2013-08-30 12:15:36 +03:00 --- debug: Session Library initialized
2013-08-30 12:15:36 +03:00 --- debug: Auth Library loaded
2013-08-30 12:15:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:15:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:15:52 +03:00 --- debug: Database Library initialized
2013-08-30 12:15:52 +03:00 --- debug: Session Library initialized
2013-08-30 12:15:52 +03:00 --- debug: Auth Library loaded
2013-08-30 12:15:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:15:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:15:52 +03:00 --- debug: Database Library initialized
2013-08-30 12:15:52 +03:00 --- debug: Session Library initialized
2013-08-30 12:15:52 +03:00 --- debug: Auth Library loaded
2013-08-30 12:16:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:16:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:16:29 +03:00 --- debug: Database Library initialized
2013-08-30 12:16:29 +03:00 --- debug: Session Library initialized
2013-08-30 12:16:29 +03:00 --- debug: Auth Library loaded
2013-08-30 12:16:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:16:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:16:29 +03:00 --- debug: Database Library initialized
2013-08-30 12:16:29 +03:00 --- debug: Session Library initialized
2013-08-30 12:16:29 +03:00 --- debug: Auth Library loaded
2013-08-30 12:16:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:16:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:16:45 +03:00 --- debug: Database Library initialized
2013-08-30 12:16:45 +03:00 --- debug: Session Library initialized
2013-08-30 12:16:45 +03:00 --- debug: Auth Library loaded
2013-08-30 12:16:45 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:16:45 +03:00 --- error: core.uncaught_exception
2013-08-30 12:16:45 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:16:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:45 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:16:45 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:16:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:16:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:16:45 +03:00 --- debug: Database Library initialized
2013-08-30 12:16:45 +03:00 --- debug: Session Library initialized
2013-08-30 12:16:45 +03:00 --- debug: Auth Library loaded
2013-08-30 12:16:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:16:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:16:58 +03:00 --- debug: Database Library initialized
2013-08-30 12:16:58 +03:00 --- debug: Session Library initialized
2013-08-30 12:16:58 +03:00 --- debug: Auth Library loaded
2013-08-30 12:16:59 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:16:59 +03:00 --- error: core.uncaught_exception
2013-08-30 12:16:59 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:16:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:16:59 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:16:59 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:16:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:16:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:16:59 +03:00 --- debug: Database Library initialized
2013-08-30 12:16:59 +03:00 --- debug: Session Library initialized
2013-08-30 12:16:59 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:31 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:31 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:31 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:31 +03:00 --- debug: Pagination Library initialized
2013-08-30 12:17:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:31 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:31 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:31 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:33 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:33 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:33 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:34 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:34 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:34 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:34 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:34 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:34 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:34 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:34 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:34 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:37 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:37 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:37 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:38 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:38 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:38 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:56 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:56 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:56 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:56 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:17:56 +03:00 --- error: core.uncaught_exception
2013-08-30 12:17:56 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:17:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:56 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:56 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:17:56 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:17:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:56 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:56 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:56 +03:00 --- debug: Auth Library loaded
2013-08-30 12:17:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:59 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: core.uncaught_exception
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:17:59 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:17:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:17:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:17:59 +03:00 --- debug: Database Library initialized
2013-08-30 12:17:59 +03:00 --- debug: Session Library initialized
2013-08-30 12:17:59 +03:00 --- debug: Auth Library loaded
2013-08-30 12:18:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:18:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:18:01 +03:00 --- debug: Database Library initialized
2013-08-30 12:18:01 +03:00 --- debug: Session Library initialized
2013-08-30 12:18:01 +03:00 --- debug: Auth Library loaded
2013-08-30 12:18:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:18:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:18:01 +03:00 --- debug: Database Library initialized
2013-08-30 12:18:01 +03:00 --- debug: Session Library initialized
2013-08-30 12:18:01 +03:00 --- debug: Auth Library loaded
2013-08-30 12:18:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:18:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:18:30 +03:00 --- debug: Database Library initialized
2013-08-30 12:18:30 +03:00 --- debug: Session Library initialized
2013-08-30 12:18:30 +03:00 --- debug: Auth Library loaded
2013-08-30 12:18:30 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:18:30 +03:00 --- error: core.uncaught_exception
2013-08-30 12:18:30 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:18:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:30 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:18:30 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:18:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:18:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:18:31 +03:00 --- debug: Database Library initialized
2013-08-30 12:18:31 +03:00 --- debug: Session Library initialized
2013-08-30 12:18:31 +03:00 --- debug: Auth Library loaded
2013-08-30 12:18:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:18:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:18:58 +03:00 --- debug: Database Library initialized
2013-08-30 12:18:58 +03:00 --- debug: Session Library initialized
2013-08-30 12:18:58 +03:00 --- debug: Auth Library loaded
2013-08-30 12:18:58 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:18:58 +03:00 --- error: core.uncaught_exception
2013-08-30 12:18:58 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:18:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:18:58 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:18:58 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:18:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:18:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:18:58 +03:00 --- debug: Database Library initialized
2013-08-30 12:18:58 +03:00 --- debug: Session Library initialized
2013-08-30 12:18:58 +03:00 --- debug: Auth Library loaded
2013-08-30 12:19:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:19:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:19:00 +03:00 --- debug: Database Library initialized
2013-08-30 12:19:00 +03:00 --- debug: Session Library initialized
2013-08-30 12:19:00 +03:00 --- debug: Auth Library loaded
2013-08-30 12:19:00 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:19:00 +03:00 --- error: core.uncaught_exception
2013-08-30 12:19:00 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:19:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:00 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:19:00 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:19:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:19:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:19:00 +03:00 --- debug: Database Library initialized
2013-08-30 12:19:00 +03:00 --- debug: Session Library initialized
2013-08-30 12:19:00 +03:00 --- debug: Auth Library loaded
2013-08-30 12:19:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:19:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:19:03 +03:00 --- debug: Database Library initialized
2013-08-30 12:19:03 +03:00 --- debug: Session Library initialized
2013-08-30 12:19:03 +03:00 --- debug: Auth Library loaded
2013-08-30 12:19:03 +03:00 --- debug: Pagination Library initialized
2013-08-30 12:19:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:19:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:19:03 +03:00 --- debug: Database Library initialized
2013-08-30 12:19:03 +03:00 --- debug: Session Library initialized
2013-08-30 12:19:03 +03:00 --- debug: Auth Library loaded
2013-08-30 12:19:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:19:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:19:05 +03:00 --- debug: Database Library initialized
2013-08-30 12:19:05 +03:00 --- debug: Session Library initialized
2013-08-30 12:19:05 +03:00 --- debug: Auth Library loaded
2013-08-30 12:19:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:19:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:19:05 +03:00 --- debug: Database Library initialized
2013-08-30 12:19:05 +03:00 --- debug: Session Library initialized
2013-08-30 12:19:05 +03:00 --- debug: Auth Library loaded
2013-08-30 12:19:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:19:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:19:06 +03:00 --- debug: Database Library initialized
2013-08-30 12:19:06 +03:00 --- debug: Session Library initialized
2013-08-30 12:19:06 +03:00 --- debug: Auth Library loaded
2013-08-30 12:19:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:19:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:19:07 +03:00 --- debug: Database Library initialized
2013-08-30 12:19:07 +03:00 --- debug: Session Library initialized
2013-08-30 12:19:07 +03:00 --- debug: Auth Library loaded
2013-08-30 12:19:07 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:19:07 +03:00 --- error: core.uncaught_exception
2013-08-30 12:19:07 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:19:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:07 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:19:07 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:19:07 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:19:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:19:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:19:07 +03:00 --- debug: Database Library initialized
2013-08-30 12:19:07 +03:00 --- debug: Session Library initialized
2013-08-30 12:19:07 +03:00 --- debug: Auth Library loaded
2013-08-30 12:20:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:20:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:20:04 +03:00 --- debug: Database Library initialized
2013-08-30 12:20:04 +03:00 --- debug: Session Library initialized
2013-08-30 12:20:04 +03:00 --- debug: Auth Library loaded
2013-08-30 12:20:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:20:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:20:05 +03:00 --- debug: Database Library initialized
2013-08-30 12:20:05 +03:00 --- debug: Session Library initialized
2013-08-30 12:20:05 +03:00 --- debug: Auth Library loaded
2013-08-30 12:20:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:20:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:20:11 +03:00 --- debug: Database Library initialized
2013-08-30 12:20:11 +03:00 --- debug: Session Library initialized
2013-08-30 12:20:11 +03:00 --- debug: Auth Library loaded
2013-08-30 12:20:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:20:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:20:11 +03:00 --- debug: Database Library initialized
2013-08-30 12:20:11 +03:00 --- debug: Session Library initialized
2013-08-30 12:20:11 +03:00 --- debug: Auth Library loaded
2013-08-30 12:20:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:20:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:20:37 +03:00 --- debug: Database Library initialized
2013-08-30 12:20:37 +03:00 --- debug: Session Library initialized
2013-08-30 12:20:37 +03:00 --- debug: Auth Library loaded
2013-08-30 12:20:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:20:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:20:37 +03:00 --- debug: Database Library initialized
2013-08-30 12:20:37 +03:00 --- debug: Session Library initialized
2013-08-30 12:20:37 +03:00 --- debug: Auth Library loaded
2013-08-30 12:20:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:20:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:20:57 +03:00 --- debug: Database Library initialized
2013-08-30 12:20:57 +03:00 --- debug: Session Library initialized
2013-08-30 12:20:57 +03:00 --- debug: Auth Library loaded
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.invalid_property for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: core.uncaught_exception
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:20:57 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:20:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:20:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:20:57 +03:00 --- debug: Database Library initialized
2013-08-30 12:20:57 +03:00 --- debug: Session Library initialized
2013-08-30 12:20:57 +03:00 --- debug: Auth Library loaded
2013-08-30 12:21:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:21:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:21:09 +03:00 --- debug: Database Library initialized
2013-08-30 12:21:09 +03:00 --- debug: Session Library initialized
2013-08-30 12:21:09 +03:00 --- debug: Auth Library loaded
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.invalid_property for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: core.uncaught_exception
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:21:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:21:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:21:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:21:09 +03:00 --- debug: Database Library initialized
2013-08-30 12:21:09 +03:00 --- debug: Session Library initialized
2013-08-30 12:21:09 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:13 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:13 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:13 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.invalid_property for language uk_UA
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:22:13 +03:00 --- error: core.uncaught_exception
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:22:13 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:22:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:13 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:13 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:13 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:23 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:23 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:23 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.invalid_property for language uk_UA
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:22:23 +03:00 --- error: core.uncaught_exception
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:22:23 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:22:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:23 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:23 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:23 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:26 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:26 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:26 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:26 +03:00 --- debug: Pagination Library initialized
2013-08-30 12:22:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:27 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:27 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:27 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:28 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:28 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:28 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:29 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:22:29 +03:00 --- error: core.uncaught_exception
2013-08-30 12:22:29 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:22:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:29 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:22:29 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:22:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:46 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:46 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:46 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:46 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:46 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:46 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:47 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:47 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:47 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:49 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:49 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:49 +03:00 --- debug: Auth Library loaded
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.invalid_property for language uk_UA
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:22:49 +03:00 --- error: core.uncaught_exception
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:22:49 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:22:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:22:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:22:49 +03:00 --- debug: Database Library initialized
2013-08-30 12:22:49 +03:00 --- debug: Session Library initialized
2013-08-30 12:22:49 +03:00 --- debug: Auth Library loaded
2013-08-30 12:23:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:23:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:23:14 +03:00 --- debug: Database Library initialized
2013-08-30 12:23:14 +03:00 --- debug: Session Library initialized
2013-08-30 12:23:14 +03:00 --- debug: Auth Library loaded
2013-08-30 12:23:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:23:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:23:14 +03:00 --- debug: Database Library initialized
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: core.uncaught_exception
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:23:14 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:23:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:23:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:23:24 +03:00 --- debug: Database Library initialized
2013-08-30 12:23:24 +03:00 --- debug: Session Library initialized
2013-08-30 12:23:24 +03:00 --- debug: Auth Library loaded
2013-08-30 12:23:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:23:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:23:24 +03:00 --- debug: Database Library initialized
2013-08-30 12:23:24 +03:00 --- debug: Session Library initialized
2013-08-30 12:23:24 +03:00 --- debug: Auth Library loaded
2013-08-30 12:28:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:28:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:28:46 +03:00 --- debug: Database Library initialized
2013-08-30 12:28:46 +03:00 --- debug: Session Library initialized
2013-08-30 12:28:46 +03:00 --- debug: Auth Library loaded
2013-08-30 12:28:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:28:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:28:46 +03:00 --- debug: Database Library initialized
2013-08-30 12:28:46 +03:00 --- debug: Session Library initialized
2013-08-30 12:28:46 +03:00 --- debug: Auth Library loaded
2013-08-30 12:29:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:29:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:29:29 +03:00 --- debug: Database Library initialized
2013-08-30 12:29:29 +03:00 --- debug: Session Library initialized
2013-08-30 12:29:29 +03:00 --- debug: Auth Library loaded
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: core.uncaught_exception
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:29:29 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:29:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:29:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:29:29 +03:00 --- debug: Database Library initialized
2013-08-30 12:29:29 +03:00 --- debug: Session Library initialized
2013-08-30 12:29:29 +03:00 --- debug: Auth Library loaded
2013-08-30 12:29:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:29:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:29:55 +03:00 --- debug: Database Library initialized
2013-08-30 12:29:55 +03:00 --- debug: Session Library initialized
2013-08-30 12:29:55 +03:00 --- debug: Auth Library loaded
2013-08-30 12:29:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:29:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:29:56 +03:00 --- debug: Database Library initialized
2013-08-30 12:29:56 +03:00 --- debug: Session Library initialized
2013-08-30 12:29:56 +03:00 --- debug: Auth Library loaded
2013-08-30 12:30:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:30:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:30:03 +03:00 --- debug: Database Library initialized
2013-08-30 12:30:03 +03:00 --- debug: Session Library initialized
2013-08-30 12:30:03 +03:00 --- debug: Auth Library loaded
2013-08-30 12:30:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:30:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:30:04 +03:00 --- debug: Database Library initialized
2013-08-30 12:30:04 +03:00 --- debug: Session Library initialized
2013-08-30 12:30:04 +03:00 --- debug: Auth Library loaded
2013-08-30 12:33:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:33:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:33:13 +03:00 --- debug: Database Library initialized
2013-08-30 12:33:13 +03:00 --- debug: Session Library initialized
2013-08-30 12:33:13 +03:00 --- debug: Auth Library loaded
2013-08-30 12:33:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:33:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:33:13 +03:00 --- debug: Database Library initialized
2013-08-30 12:33:13 +03:00 --- debug: Session Library initialized
2013-08-30 12:33:13 +03:00 --- debug: Auth Library loaded
2013-08-30 12:33:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:33:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:33:32 +03:00 --- debug: Database Library initialized
2013-08-30 12:33:32 +03:00 --- debug: Session Library initialized
2013-08-30 12:33:32 +03:00 --- debug: Auth Library loaded
2013-08-30 12:33:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:33:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:33:33 +03:00 --- debug: Database Library initialized
2013-08-30 12:33:33 +03:00 --- debug: Session Library initialized
2013-08-30 12:33:33 +03:00 --- debug: Auth Library loaded
2013-08-30 12:33:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:33:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:33:38 +03:00 --- debug: Database Library initialized
2013-08-30 12:33:38 +03:00 --- debug: Session Library initialized
2013-08-30 12:33:38 +03:00 --- debug: Auth Library loaded
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: core.uncaught_exception
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:33:39 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:35:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:35:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:35:44 +03:00 --- debug: Database Library initialized
2013-08-30 12:35:44 +03:00 --- debug: Session Library initialized
2013-08-30 12:35:44 +03:00 --- debug: Auth Library loaded
2013-08-30 12:35:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:35:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:35:45 +03:00 --- debug: Database Library initialized
2013-08-30 12:35:45 +03:00 --- debug: Session Library initialized
2013-08-30 12:35:45 +03:00 --- debug: Auth Library loaded
2013-08-30 12:37:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:37:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:37:53 +03:00 --- debug: Database Library initialized
2013-08-30 12:37:53 +03:00 --- debug: Session Library initialized
2013-08-30 12:37:53 +03:00 --- debug: Auth Library loaded
2013-08-30 12:37:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:37:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:37:53 +03:00 --- debug: Database Library initialized
2013-08-30 12:37:53 +03:00 --- debug: Session Library initialized
2013-08-30 12:37:53 +03:00 --- debug: Auth Library loaded
2013-08-30 12:37:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:37:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:37:54 +03:00 --- debug: Database Library initialized
2013-08-30 12:37:54 +03:00 --- debug: Session Library initialized
2013-08-30 12:37:54 +03:00 --- debug: Auth Library loaded
2013-08-30 12:38:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:38:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:38:19 +03:00 --- debug: Database Library initialized
2013-08-30 12:38:19 +03:00 --- debug: Session Library initialized
2013-08-30 12:38:19 +03:00 --- debug: Auth Library loaded
2013-08-30 12:38:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:38:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:38:19 +03:00 --- debug: Database Library initialized
2013-08-30 12:38:19 +03:00 --- debug: Session Library initialized
2013-08-30 12:38:19 +03:00 --- debug: Auth Library loaded
2013-08-30 12:38:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:38:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:38:19 +03:00 --- debug: Database Library initialized
2013-08-30 12:38:19 +03:00 --- debug: Session Library initialized
2013-08-30 12:38:19 +03:00 --- debug: Auth Library loaded
2013-08-30 12:39:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:39:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:39:00 +03:00 --- debug: Database Library initialized
2013-08-30 12:39:00 +03:00 --- debug: Session Library initialized
2013-08-30 12:39:00 +03:00 --- debug: Auth Library loaded
2013-08-30 12:39:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:39:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:39:04 +03:00 --- debug: Database Library initialized
2013-08-30 12:39:04 +03:00 --- debug: Session Library initialized
2013-08-30 12:39:04 +03:00 --- debug: Auth Library loaded
2013-08-30 12:39:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:39:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:39:53 +03:00 --- debug: Database Library initialized
2013-08-30 12:39:53 +03:00 --- debug: Session Library initialized
2013-08-30 12:39:53 +03:00 --- debug: Auth Library loaded
2013-08-30 12:39:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:39:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:39:56 +03:00 --- debug: Database Library initialized
2013-08-30 12:39:56 +03:00 --- debug: Session Library initialized
2013-08-30 12:39:56 +03:00 --- debug: Auth Library loaded
2013-08-30 12:39:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:39:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:39:59 +03:00 --- debug: Database Library initialized
2013-08-30 12:39:59 +03:00 --- debug: Session Library initialized
2013-08-30 12:39:59 +03:00 --- debug: Auth Library loaded
2013-08-30 12:40:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:40:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:40:01 +03:00 --- debug: Database Library initialized
2013-08-30 12:40:01 +03:00 --- debug: Session Library initialized
2013-08-30 12:40:01 +03:00 --- debug: Auth Library loaded
2013-08-30 12:40:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:40:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:40:06 +03:00 --- debug: Database Library initialized
2013-08-30 12:40:06 +03:00 --- debug: Session Library initialized
2013-08-30 12:40:06 +03:00 --- debug: Auth Library loaded
2013-08-30 12:40:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:40:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:40:07 +03:00 --- debug: Database Library initialized
2013-08-30 12:40:07 +03:00 --- debug: Session Library initialized
2013-08-30 12:40:07 +03:00 --- debug: Auth Library loaded
2013-08-30 12:40:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:40:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:40:21 +03:00 --- debug: Database Library initialized
2013-08-30 12:40:21 +03:00 --- debug: Session Library initialized
2013-08-30 12:40:21 +03:00 --- debug: Auth Library loaded
2013-08-30 12:41:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:41:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:41:00 +03:00 --- debug: Database Library initialized
2013-08-30 12:41:00 +03:00 --- debug: Session Library initialized
2013-08-30 12:41:00 +03:00 --- debug: Auth Library loaded
2013-08-30 12:41:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:41:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:41:02 +03:00 --- debug: Database Library initialized
2013-08-30 12:41:02 +03:00 --- debug: Session Library initialized
2013-08-30 12:41:02 +03:00 --- debug: Auth Library loaded
2013-08-30 12:41:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:41:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:41:02 +03:00 --- debug: Database Library initialized
2013-08-30 12:41:02 +03:00 --- debug: Session Library initialized
2013-08-30 12:41:02 +03:00 --- debug: Auth Library loaded
2013-08-30 12:41:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:41:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:41:34 +03:00 --- debug: Database Library initialized
2013-08-30 12:41:34 +03:00 --- debug: Session Library initialized
2013-08-30 12:41:34 +03:00 --- debug: Auth Library loaded
2013-08-30 12:41:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:41:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:41:35 +03:00 --- debug: Database Library initialized
2013-08-30 12:41:35 +03:00 --- debug: Session Library initialized
2013-08-30 12:41:35 +03:00 --- debug: Auth Library loaded
2013-08-30 12:42:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:42:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:42:26 +03:00 --- debug: Database Library initialized
2013-08-30 12:42:26 +03:00 --- debug: Session Library initialized
2013-08-30 12:42:26 +03:00 --- debug: Auth Library loaded
2013-08-30 12:42:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:42:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:42:27 +03:00 --- debug: Database Library initialized
2013-08-30 12:42:27 +03:00 --- debug: Session Library initialized
2013-08-30 12:42:27 +03:00 --- debug: Auth Library loaded
2013-08-30 12:42:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:42:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:42:57 +03:00 --- debug: Database Library initialized
2013-08-30 12:42:57 +03:00 --- debug: Session Library initialized
2013-08-30 12:42:57 +03:00 --- debug: Auth Library loaded
2013-08-30 12:42:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:42:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:42:57 +03:00 --- debug: Database Library initialized
2013-08-30 12:42:57 +03:00 --- debug: Session Library initialized
2013-08-30 12:42:57 +03:00 --- debug: Auth Library loaded
2013-08-30 12:43:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:43:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:43:02 +03:00 --- debug: Database Library initialized
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: core.uncaught_exception
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:43:02 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:43:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:43:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:43:02 +03:00 --- debug: Database Library initialized
2013-08-30 12:43:02 +03:00 --- debug: Session Library initialized
2013-08-30 12:43:02 +03:00 --- debug: Auth Library loaded
2013-08-30 12:43:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:43:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:43:04 +03:00 --- debug: Database Library initialized
2013-08-30 12:43:04 +03:00 --- debug: Session Library initialized
2013-08-30 12:43:04 +03:00 --- debug: Auth Library loaded
2013-08-30 12:43:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:43:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:43:55 +03:00 --- debug: Database Library initialized
2013-08-30 12:43:55 +03:00 --- debug: Session Library initialized
2013-08-30 12:43:55 +03:00 --- debug: Auth Library loaded
2013-08-30 12:44:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:44:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:44:58 +03:00 --- debug: Database Library initialized
2013-08-30 12:44:58 +03:00 --- debug: Session Library initialized
2013-08-30 12:44:58 +03:00 --- debug: Auth Library loaded
2013-08-30 12:46:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:46:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:46:21 +03:00 --- debug: Database Library initialized
2013-08-30 12:46:21 +03:00 --- debug: Session Library initialized
2013-08-30 12:46:21 +03:00 --- debug: Auth Library loaded
2013-08-30 12:47:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:47:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:47:30 +03:00 --- debug: Database Library initialized
2013-08-30 12:47:30 +03:00 --- debug: Session Library initialized
2013-08-30 12:47:30 +03:00 --- debug: Auth Library loaded
2013-08-30 12:47:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:47:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:47:58 +03:00 --- debug: Database Library initialized
2013-08-30 12:47:58 +03:00 --- debug: Session Library initialized
2013-08-30 12:47:58 +03:00 --- debug: Auth Library loaded
2013-08-30 12:49:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:49:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:49:39 +03:00 --- debug: Database Library initialized
2013-08-30 12:49:39 +03:00 --- debug: Session Library initialized
2013-08-30 12:49:39 +03:00 --- debug: Auth Library loaded
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.invalid_property for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: core.uncaught_exception
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:49:39 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:49:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:49:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:49:39 +03:00 --- debug: Database Library initialized
2013-08-30 12:49:39 +03:00 --- debug: Session Library initialized
2013-08-30 12:49:39 +03:00 --- debug: Auth Library loaded
2013-08-30 12:49:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:49:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:49:54 +03:00 --- debug: Database Library initialized
2013-08-30 12:49:54 +03:00 --- debug: Session Library initialized
2013-08-30 12:49:54 +03:00 --- debug: Auth Library loaded
2013-08-30 12:51:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:51:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:51:18 +03:00 --- debug: Database Library initialized
2013-08-30 12:51:18 +03:00 --- debug: Session Library initialized
2013-08-30 12:51:18 +03:00 --- debug: Auth Library loaded
2013-08-30 12:52:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:52:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:52:06 +03:00 --- debug: Database Library initialized
2013-08-30 12:52:06 +03:00 --- debug: Session Library initialized
2013-08-30 12:52:06 +03:00 --- debug: Auth Library loaded
2013-08-30 12:52:07 +03:00 --- debug: Pagination Library initialized
2013-08-30 12:52:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:52:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:52:07 +03:00 --- debug: Database Library initialized
2013-08-30 12:52:07 +03:00 --- debug: Session Library initialized
2013-08-30 12:52:07 +03:00 --- debug: Auth Library loaded
2013-08-30 12:52:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:52:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:52:15 +03:00 --- debug: Database Library initialized
2013-08-30 12:52:15 +03:00 --- debug: Session Library initialized
2013-08-30 12:52:15 +03:00 --- debug: Auth Library loaded
2013-08-30 12:52:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:52:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:52:47 +03:00 --- debug: Database Library initialized
2013-08-30 12:52:47 +03:00 --- debug: Session Library initialized
2013-08-30 12:52:47 +03:00 --- debug: Auth Library loaded
2013-08-30 12:52:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:52:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:52:47 +03:00 --- debug: Database Library initialized
2013-08-30 12:52:47 +03:00 --- debug: Session Library initialized
2013-08-30 12:52:47 +03:00 --- debug: Auth Library loaded
2013-08-30 12:53:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:53:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:53:14 +03:00 --- debug: Database Library initialized
2013-08-30 12:53:14 +03:00 --- debug: Session Library initialized
2013-08-30 12:53:14 +03:00 --- debug: Auth Library loaded
2013-08-30 12:53:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:53:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:53:14 +03:00 --- debug: Database Library initialized
2013-08-30 12:53:14 +03:00 --- debug: Session Library initialized
2013-08-30 12:53:14 +03:00 --- debug: Auth Library loaded
2013-08-30 12:53:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:53:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:53:25 +03:00 --- debug: Database Library initialized
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: core.uncaught_exception
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 12:53:25 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 12:53:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:53:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:53:25 +03:00 --- debug: Database Library initialized
2013-08-30 12:53:25 +03:00 --- debug: Session Library initialized
2013-08-30 12:53:25 +03:00 --- debug: Auth Library loaded
2013-08-30 12:53:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:53:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:53:26 +03:00 --- debug: Database Library initialized
2013-08-30 12:53:26 +03:00 --- debug: Session Library initialized
2013-08-30 12:53:26 +03:00 --- debug: Auth Library loaded
2013-08-30 12:53:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:53:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:53:27 +03:00 --- debug: Database Library initialized
2013-08-30 12:53:27 +03:00 --- debug: Session Library initialized
2013-08-30 12:53:27 +03:00 --- debug: Auth Library loaded
2013-08-30 12:53:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:53:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:53:37 +03:00 --- debug: Database Library initialized
2013-08-30 12:53:37 +03:00 --- debug: Session Library initialized
2013-08-30 12:53:37 +03:00 --- debug: Auth Library loaded
2013-08-30 12:53:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:53:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:53:37 +03:00 --- debug: Database Library initialized
2013-08-30 12:53:37 +03:00 --- debug: Session Library initialized
2013-08-30 12:53:37 +03:00 --- debug: Auth Library loaded
2013-08-30 12:53:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:53:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:53:52 +03:00 --- debug: Database Library initialized
2013-08-30 12:53:52 +03:00 --- debug: Session Library initialized
2013-08-30 12:53:52 +03:00 --- debug: Auth Library loaded
2013-08-30 12:53:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:53:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:53:53 +03:00 --- debug: Database Library initialized
2013-08-30 12:53:53 +03:00 --- debug: Session Library initialized
2013-08-30 12:53:53 +03:00 --- debug: Auth Library loaded
2013-08-30 12:54:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:54:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:54:01 +03:00 --- debug: Database Library initialized
2013-08-30 12:54:01 +03:00 --- debug: Session Library initialized
2013-08-30 12:54:01 +03:00 --- debug: Auth Library loaded
2013-08-30 12:54:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:54:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:54:01 +03:00 --- debug: Database Library initialized
2013-08-30 12:54:01 +03:00 --- debug: Session Library initialized
2013-08-30 12:54:01 +03:00 --- debug: Auth Library loaded
2013-08-30 12:54:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:54:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:54:30 +03:00 --- debug: Database Library initialized
2013-08-30 12:54:30 +03:00 --- debug: Session Library initialized
2013-08-30 12:54:30 +03:00 --- debug: Auth Library loaded
2013-08-30 12:54:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:54:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:54:30 +03:00 --- debug: Database Library initialized
2013-08-30 12:54:30 +03:00 --- debug: Session Library initialized
2013-08-30 12:54:30 +03:00 --- debug: Auth Library loaded
2013-08-30 12:55:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:55:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:55:07 +03:00 --- debug: Database Library initialized
2013-08-30 12:55:07 +03:00 --- debug: Session Library initialized
2013-08-30 12:55:07 +03:00 --- debug: Auth Library loaded
2013-08-30 12:55:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 12:55:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 12:55:07 +03:00 --- debug: Database Library initialized
2013-08-30 12:55:07 +03:00 --- debug: Session Library initialized
2013-08-30 12:55:07 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:04 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:04 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:04 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:04 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:04 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:04 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:14 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:14 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:14 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:15 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:15 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:15 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:15 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:15 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:15 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:16 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:16 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:16 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:34 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:34 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:34 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:34 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:34 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:34 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:35 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:35 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:35 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:48 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:48 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:48 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:49 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:49 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:49 +03:00 --- debug: Auth Library loaded
2013-08-30 13:08:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:08:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:08:50 +03:00 --- debug: Database Library initialized
2013-08-30 13:08:50 +03:00 --- debug: Session Library initialized
2013-08-30 13:08:50 +03:00 --- debug: Auth Library loaded
2013-08-30 13:09:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:09:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:09:15 +03:00 --- debug: Database Library initialized
2013-08-30 13:09:15 +03:00 --- debug: Session Library initialized
2013-08-30 13:09:15 +03:00 --- debug: Auth Library loaded
2013-08-30 13:09:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:09:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:09:15 +03:00 --- debug: Database Library initialized
2013-08-30 13:09:15 +03:00 --- debug: Session Library initialized
2013-08-30 13:09:15 +03:00 --- debug: Auth Library loaded
2013-08-30 13:09:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:09:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:09:16 +03:00 --- debug: Database Library initialized
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: core.uncaught_exception
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:09:16 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:09:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:09:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:09:27 +03:00 --- debug: Database Library initialized
2013-08-30 13:09:27 +03:00 --- debug: Session Library initialized
2013-08-30 13:09:27 +03:00 --- debug: Auth Library loaded
2013-08-30 13:09:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:09:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:09:27 +03:00 --- debug: Database Library initialized
2013-08-30 13:09:27 +03:00 --- debug: Session Library initialized
2013-08-30 13:09:27 +03:00 --- debug: Auth Library loaded
2013-08-30 13:09:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:09:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:09:28 +03:00 --- debug: Database Library initialized
2013-08-30 13:09:28 +03:00 --- debug: Session Library initialized
2013-08-30 13:09:28 +03:00 --- debug: Auth Library loaded
2013-08-30 13:09:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:09:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:09:40 +03:00 --- debug: Database Library initialized
2013-08-30 13:09:40 +03:00 --- debug: Session Library initialized
2013-08-30 13:09:40 +03:00 --- debug: Auth Library loaded
2013-08-30 13:09:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:09:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:09:41 +03:00 --- debug: Database Library initialized
2013-08-30 13:09:41 +03:00 --- debug: Session Library initialized
2013-08-30 13:09:41 +03:00 --- debug: Auth Library loaded
2013-08-30 13:09:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:09:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:09:42 +03:00 --- debug: Database Library initialized
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: core.uncaught_exception
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:09:42 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:10:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:10:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:10:23 +03:00 --- debug: Database Library initialized
2013-08-30 13:10:23 +03:00 --- debug: Session Library initialized
2013-08-30 13:10:23 +03:00 --- debug: Auth Library loaded
2013-08-30 13:10:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:10:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:10:23 +03:00 --- debug: Database Library initialized
2013-08-30 13:10:23 +03:00 --- debug: Session Library initialized
2013-08-30 13:10:23 +03:00 --- debug: Auth Library loaded
2013-08-30 13:10:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:10:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:10:24 +03:00 --- debug: Database Library initialized
2013-08-30 13:10:24 +03:00 --- debug: Session Library initialized
2013-08-30 13:10:24 +03:00 --- debug: Auth Library loaded
2013-08-30 13:10:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:10:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:10:52 +03:00 --- debug: Database Library initialized
2013-08-30 13:10:52 +03:00 --- debug: Session Library initialized
2013-08-30 13:10:52 +03:00 --- debug: Auth Library loaded
2013-08-30 13:10:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:10:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:10:53 +03:00 --- debug: Database Library initialized
2013-08-30 13:10:53 +03:00 --- debug: Session Library initialized
2013-08-30 13:10:53 +03:00 --- debug: Auth Library loaded
2013-08-30 13:10:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:10:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:10:55 +03:00 --- debug: Database Library initialized
2013-08-30 13:10:55 +03:00 --- debug: Session Library initialized
2013-08-30 13:10:55 +03:00 --- debug: Auth Library loaded
2013-08-30 13:11:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:11:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:11:30 +03:00 --- debug: Database Library initialized
2013-08-30 13:11:30 +03:00 --- debug: Session Library initialized
2013-08-30 13:11:30 +03:00 --- debug: Auth Library loaded
2013-08-30 13:11:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:11:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:11:31 +03:00 --- debug: Database Library initialized
2013-08-30 13:11:31 +03:00 --- debug: Session Library initialized
2013-08-30 13:11:31 +03:00 --- debug: Auth Library loaded
2013-08-30 13:11:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:11:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:11:32 +03:00 --- debug: Database Library initialized
2013-08-30 13:11:32 +03:00 --- debug: Session Library initialized
2013-08-30 13:11:32 +03:00 --- debug: Auth Library loaded
2013-08-30 13:13:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:13:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:13:30 +03:00 --- debug: Database Library initialized
2013-08-30 13:13:30 +03:00 --- debug: Session Library initialized
2013-08-30 13:13:30 +03:00 --- debug: Auth Library loaded
2013-08-30 13:13:30 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:13:30 +03:00 --- error: core.uncaught_exception
2013-08-30 13:13:30 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:13:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:13:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:13:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:13:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:13:30 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:13:30 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:13:30 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:13:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:13:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:13:30 +03:00 --- debug: Database Library initialized
2013-08-30 13:13:30 +03:00 --- debug: Session Library initialized
2013-08-30 13:13:30 +03:00 --- debug: Auth Library loaded
2013-08-30 13:13:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:13:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:13:54 +03:00 --- debug: Database Library initialized
2013-08-30 13:13:54 +03:00 --- debug: Session Library initialized
2013-08-30 13:13:54 +03:00 --- debug: Auth Library loaded
2013-08-30 13:13:54 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:13:54 +03:00 --- error: core.uncaught_exception
2013-08-30 13:13:54 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:13:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:13:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:13:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:13:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:13:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:13:54 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:13:54 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:13:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:13:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:13:54 +03:00 --- debug: Database Library initialized
2013-08-30 13:13:54 +03:00 --- debug: Session Library initialized
2013-08-30 13:13:54 +03:00 --- debug: Auth Library loaded
2013-08-30 13:14:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:14:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:14:15 +03:00 --- debug: Database Library initialized
2013-08-30 13:14:15 +03:00 --- debug: Session Library initialized
2013-08-30 13:14:15 +03:00 --- debug: Auth Library loaded
2013-08-30 13:14:15 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:14:15 +03:00 --- error: core.uncaught_exception
2013-08-30 13:14:15 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:14:15 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:14:15 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:14:15 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:14:15 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:14:15 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:14:15 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:14:15 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:14:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:14:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:14:15 +03:00 --- debug: Database Library initialized
2013-08-30 13:14:15 +03:00 --- debug: Session Library initialized
2013-08-30 13:14:15 +03:00 --- debug: Auth Library loaded
2013-08-30 13:14:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:14:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:14:55 +03:00 --- debug: Database Library initialized
2013-08-30 13:14:55 +03:00 --- debug: Session Library initialized
2013-08-30 13:14:55 +03:00 --- debug: Auth Library loaded
2013-08-30 13:14:55 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:14:55 +03:00 --- error: core.uncaught_exception
2013-08-30 13:14:55 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:14:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:14:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:14:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:14:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:14:55 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:14:55 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:14:55 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:14:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:14:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:14:55 +03:00 --- debug: Database Library initialized
2013-08-30 13:14:55 +03:00 --- debug: Session Library initialized
2013-08-30 13:14:55 +03:00 --- debug: Auth Library loaded
2013-08-30 13:15:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:15:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:15:36 +03:00 --- debug: Database Library initialized
2013-08-30 13:15:36 +03:00 --- debug: Session Library initialized
2013-08-30 13:15:36 +03:00 --- debug: Auth Library loaded
2013-08-30 13:15:36 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:15:36 +03:00 --- error: core.uncaught_exception
2013-08-30 13:15:36 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:15:36 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:15:36 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:15:36 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:15:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:15:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:15:36 +03:00 --- debug: Database Library initialized
2013-08-30 13:15:36 +03:00 --- debug: Session Library initialized
2013-08-30 13:15:36 +03:00 --- debug: Auth Library loaded
2013-08-30 13:15:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:15:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:15:54 +03:00 --- debug: Database Library initialized
2013-08-30 13:15:54 +03:00 --- debug: Session Library initialized
2013-08-30 13:15:54 +03:00 --- debug: Auth Library loaded
2013-08-30 13:15:54 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:15:54 +03:00 --- error: core.uncaught_exception
2013-08-30 13:15:54 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:15:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:15:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:15:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:15:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:15:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:15:54 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:15:54 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:15:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:15:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:15:54 +03:00 --- debug: Database Library initialized
2013-08-30 13:15:54 +03:00 --- debug: Session Library initialized
2013-08-30 13:15:54 +03:00 --- debug: Auth Library loaded
2013-08-30 13:16:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:16:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:16:11 +03:00 --- debug: Database Library initialized
2013-08-30 13:16:11 +03:00 --- debug: Session Library initialized
2013-08-30 13:16:11 +03:00 --- debug: Auth Library loaded
2013-08-30 13:16:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:16:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:16:11 +03:00 --- debug: Database Library initialized
2013-08-30 13:16:11 +03:00 --- debug: Session Library initialized
2013-08-30 13:16:11 +03:00 --- debug: Auth Library loaded
2013-08-30 13:20:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:20:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:20:10 +03:00 --- debug: Database Library initialized
2013-08-30 13:20:10 +03:00 --- debug: Session Library initialized
2013-08-30 13:20:10 +03:00 --- debug: Auth Library loaded
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: core.uncaught_exception
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:20:10 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:20:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:20:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:20:10 +03:00 --- debug: Database Library initialized
2013-08-30 13:20:10 +03:00 --- debug: Session Library initialized
2013-08-30 13:20:10 +03:00 --- debug: Auth Library loaded
2013-08-30 13:20:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:20:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:20:39 +03:00 --- debug: Database Library initialized
2013-08-30 13:20:39 +03:00 --- debug: Session Library initialized
2013-08-30 13:20:39 +03:00 --- debug: Auth Library loaded
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: core.uncaught_exception
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:20:40 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:20:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:20:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:20:40 +03:00 --- debug: Database Library initialized
2013-08-30 13:20:40 +03:00 --- debug: Session Library initialized
2013-08-30 13:20:40 +03:00 --- debug: Auth Library loaded
2013-08-30 13:21:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:21:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:21:00 +03:00 --- debug: Database Library initialized
2013-08-30 13:21:00 +03:00 --- debug: Session Library initialized
2013-08-30 13:21:00 +03:00 --- debug: Auth Library loaded
2013-08-30 13:21:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:21:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:21:01 +03:00 --- debug: Database Library initialized
2013-08-30 13:21:01 +03:00 --- debug: Session Library initialized
2013-08-30 13:21:01 +03:00 --- debug: Auth Library loaded
2013-08-30 13:21:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:21:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:21:51 +03:00 --- debug: Database Library initialized
2013-08-30 13:21:51 +03:00 --- debug: Session Library initialized
2013-08-30 13:21:51 +03:00 --- debug: Auth Library loaded
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: core.uncaught_exception
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:21:51 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:21:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:21:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:21:52 +03:00 --- debug: Database Library initialized
2013-08-30 13:21:52 +03:00 --- debug: Session Library initialized
2013-08-30 13:21:52 +03:00 --- debug: Auth Library loaded
2013-08-30 13:22:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:22:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:22:18 +03:00 --- debug: Database Library initialized
2013-08-30 13:22:18 +03:00 --- debug: Session Library initialized
2013-08-30 13:22:18 +03:00 --- debug: Auth Library loaded
2013-08-30 13:22:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:22:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:22:18 +03:00 --- debug: Database Library initialized
2013-08-30 13:22:18 +03:00 --- debug: Session Library initialized
2013-08-30 13:22:18 +03:00 --- debug: Auth Library loaded
2013-08-30 13:22:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:22:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:22:44 +03:00 --- debug: Database Library initialized
2013-08-30 13:22:44 +03:00 --- debug: Session Library initialized
2013-08-30 13:22:44 +03:00 --- debug: Auth Library loaded
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: core.uncaught_exception
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:22:44 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:22:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:22:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:22:44 +03:00 --- debug: Database Library initialized
2013-08-30 13:22:44 +03:00 --- debug: Session Library initialized
2013-08-30 13:22:44 +03:00 --- debug: Auth Library loaded
2013-08-30 13:22:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:22:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:22:49 +03:00 --- debug: Database Library initialized
2013-08-30 13:22:49 +03:00 --- debug: Session Library initialized
2013-08-30 13:22:49 +03:00 --- debug: Auth Library loaded
2013-08-30 13:22:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:22:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:22:49 +03:00 --- debug: Database Library initialized
2013-08-30 13:22:49 +03:00 --- debug: Session Library initialized
2013-08-30 13:22:49 +03:00 --- debug: Auth Library loaded
2013-08-30 13:23:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:23:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:23:38 +03:00 --- debug: Database Library initialized
2013-08-30 13:23:38 +03:00 --- debug: Session Library initialized
2013-08-30 13:23:38 +03:00 --- debug: Auth Library loaded
2013-08-30 13:23:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:23:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:23:38 +03:00 --- debug: Database Library initialized
2013-08-30 13:23:38 +03:00 --- debug: Session Library initialized
2013-08-30 13:23:38 +03:00 --- debug: Auth Library loaded
2013-08-30 13:24:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:24:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:24:07 +03:00 --- debug: Database Library initialized
2013-08-30 13:24:07 +03:00 --- debug: Session Library initialized
2013-08-30 13:24:07 +03:00 --- debug: Auth Library loaded
2013-08-30 13:24:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:24:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:24:07 +03:00 --- debug: Database Library initialized
2013-08-30 13:24:07 +03:00 --- debug: Session Library initialized
2013-08-30 13:24:07 +03:00 --- debug: Auth Library loaded
2013-08-30 13:25:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:25:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:25:28 +03:00 --- debug: Database Library initialized
2013-08-30 13:25:28 +03:00 --- debug: Session Library initialized
2013-08-30 13:25:28 +03:00 --- debug: Auth Library loaded
2013-08-30 13:25:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:25:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:25:28 +03:00 --- debug: Database Library initialized
2013-08-30 13:25:28 +03:00 --- debug: Session Library initialized
2013-08-30 13:25:28 +03:00 --- debug: Auth Library loaded
2013-08-30 13:25:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:25:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:25:31 +03:00 --- debug: Database Library initialized
2013-08-30 13:25:31 +03:00 --- debug: Session Library initialized
2013-08-30 13:25:31 +03:00 --- debug: Auth Library loaded
2013-08-30 13:25:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:25:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:25:31 +03:00 --- debug: Database Library initialized
2013-08-30 13:25:31 +03:00 --- debug: Session Library initialized
2013-08-30 13:25:31 +03:00 --- debug: Auth Library loaded
2013-08-30 13:25:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:25:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:25:51 +03:00 --- debug: Database Library initialized
2013-08-30 13:25:51 +03:00 --- debug: Session Library initialized
2013-08-30 13:25:51 +03:00 --- debug: Auth Library loaded
2013-08-30 13:25:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:25:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:25:51 +03:00 --- debug: Database Library initialized
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: core.uncaught_exception
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:25:51 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:26:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:26:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:26:09 +03:00 --- debug: Database Library initialized
2013-08-30 13:26:09 +03:00 --- debug: Session Library initialized
2013-08-30 13:26:09 +03:00 --- debug: Auth Library loaded
2013-08-30 13:26:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:26:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:26:10 +03:00 --- debug: Database Library initialized
2013-08-30 13:26:10 +03:00 --- debug: Session Library initialized
2013-08-30 13:26:10 +03:00 --- debug: Auth Library loaded
2013-08-30 13:26:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:26:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:26:52 +03:00 --- debug: Database Library initialized
2013-08-30 13:26:52 +03:00 --- debug: Session Library initialized
2013-08-30 13:26:52 +03:00 --- debug: Auth Library loaded
2013-08-30 13:26:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:26:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:26:52 +03:00 --- debug: Database Library initialized
2013-08-30 13:26:52 +03:00 --- debug: Session Library initialized
2013-08-30 13:26:52 +03:00 --- debug: Auth Library loaded
2013-08-30 13:27:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:27:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:27:56 +03:00 --- debug: Database Library initialized
2013-08-30 13:27:56 +03:00 --- debug: Session Library initialized
2013-08-30 13:27:56 +03:00 --- debug: Auth Library loaded
2013-08-30 13:27:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:27:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:27:56 +03:00 --- debug: Database Library initialized
2013-08-30 13:27:56 +03:00 --- debug: Session Library initialized
2013-08-30 13:27:56 +03:00 --- debug: Auth Library loaded
2013-08-30 13:28:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:28:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:28:21 +03:00 --- debug: Database Library initialized
2013-08-30 13:28:21 +03:00 --- debug: Session Library initialized
2013-08-30 13:28:21 +03:00 --- debug: Auth Library loaded
2013-08-30 13:28:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:28:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:28:21 +03:00 --- debug: Database Library initialized
2013-08-30 13:28:21 +03:00 --- debug: Session Library initialized
2013-08-30 13:28:21 +03:00 --- debug: Auth Library loaded
2013-08-30 13:29:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:29:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:29:07 +03:00 --- debug: Database Library initialized
2013-08-30 13:29:07 +03:00 --- debug: Session Library initialized
2013-08-30 13:29:07 +03:00 --- debug: Auth Library loaded
2013-08-30 13:30:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:30:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:30:47 +03:00 --- debug: Database Library initialized
2013-08-30 13:30:47 +03:00 --- debug: Session Library initialized
2013-08-30 13:30:47 +03:00 --- debug: Auth Library loaded
2013-08-30 13:31:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:31:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:31:25 +03:00 --- debug: Database Library initialized
2013-08-30 13:31:25 +03:00 --- debug: Session Library initialized
2013-08-30 13:31:25 +03:00 --- debug: Auth Library loaded
2013-08-30 13:34:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:34:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:34:44 +03:00 --- debug: Database Library initialized
2013-08-30 13:34:44 +03:00 --- debug: Session Library initialized
2013-08-30 13:34:44 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:04 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:04 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:04 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:04 +03:00 --- error: Missing i18n entry admin.dashboard for language uk_UA
2013-08-30 13:36:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:04 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:04 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:04 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:06 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:06 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:06 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: core.uncaught_exception
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:36:06 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:36:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:06 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:06 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:06 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:19 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:19 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:19 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: core.uncaught_exception
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:36:19 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:36:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:19 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:19 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:19 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:21 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:21 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:21 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: core.uncaught_exception
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:36:21 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:36:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:21 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:21 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:21 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:38 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:38 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:38 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:38 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:36:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:39 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:39 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:39 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:44 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:44 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:44 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:44 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:36:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:44 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:44 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:44 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:45 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:45 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:45 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:45 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:36:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:45 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:45 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:45 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:47 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:47 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:47 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:47 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:36:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:47 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:47 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:47 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:48 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:48 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:48 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:48 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:36:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:48 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:48 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:48 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:49 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:49 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:49 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:49 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:36:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:49 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:49 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:49 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:58 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:58 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:58 +03:00 --- debug: Auth Library loaded
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: core.uncaught_exception
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:36:58 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:36:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:36:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:36:58 +03:00 --- debug: Database Library initialized
2013-08-30 13:36:58 +03:00 --- debug: Session Library initialized
2013-08-30 13:36:58 +03:00 --- debug: Auth Library loaded
2013-08-30 13:37:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:37:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:37:00 +03:00 --- debug: Database Library initialized
2013-08-30 13:37:00 +03:00 --- debug: Session Library initialized
2013-08-30 13:37:00 +03:00 --- debug: Auth Library loaded
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: core.uncaught_exception
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:37:01 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:37:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:37:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:37:01 +03:00 --- debug: Database Library initialized
2013-08-30 13:37:01 +03:00 --- debug: Session Library initialized
2013-08-30 13:37:01 +03:00 --- debug: Auth Library loaded
2013-08-30 13:37:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:37:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:37:05 +03:00 --- debug: Database Library initialized
2013-08-30 13:37:05 +03:00 --- debug: Session Library initialized
2013-08-30 13:37:05 +03:00 --- debug: Auth Library loaded
2013-08-30 13:37:05 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:37:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:37:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:37:05 +03:00 --- debug: Database Library initialized
2013-08-30 13:37:05 +03:00 --- debug: Session Library initialized
2013-08-30 13:37:05 +03:00 --- debug: Auth Library loaded
2013-08-30 13:38:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:38:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:38:45 +03:00 --- debug: Database Library initialized
2013-08-30 13:38:45 +03:00 --- debug: Session Library initialized
2013-08-30 13:38:45 +03:00 --- debug: Auth Library loaded
2013-08-30 13:38:45 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:38:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:38:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:38:45 +03:00 --- debug: Database Library initialized
2013-08-30 13:38:45 +03:00 --- debug: Session Library initialized
2013-08-30 13:38:45 +03:00 --- debug: Auth Library loaded
2013-08-30 13:38:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:38:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:38:45 +03:00 --- debug: Database Library initialized
2013-08-30 13:38:45 +03:00 --- debug: Session Library initialized
2013-08-30 13:38:45 +03:00 --- debug: Auth Library loaded
2013-08-30 13:41:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:41:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:41:12 +03:00 --- debug: Database Library initialized
2013-08-30 13:41:12 +03:00 --- debug: Session Library initialized
2013-08-30 13:41:12 +03:00 --- debug: Auth Library loaded
2013-08-30 13:41:12 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:41:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:41:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:41:12 +03:00 --- debug: Database Library initialized
2013-08-30 13:41:12 +03:00 --- debug: Session Library initialized
2013-08-30 13:41:12 +03:00 --- debug: Auth Library loaded
2013-08-30 13:41:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:41:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:41:13 +03:00 --- debug: Database Library initialized
2013-08-30 13:41:13 +03:00 --- debug: Session Library initialized
2013-08-30 13:41:13 +03:00 --- debug: Auth Library loaded
2013-08-30 13:41:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:41:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:41:28 +03:00 --- debug: Database Library initialized
2013-08-30 13:41:28 +03:00 --- debug: Session Library initialized
2013-08-30 13:41:28 +03:00 --- debug: Auth Library loaded
2013-08-30 13:41:28 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:41:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:41:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:41:29 +03:00 --- debug: Database Library initialized
2013-08-30 13:41:29 +03:00 --- debug: Session Library initialized
2013-08-30 13:41:29 +03:00 --- debug: Auth Library loaded
2013-08-30 13:41:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:41:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:41:29 +03:00 --- debug: Database Library initialized
2013-08-30 13:41:29 +03:00 --- debug: Session Library initialized
2013-08-30 13:41:29 +03:00 --- debug: Auth Library loaded
2013-08-30 13:43:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:43:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:43:33 +03:00 --- debug: Database Library initialized
2013-08-30 13:43:33 +03:00 --- debug: Session Library initialized
2013-08-30 13:43:33 +03:00 --- debug: Auth Library loaded
2013-08-30 13:43:34 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:43:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:43:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:43:34 +03:00 --- debug: Database Library initialized
2013-08-30 13:43:34 +03:00 --- debug: Session Library initialized
2013-08-30 13:43:34 +03:00 --- debug: Auth Library loaded
2013-08-30 13:43:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:43:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:43:38 +03:00 --- debug: Database Library initialized
2013-08-30 13:43:38 +03:00 --- debug: Session Library initialized
2013-08-30 13:43:38 +03:00 --- debug: Auth Library loaded
2013-08-30 13:43:38 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:43:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:43:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:43:38 +03:00 --- debug: Database Library initialized
2013-08-30 13:43:38 +03:00 --- debug: Session Library initialized
2013-08-30 13:43:38 +03:00 --- debug: Auth Library loaded
2013-08-30 13:43:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:43:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:43:41 +03:00 --- debug: Database Library initialized
2013-08-30 13:43:41 +03:00 --- debug: Session Library initialized
2013-08-30 13:43:41 +03:00 --- debug: Auth Library loaded
2013-08-30 13:43:41 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:43:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:43:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:43:41 +03:00 --- debug: Database Library initialized
2013-08-30 13:43:41 +03:00 --- debug: Session Library initialized
2013-08-30 13:43:41 +03:00 --- debug: Auth Library loaded
2013-08-30 13:44:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:44:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:44:03 +03:00 --- debug: Database Library initialized
2013-08-30 13:44:03 +03:00 --- debug: Session Library initialized
2013-08-30 13:44:03 +03:00 --- debug: Auth Library loaded
2013-08-30 13:44:04 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:44:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:44:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:44:04 +03:00 --- debug: Database Library initialized
2013-08-30 13:44:04 +03:00 --- debug: Session Library initialized
2013-08-30 13:44:04 +03:00 --- debug: Auth Library loaded
2013-08-30 13:44:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:44:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:44:11 +03:00 --- debug: Database Library initialized
2013-08-30 13:44:11 +03:00 --- debug: Session Library initialized
2013-08-30 13:44:11 +03:00 --- debug: Auth Library loaded
2013-08-30 13:44:11 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:44:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:44:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:44:11 +03:00 --- debug: Database Library initialized
2013-08-30 13:44:11 +03:00 --- debug: Session Library initialized
2013-08-30 13:44:11 +03:00 --- debug: Auth Library loaded
2013-08-30 13:44:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:44:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:44:30 +03:00 --- debug: Database Library initialized
2013-08-30 13:44:30 +03:00 --- debug: Session Library initialized
2013-08-30 13:44:30 +03:00 --- debug: Auth Library loaded
2013-08-30 13:44:31 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:44:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:44:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:44:31 +03:00 --- debug: Database Library initialized
2013-08-30 13:44:31 +03:00 --- debug: Session Library initialized
2013-08-30 13:44:31 +03:00 --- debug: Auth Library loaded
2013-08-30 13:44:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:44:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:44:33 +03:00 --- debug: Database Library initialized
2013-08-30 13:44:33 +03:00 --- debug: Session Library initialized
2013-08-30 13:44:33 +03:00 --- debug: Auth Library loaded
2013-08-30 13:44:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:44:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:44:38 +03:00 --- debug: Database Library initialized
2013-08-30 13:44:38 +03:00 --- debug: Session Library initialized
2013-08-30 13:44:38 +03:00 --- debug: Auth Library loaded
2013-08-30 13:44:38 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:44:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:44:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:44:38 +03:00 --- debug: Database Library initialized
2013-08-30 13:44:38 +03:00 --- debug: Session Library initialized
2013-08-30 13:44:38 +03:00 --- debug: Auth Library loaded
2013-08-30 13:45:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:45:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:45:00 +03:00 --- debug: Database Library initialized
2013-08-30 13:45:00 +03:00 --- debug: Session Library initialized
2013-08-30 13:45:00 +03:00 --- debug: Auth Library loaded
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: core.uncaught_exception
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:45:00 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:45:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:45:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:45:47 +03:00 --- debug: Database Library initialized
2013-08-30 13:45:47 +03:00 --- debug: Session Library initialized
2013-08-30 13:45:47 +03:00 --- debug: Auth Library loaded
2013-08-30 13:45:47 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:45:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:45:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:45:47 +03:00 --- debug: Database Library initialized
2013-08-30 13:45:47 +03:00 --- debug: Session Library initialized
2013-08-30 13:45:47 +03:00 --- debug: Auth Library loaded
2013-08-30 13:45:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:45:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:45:54 +03:00 --- debug: Database Library initialized
2013-08-30 13:45:54 +03:00 --- debug: Session Library initialized
2013-08-30 13:45:54 +03:00 --- debug: Auth Library loaded
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: core.uncaught_exception
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:45:54 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:47:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:47:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:47:25 +03:00 --- debug: Database Library initialized
2013-08-30 13:47:25 +03:00 --- debug: Session Library initialized
2013-08-30 13:47:25 +03:00 --- debug: Auth Library loaded
2013-08-30 13:47:25 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:47:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:47:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:47:25 +03:00 --- debug: Database Library initialized
2013-08-30 13:47:25 +03:00 --- debug: Session Library initialized
2013-08-30 13:47:25 +03:00 --- debug: Auth Library loaded
2013-08-30 13:47:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:47:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:47:28 +03:00 --- debug: Database Library initialized
2013-08-30 13:47:28 +03:00 --- debug: Session Library initialized
2013-08-30 13:47:28 +03:00 --- debug: Auth Library loaded
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: core.uncaught_exception
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:47:28 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:48:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:07 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:07 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:07 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: core.uncaught_exception
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:48:08 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:48:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:08 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:08 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:08 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:10 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:10 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:10 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:10 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:48:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:10 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:11 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:11 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:15 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:15 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:15 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:15 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:15 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:15 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:15 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:48:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:15 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:15 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:15 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:29 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:29 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:29 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:29 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:48:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:29 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:29 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:29 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:48 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:48 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:48 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:52 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:52 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:52 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:52 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:52 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:52 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:53 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:53 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:53 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:53 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:53 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:53 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:53 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:53 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:53 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:54 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:48:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:54 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:54 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:54 +03:00 --- debug: Auth Library loaded
2013-08-30 13:48:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:48:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:48:59 +03:00 --- debug: Database Library initialized
2013-08-30 13:48:59 +03:00 --- debug: Session Library initialized
2013-08-30 13:48:59 +03:00 --- debug: Auth Library loaded
2013-08-30 13:49:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:49:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:49:00 +03:00 --- debug: Database Library initialized
2013-08-30 13:49:00 +03:00 --- debug: Session Library initialized
2013-08-30 13:49:00 +03:00 --- debug: Auth Library loaded
2013-08-30 13:49:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:49:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:49:02 +03:00 --- debug: Database Library initialized
2013-08-30 13:49:02 +03:00 --- debug: Session Library initialized
2013-08-30 13:49:02 +03:00 --- debug: Auth Library loaded
2013-08-30 13:49:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:49:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:49:02 +03:00 --- debug: Database Library initialized
2013-08-30 13:49:02 +03:00 --- debug: Session Library initialized
2013-08-30 13:49:02 +03:00 --- debug: Auth Library loaded
2013-08-30 13:49:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:49:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:49:03 +03:00 --- debug: Database Library initialized
2013-08-30 13:49:03 +03:00 --- debug: Session Library initialized
2013-08-30 13:49:03 +03:00 --- debug: Auth Library loaded
2013-08-30 13:49:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:49:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:49:07 +03:00 --- debug: Database Library initialized
2013-08-30 13:49:07 +03:00 --- debug: Session Library initialized
2013-08-30 13:49:07 +03:00 --- debug: Auth Library loaded
2013-08-30 13:49:07 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:49:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:49:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:49:07 +03:00 --- debug: Database Library initialized
2013-08-30 13:49:07 +03:00 --- debug: Session Library initialized
2013-08-30 13:49:07 +03:00 --- debug: Auth Library loaded
2013-08-30 13:49:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:49:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:49:10 +03:00 --- debug: Database Library initialized
2013-08-30 13:49:10 +03:00 --- debug: Session Library initialized
2013-08-30 13:49:10 +03:00 --- debug: Auth Library loaded
2013-08-30 13:49:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:49:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:49:37 +03:00 --- debug: Database Library initialized
2013-08-30 13:49:37 +03:00 --- debug: Session Library initialized
2013-08-30 13:49:37 +03:00 --- debug: Auth Library loaded
2013-08-30 13:49:37 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:49:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:49:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:49:37 +03:00 --- debug: Database Library initialized
2013-08-30 13:49:37 +03:00 --- debug: Session Library initialized
2013-08-30 13:49:37 +03:00 --- debug: Auth Library loaded
2013-08-30 13:49:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:49:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:49:38 +03:00 --- debug: Database Library initialized
2013-08-30 13:49:38 +03:00 --- debug: Session Library initialized
2013-08-30 13:49:38 +03:00 --- debug: Auth Library loaded
2013-08-30 13:55:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:55:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:55:24 +03:00 --- debug: Database Library initialized
2013-08-30 13:55:24 +03:00 --- debug: Session Library initialized
2013-08-30 13:55:24 +03:00 --- debug: Auth Library loaded
2013-08-30 13:55:24 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:55:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:55:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:55:25 +03:00 --- debug: Database Library initialized
2013-08-30 13:55:25 +03:00 --- debug: Session Library initialized
2013-08-30 13:55:25 +03:00 --- debug: Auth Library loaded
2013-08-30 13:55:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:55:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:55:27 +03:00 --- debug: Database Library initialized
2013-08-30 13:55:27 +03:00 --- debug: Session Library initialized
2013-08-30 13:55:27 +03:00 --- debug: Auth Library loaded
2013-08-30 13:55:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:55:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:55:28 +03:00 --- debug: Database Library initialized
2013-08-30 13:55:28 +03:00 --- debug: Session Library initialized
2013-08-30 13:55:28 +03:00 --- debug: Auth Library loaded
2013-08-30 13:55:28 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 13:55:28 +03:00 --- error: core.uncaught_exception
2013-08-30 13:55:28 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 13:55:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:55:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:55:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:55:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:55:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:55:28 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 13:55:28 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 13:55:28 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 13:55:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:55:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:55:45 +03:00 --- debug: Database Library initialized
2013-08-30 13:55:45 +03:00 --- debug: Session Library initialized
2013-08-30 13:55:45 +03:00 --- debug: Auth Library loaded
2013-08-30 13:55:45 +03:00 --- debug: Pagination Library initialized
2013-08-30 13:55:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:55:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:55:45 +03:00 --- debug: Database Library initialized
2013-08-30 13:55:45 +03:00 --- debug: Session Library initialized
2013-08-30 13:55:45 +03:00 --- debug: Auth Library loaded
2013-08-30 13:55:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:55:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:55:46 +03:00 --- debug: Database Library initialized
2013-08-30 13:55:46 +03:00 --- debug: Session Library initialized
2013-08-30 13:55:46 +03:00 --- debug: Auth Library loaded
2013-08-30 13:55:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 13:55:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 13:55:48 +03:00 --- debug: Database Library initialized
2013-08-30 13:55:48 +03:00 --- debug: Session Library initialized
2013-08-30 13:55:48 +03:00 --- debug: Auth Library loaded
2013-08-30 14:05:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:05:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:05:06 +03:00 --- debug: Database Library initialized
2013-08-30 14:05:06 +03:00 --- debug: Session Library initialized
2013-08-30 14:05:06 +03:00 --- debug: Auth Library loaded
2013-08-30 14:05:07 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:05:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:05:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:05:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:05:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:05:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:05:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:05:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:05:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:05:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:05:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:05:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:05:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:05:10 +03:00 --- debug: Database Library initialized
2013-08-30 14:05:10 +03:00 --- debug: Session Library initialized
2013-08-30 14:05:10 +03:00 --- debug: Auth Library loaded
2013-08-30 14:05:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:05:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:05:24 +03:00 --- debug: Database Library initialized
2013-08-30 14:05:24 +03:00 --- debug: Session Library initialized
2013-08-30 14:05:24 +03:00 --- debug: Auth Library loaded
2013-08-30 14:05:24 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:05:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:05:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:05:25 +03:00 --- debug: Database Library initialized
2013-08-30 14:05:25 +03:00 --- debug: Session Library initialized
2013-08-30 14:05:25 +03:00 --- debug: Auth Library loaded
2013-08-30 14:05:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:05:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:05:32 +03:00 --- debug: Database Library initialized
2013-08-30 14:05:32 +03:00 --- debug: Session Library initialized
2013-08-30 14:05:32 +03:00 --- debug: Auth Library loaded
2013-08-30 14:05:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:05:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:05:38 +03:00 --- debug: Database Library initialized
2013-08-30 14:05:38 +03:00 --- debug: Session Library initialized
2013-08-30 14:05:38 +03:00 --- debug: Auth Library loaded
2013-08-30 14:05:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:05:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:05:41 +03:00 --- debug: Database Library initialized
2013-08-30 14:05:41 +03:00 --- debug: Session Library initialized
2013-08-30 14:05:41 +03:00 --- debug: Auth Library loaded
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: core.uncaught_exception
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:05:41 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:09:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:09:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:09:12 +03:00 --- debug: Database Library initialized
2013-08-30 14:09:12 +03:00 --- debug: Session Library initialized
2013-08-30 14:09:12 +03:00 --- debug: Auth Library loaded
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: core.uncaught_exception
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:09:12 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:09:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:09:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:09:33 +03:00 --- debug: Database Library initialized
2013-08-30 14:09:33 +03:00 --- debug: Session Library initialized
2013-08-30 14:09:33 +03:00 --- debug: Auth Library loaded
2013-08-30 14:09:33 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:09:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:09:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:09:34 +03:00 --- debug: Database Library initialized
2013-08-30 14:09:34 +03:00 --- debug: Session Library initialized
2013-08-30 14:09:34 +03:00 --- debug: Auth Library loaded
2013-08-30 14:09:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:09:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:09:36 +03:00 --- debug: Database Library initialized
2013-08-30 14:09:36 +03:00 --- debug: Session Library initialized
2013-08-30 14:09:36 +03:00 --- debug: Auth Library loaded
2013-08-30 14:09:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:09:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:09:38 +03:00 --- debug: Database Library initialized
2013-08-30 14:09:38 +03:00 --- debug: Session Library initialized
2013-08-30 14:09:38 +03:00 --- debug: Auth Library loaded
2013-08-30 14:09:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:09:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:09:43 +03:00 --- debug: Database Library initialized
2013-08-30 14:09:43 +03:00 --- debug: Session Library initialized
2013-08-30 14:09:43 +03:00 --- debug: Auth Library loaded
2013-08-30 14:09:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:09:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:09:44 +03:00 --- debug: Database Library initialized
2013-08-30 14:09:44 +03:00 --- debug: Session Library initialized
2013-08-30 14:09:44 +03:00 --- debug: Auth Library loaded
2013-08-30 14:09:44 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:09:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:09:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:09:44 +03:00 --- debug: Database Library initialized
2013-08-30 14:09:44 +03:00 --- debug: Session Library initialized
2013-08-30 14:09:44 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:20 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:20 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:20 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:20 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:20 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:20 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:28 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:28 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:28 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:30 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:30 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:30 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:30 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:30 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:30 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:30 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:30 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:30 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:31 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:31 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:31 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:34 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:34 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:34 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:34 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:34 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:34 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:35 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:35 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:35 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:35 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:35 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:35 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:37 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:37 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:37 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:37 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:37 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:37 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:40 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:40 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:40 +03:00 --- debug: Auth Library loaded
2013-08-30 14:10:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:10:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:10:40 +03:00 --- debug: Database Library initialized
2013-08-30 14:10:40 +03:00 --- debug: Session Library initialized
2013-08-30 14:10:40 +03:00 --- debug: Auth Library loaded
2013-08-30 14:13:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:13:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:13:56 +03:00 --- debug: Database Library initialized
2013-08-30 14:13:56 +03:00 --- debug: Session Library initialized
2013-08-30 14:13:56 +03:00 --- debug: Auth Library loaded
2013-08-30 14:13:56 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:13:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:13:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:13:56 +03:00 --- debug: Database Library initialized
2013-08-30 14:13:56 +03:00 --- debug: Session Library initialized
2013-08-30 14:13:56 +03:00 --- debug: Auth Library loaded
2013-08-30 14:13:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:13:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:13:59 +03:00 --- debug: Database Library initialized
2013-08-30 14:13:59 +03:00 --- debug: Session Library initialized
2013-08-30 14:13:59 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:09 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:14:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:10 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:10 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:10 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:11 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:11 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:11 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:45 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:45 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:45 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:45 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:14:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:45 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: core.uncaught_exception
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:14:45 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:14:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:49 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:49 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:49 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:51 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:51 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:51 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:53 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:53 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:53 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:53 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:53 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:53 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:53 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:54 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:54 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:54 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:54 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:54 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:54 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:55 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:55 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:55 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:55 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:14:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:56 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:56 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:56 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:57 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:57 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:57 +03:00 --- debug: Auth Library loaded
2013-08-30 14:14:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:14:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:14:58 +03:00 --- debug: Database Library initialized
2013-08-30 14:14:58 +03:00 --- debug: Session Library initialized
2013-08-30 14:14:58 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:05 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:05 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:05 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:06 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:06 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:06 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:06 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:06 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:06 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:06 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:06 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:06 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:06 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:06 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:06 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:08 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:08 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:08 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:08 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:08 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:08 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:08 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:08 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:08 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:08 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:08 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:08 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:08 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:08 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:08 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:58 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:58 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:58 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:58 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:58 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:58 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:58 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:58 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:58 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:59 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:59 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:59 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:59 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:59 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:59 +03:00 --- debug: Auth Library loaded
2013-08-30 14:15:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:15:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:15:59 +03:00 --- debug: Database Library initialized
2013-08-30 14:15:59 +03:00 --- debug: Session Library initialized
2013-08-30 14:15:59 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:00 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:00 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:00 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:00 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:00 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:00 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:00 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:00 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:00 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:00 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:00 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:00 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:00 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:00 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:00 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:01 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:01 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:01 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:01 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:01 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:01 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:01 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:01 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:01 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:01 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:01 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:01 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:01 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:01 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:01 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:02 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:02 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:02 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:24 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:24 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:24 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: core.uncaught_exception
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:16:24 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:16:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:51 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:51 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:51 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:53 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:53 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:53 +03:00 --- debug: Auth Library loaded
2013-08-30 14:16:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:16:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:16:53 +03:00 --- debug: Database Library initialized
2013-08-30 14:16:53 +03:00 --- debug: Session Library initialized
2013-08-30 14:16:53 +03:00 --- debug: Auth Library loaded
2013-08-30 14:17:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:17:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:17:00 +03:00 --- debug: Database Library initialized
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: core.uncaught_exception
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:17:00 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:19:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:45 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:45 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:45 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:45 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:19:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:45 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:45 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:45 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:48 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:48 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:48 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:48 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:48 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:48 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:49 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:49 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:49 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:49 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:49 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:49 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:49 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:49 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:49 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:49 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:49 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:49 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:50 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:50 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:50 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:50 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:50 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:50 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:19:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:19:54 +03:00 --- debug: Database Library initialized
2013-08-30 14:19:54 +03:00 --- debug: Session Library initialized
2013-08-30 14:19:54 +03:00 --- debug: Auth Library loaded
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry image.file_not_found for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: core.uncaught_exception
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:19:54 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:21:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:21:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:21:31 +03:00 --- debug: Database Library initialized
2013-08-30 14:21:31 +03:00 --- debug: Session Library initialized
2013-08-30 14:21:31 +03:00 --- debug: Auth Library loaded
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry image.file_not_found for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: core.uncaught_exception
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:21:32 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:22:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:22:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:22:11 +03:00 --- debug: Database Library initialized
2013-08-30 14:22:11 +03:00 --- debug: Session Library initialized
2013-08-30 14:22:11 +03:00 --- debug: Auth Library loaded
2013-08-30 14:22:11 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:22:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:22:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:22:12 +03:00 --- debug: Database Library initialized
2013-08-30 14:22:12 +03:00 --- debug: Session Library initialized
2013-08-30 14:22:12 +03:00 --- debug: Auth Library loaded
2013-08-30 14:22:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:22:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:22:16 +03:00 --- debug: Database Library initialized
2013-08-30 14:22:16 +03:00 --- debug: Session Library initialized
2013-08-30 14:22:16 +03:00 --- debug: Auth Library loaded
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry image.file_not_found for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: core.uncaught_exception
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:22:17 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:22:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:22:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:22:50 +03:00 --- debug: Database Library initialized
2013-08-30 14:22:50 +03:00 --- debug: Session Library initialized
2013-08-30 14:22:50 +03:00 --- debug: Auth Library loaded
2013-08-30 14:23:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:23:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:23:43 +03:00 --- debug: Database Library initialized
2013-08-30 14:23:43 +03:00 --- debug: Session Library initialized
2013-08-30 14:23:43 +03:00 --- debug: Auth Library loaded
2013-08-30 14:29:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:29:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:29:21 +03:00 --- debug: Database Library initialized
2013-08-30 14:29:21 +03:00 --- debug: Session Library initialized
2013-08-30 14:29:21 +03:00 --- debug: Auth Library loaded
2013-08-30 14:29:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:29:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:29:54 +03:00 --- debug: Database Library initialized
2013-08-30 14:29:54 +03:00 --- debug: Session Library initialized
2013-08-30 14:29:54 +03:00 --- debug: Auth Library loaded
2013-08-30 14:30:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:30:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:30:44 +03:00 --- debug: Database Library initialized
2013-08-30 14:30:44 +03:00 --- debug: Session Library initialized
2013-08-30 14:30:44 +03:00 --- debug: Auth Library loaded
2013-08-30 14:31:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:31:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:31:35 +03:00 --- debug: Database Library initialized
2013-08-30 14:31:35 +03:00 --- debug: Session Library initialized
2013-08-30 14:31:35 +03:00 --- debug: Auth Library loaded
2013-08-30 14:32:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:32:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:32:18 +03:00 --- debug: Database Library initialized
2013-08-30 14:32:18 +03:00 --- debug: Session Library initialized
2013-08-30 14:32:18 +03:00 --- debug: Auth Library loaded
2013-08-30 14:33:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:33:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:33:24 +03:00 --- debug: Database Library initialized
2013-08-30 14:33:24 +03:00 --- debug: Session Library initialized
2013-08-30 14:33:24 +03:00 --- debug: Auth Library loaded
2013-08-30 14:34:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:34:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:34:24 +03:00 --- debug: Database Library initialized
2013-08-30 14:34:24 +03:00 --- debug: Session Library initialized
2013-08-30 14:34:24 +03:00 --- debug: Auth Library loaded
2013-08-30 14:34:24 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:34:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:34:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:34:25 +03:00 --- debug: Database Library initialized
2013-08-30 14:34:25 +03:00 --- debug: Session Library initialized
2013-08-30 14:34:25 +03:00 --- debug: Auth Library loaded
2013-08-30 14:34:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:34:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:34:49 +03:00 --- debug: Database Library initialized
2013-08-30 14:34:49 +03:00 --- debug: Session Library initialized
2013-08-30 14:34:49 +03:00 --- debug: Auth Library loaded
2013-08-30 14:36:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:36:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:36:45 +03:00 --- debug: Database Library initialized
2013-08-30 14:36:45 +03:00 --- debug: Session Library initialized
2013-08-30 14:36:45 +03:00 --- debug: Auth Library loaded
2013-08-30 14:36:45 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:36:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:36:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:36:45 +03:00 --- debug: Database Library initialized
2013-08-30 14:36:45 +03:00 --- debug: Session Library initialized
2013-08-30 14:36:45 +03:00 --- debug: Auth Library loaded
2013-08-30 14:36:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:36:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:36:52 +03:00 --- debug: Database Library initialized
2013-08-30 14:36:52 +03:00 --- debug: Session Library initialized
2013-08-30 14:36:52 +03:00 --- debug: Auth Library loaded
2013-08-30 14:38:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:38:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:38:10 +03:00 --- debug: Database Library initialized
2013-08-30 14:38:10 +03:00 --- debug: Session Library initialized
2013-08-30 14:38:10 +03:00 --- debug: Auth Library loaded
2013-08-30 14:39:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:39:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:39:04 +03:00 --- debug: Database Library initialized
2013-08-30 14:39:04 +03:00 --- debug: Session Library initialized
2013-08-30 14:39:04 +03:00 --- debug: Auth Library loaded
2013-08-30 14:39:04 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:39:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:39:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:39:05 +03:00 --- debug: Database Library initialized
2013-08-30 14:39:05 +03:00 --- debug: Session Library initialized
2013-08-30 14:39:05 +03:00 --- debug: Auth Library loaded
2013-08-30 14:39:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:39:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:39:09 +03:00 --- debug: Database Library initialized
2013-08-30 14:39:09 +03:00 --- debug: Session Library initialized
2013-08-30 14:39:09 +03:00 --- debug: Auth Library loaded
2013-08-30 14:39:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:39:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:39:19 +03:00 --- debug: Database Library initialized
2013-08-30 14:39:19 +03:00 --- debug: Session Library initialized
2013-08-30 14:39:19 +03:00 --- debug: Auth Library loaded
2013-08-30 14:39:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:39:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:39:20 +03:00 --- debug: Database Library initialized
2013-08-30 14:39:20 +03:00 --- debug: Session Library initialized
2013-08-30 14:39:20 +03:00 --- debug: Auth Library loaded
2013-08-30 14:39:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:39:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:39:20 +03:00 --- debug: Database Library initialized
2013-08-30 14:39:20 +03:00 --- debug: Session Library initialized
2013-08-30 14:39:20 +03:00 --- debug: Auth Library loaded
2013-08-30 14:40:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:40:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:40:39 +03:00 --- debug: Database Library initialized
2013-08-30 14:40:39 +03:00 --- debug: Session Library initialized
2013-08-30 14:40:39 +03:00 --- debug: Auth Library loaded
2013-08-30 14:40:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:40:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:40:40 +03:00 --- debug: Database Library initialized
2013-08-30 14:40:40 +03:00 --- debug: Session Library initialized
2013-08-30 14:40:40 +03:00 --- debug: Auth Library loaded
2013-08-30 14:40:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:40:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:40:50 +03:00 --- debug: Database Library initialized
2013-08-30 14:40:50 +03:00 --- debug: Session Library initialized
2013-08-30 14:40:50 +03:00 --- debug: Auth Library loaded
2013-08-30 14:40:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:40:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:40:56 +03:00 --- debug: Database Library initialized
2013-08-30 14:40:56 +03:00 --- debug: Session Library initialized
2013-08-30 14:40:56 +03:00 --- debug: Auth Library loaded
2013-08-30 14:43:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:43:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:43:39 +03:00 --- debug: Database Library initialized
2013-08-30 14:43:39 +03:00 --- debug: Session Library initialized
2013-08-30 14:43:39 +03:00 --- debug: Auth Library loaded
2013-08-30 14:45:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:45:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:45:00 +03:00 --- debug: Database Library initialized
2013-08-30 14:45:00 +03:00 --- debug: Session Library initialized
2013-08-30 14:45:00 +03:00 --- debug: Auth Library loaded
2013-08-30 14:45:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:45:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:45:13 +03:00 --- debug: Database Library initialized
2013-08-30 14:45:13 +03:00 --- debug: Session Library initialized
2013-08-30 14:45:13 +03:00 --- debug: Auth Library loaded
2013-08-30 14:45:13 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:45:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:45:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:45:14 +03:00 --- debug: Database Library initialized
2013-08-30 14:45:14 +03:00 --- debug: Session Library initialized
2013-08-30 14:45:14 +03:00 --- debug: Auth Library loaded
2013-08-30 14:45:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:45:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:45:20 +03:00 --- debug: Database Library initialized
2013-08-30 14:45:20 +03:00 --- debug: Session Library initialized
2013-08-30 14:45:20 +03:00 --- debug: Auth Library loaded
2013-08-30 14:46:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:46:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:46:05 +03:00 --- debug: Database Library initialized
2013-08-30 14:46:06 +03:00 --- debug: Session Library initialized
2013-08-30 14:46:06 +03:00 --- debug: Auth Library loaded
2013-08-30 14:46:06 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:46:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:46:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:46:06 +03:00 --- debug: Database Library initialized
2013-08-30 14:46:06 +03:00 --- debug: Session Library initialized
2013-08-30 14:46:06 +03:00 --- debug: Auth Library loaded
2013-08-30 14:46:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:46:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:46:12 +03:00 --- debug: Database Library initialized
2013-08-30 14:46:12 +03:00 --- debug: Session Library initialized
2013-08-30 14:46:12 +03:00 --- debug: Auth Library loaded
2013-08-30 14:46:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:46:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:46:49 +03:00 --- debug: Database Library initialized
2013-08-30 14:46:49 +03:00 --- debug: Session Library initialized
2013-08-30 14:46:49 +03:00 --- debug: Auth Library loaded
2013-08-30 14:46:49 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:46:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:46:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:46:50 +03:00 --- debug: Database Library initialized
2013-08-30 14:46:50 +03:00 --- debug: Session Library initialized
2013-08-30 14:46:50 +03:00 --- debug: Auth Library loaded
2013-08-30 14:46:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:46:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:46:59 +03:00 --- debug: Database Library initialized
2013-08-30 14:46:59 +03:00 --- debug: Session Library initialized
2013-08-30 14:46:59 +03:00 --- debug: Auth Library loaded
2013-08-30 14:48:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:48:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:48:00 +03:00 --- debug: Database Library initialized
2013-08-30 14:48:00 +03:00 --- debug: Session Library initialized
2013-08-30 14:48:00 +03:00 --- debug: Auth Library loaded
2013-08-30 14:48:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:48:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:48:01 +03:00 --- debug: Database Library initialized
2013-08-30 14:48:01 +03:00 --- debug: Session Library initialized
2013-08-30 14:48:01 +03:00 --- debug: Auth Library loaded
2013-08-30 14:48:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:48:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:48:22 +03:00 --- debug: Database Library initialized
2013-08-30 14:48:22 +03:00 --- debug: Session Library initialized
2013-08-30 14:48:22 +03:00 --- debug: Auth Library loaded
2013-08-30 14:48:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:48:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:48:47 +03:00 --- debug: Database Library initialized
2013-08-30 14:48:47 +03:00 --- debug: Session Library initialized
2013-08-30 14:48:47 +03:00 --- debug: Auth Library loaded
2013-08-30 14:48:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:48:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:48:51 +03:00 --- debug: Database Library initialized
2013-08-30 14:48:51 +03:00 --- debug: Session Library initialized
2013-08-30 14:48:51 +03:00 --- debug: Auth Library loaded
2013-08-30 14:49:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:49:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:49:24 +03:00 --- debug: Database Library initialized
2013-08-30 14:49:24 +03:00 --- debug: Session Library initialized
2013-08-30 14:49:24 +03:00 --- debug: Auth Library loaded
2013-08-30 14:50:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:50:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:50:13 +03:00 --- debug: Database Library initialized
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: core.uncaught_exception
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:50:13 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:50:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:50:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:50:13 +03:00 --- debug: Database Library initialized
2013-08-30 14:50:13 +03:00 --- debug: Session Library initialized
2013-08-30 14:50:13 +03:00 --- debug: Auth Library loaded
2013-08-30 14:50:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:50:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:50:14 +03:00 --- debug: Database Library initialized
2013-08-30 14:50:14 +03:00 --- debug: Session Library initialized
2013-08-30 14:50:14 +03:00 --- debug: Auth Library loaded
2013-08-30 14:50:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:50:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:50:14 +03:00 --- debug: Database Library initialized
2013-08-30 14:50:14 +03:00 --- debug: Session Library initialized
2013-08-30 14:50:14 +03:00 --- debug: Auth Library loaded
2013-08-30 14:50:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:50:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:50:14 +03:00 --- debug: Database Library initialized
2013-08-30 14:50:14 +03:00 --- debug: Session Library initialized
2013-08-30 14:50:14 +03:00 --- debug: Auth Library loaded
2013-08-30 14:50:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:50:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:50:14 +03:00 --- debug: Database Library initialized
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: core.uncaught_exception
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:50:14 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:51:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:04 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:04 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:04 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:04 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:51:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:04 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:04 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:04 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:05 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:05 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:05 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:06 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:06 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:06 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:06 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:06 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:06 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:07 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:07 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:07 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:32 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:32 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:32 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:33 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:51:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:33 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:33 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:33 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:34 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:34 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:34 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:37 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:37 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:37 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:37 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:37 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:37 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:38 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:51:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:38 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:38 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:38 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:57 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:57 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:57 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:57 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:57 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:57 +03:00 --- debug: Auth Library loaded
2013-08-30 14:51:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:51:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:51:58 +03:00 --- debug: Database Library initialized
2013-08-30 14:51:58 +03:00 --- debug: Session Library initialized
2013-08-30 14:51:58 +03:00 --- debug: Auth Library loaded
2013-08-30 14:52:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:52:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:52:26 +03:00 --- debug: Database Library initialized
2013-08-30 14:52:26 +03:00 --- debug: Session Library initialized
2013-08-30 14:52:26 +03:00 --- debug: Auth Library loaded
2013-08-30 14:52:26 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:52:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:52:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:52:27 +03:00 --- debug: Database Library initialized
2013-08-30 14:52:27 +03:00 --- debug: Session Library initialized
2013-08-30 14:52:27 +03:00 --- debug: Auth Library loaded
2013-08-30 14:53:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:53:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:53:11 +03:00 --- debug: Database Library initialized
2013-08-30 14:53:11 +03:00 --- debug: Session Library initialized
2013-08-30 14:53:11 +03:00 --- debug: Auth Library loaded
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry database.error for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: core.uncaught_exception
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:53:11 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:53:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:53:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:53:11 +03:00 --- debug: Database Library initialized
2013-08-30 14:53:11 +03:00 --- debug: Session Library initialized
2013-08-30 14:53:11 +03:00 --- debug: Auth Library loaded
2013-08-30 14:53:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:53:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:53:14 +03:00 --- debug: Database Library initialized
2013-08-30 14:53:14 +03:00 --- debug: Session Library initialized
2013-08-30 14:53:14 +03:00 --- debug: Auth Library loaded
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry database.error for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: core.uncaught_exception
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:53:14 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:53:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:53:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:53:14 +03:00 --- debug: Database Library initialized
2013-08-30 14:53:14 +03:00 --- debug: Session Library initialized
2013-08-30 14:53:14 +03:00 --- debug: Auth Library loaded
2013-08-30 14:53:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:53:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:53:17 +03:00 --- debug: Database Library initialized
2013-08-30 14:53:17 +03:00 --- debug: Session Library initialized
2013-08-30 14:53:17 +03:00 --- debug: Auth Library loaded
2013-08-30 14:53:17 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:53:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:53:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:53:17 +03:00 --- debug: Database Library initialized
2013-08-30 14:53:17 +03:00 --- debug: Session Library initialized
2013-08-30 14:53:17 +03:00 --- debug: Auth Library loaded
2013-08-30 14:53:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:53:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:53:32 +03:00 --- debug: Database Library initialized
2013-08-30 14:53:32 +03:00 --- debug: Session Library initialized
2013-08-30 14:53:32 +03:00 --- debug: Auth Library loaded
2013-08-30 14:53:32 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:53:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:53:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:53:32 +03:00 --- debug: Database Library initialized
2013-08-30 14:53:32 +03:00 --- debug: Session Library initialized
2013-08-30 14:53:32 +03:00 --- debug: Auth Library loaded
2013-08-30 14:53:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:53:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:53:42 +03:00 --- debug: Database Library initialized
2013-08-30 14:53:42 +03:00 --- debug: Session Library initialized
2013-08-30 14:53:42 +03:00 --- debug: Auth Library loaded
2013-08-30 14:53:42 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:53:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:53:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:53:43 +03:00 --- debug: Database Library initialized
2013-08-30 14:53:43 +03:00 --- debug: Session Library initialized
2013-08-30 14:53:43 +03:00 --- debug: Auth Library loaded
2013-08-30 14:54:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:54:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:54:05 +03:00 --- debug: Database Library initialized
2013-08-30 14:54:05 +03:00 --- debug: Session Library initialized
2013-08-30 14:54:05 +03:00 --- debug: Auth Library loaded
2013-08-30 14:54:06 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:54:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:54:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:54:06 +03:00 --- debug: Database Library initialized
2013-08-30 14:54:06 +03:00 --- debug: Session Library initialized
2013-08-30 14:54:06 +03:00 --- debug: Auth Library loaded
2013-08-30 14:54:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:54:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:54:25 +03:00 --- debug: Database Library initialized
2013-08-30 14:54:25 +03:00 --- debug: Session Library initialized
2013-08-30 14:54:25 +03:00 --- debug: Auth Library loaded
2013-08-30 14:54:26 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:54:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:54:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:54:26 +03:00 --- debug: Database Library initialized
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: core.uncaught_exception
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:54:26 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:54:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:54:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:54:41 +03:00 --- debug: Database Library initialized
2013-08-30 14:54:41 +03:00 --- debug: Session Library initialized
2013-08-30 14:54:41 +03:00 --- debug: Auth Library loaded
2013-08-30 14:54:41 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:54:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:54:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:54:42 +03:00 --- debug: Database Library initialized
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: core.uncaught_exception
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 14:54:42 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 14:54:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:54:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:54:43 +03:00 --- debug: Database Library initialized
2013-08-30 14:54:43 +03:00 --- debug: Session Library initialized
2013-08-30 14:54:43 +03:00 --- debug: Auth Library loaded
2013-08-30 14:54:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:54:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:54:44 +03:00 --- debug: Database Library initialized
2013-08-30 14:54:44 +03:00 --- debug: Session Library initialized
2013-08-30 14:54:44 +03:00 --- debug: Auth Library loaded
2013-08-30 14:54:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:54:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:54:45 +03:00 --- debug: Database Library initialized
2013-08-30 14:54:45 +03:00 --- debug: Session Library initialized
2013-08-30 14:54:45 +03:00 --- debug: Auth Library loaded
2013-08-30 14:54:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:54:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:54:45 +03:00 --- debug: Database Library initialized
2013-08-30 14:54:45 +03:00 --- debug: Session Library initialized
2013-08-30 14:54:45 +03:00 --- debug: Auth Library loaded
2013-08-30 14:55:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:55:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:55:11 +03:00 --- debug: Database Library initialized
2013-08-30 14:55:11 +03:00 --- debug: Session Library initialized
2013-08-30 14:55:11 +03:00 --- debug: Auth Library loaded
2013-08-30 14:55:11 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:55:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:55:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:55:11 +03:00 --- debug: Database Library initialized
2013-08-30 14:55:11 +03:00 --- debug: Session Library initialized
2013-08-30 14:55:11 +03:00 --- debug: Auth Library loaded
2013-08-30 14:55:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:55:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:55:24 +03:00 --- debug: Database Library initialized
2013-08-30 14:55:24 +03:00 --- debug: Session Library initialized
2013-08-30 14:55:24 +03:00 --- debug: Auth Library loaded
2013-08-30 14:55:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:55:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:55:33 +03:00 --- debug: Database Library initialized
2013-08-30 14:55:33 +03:00 --- debug: Session Library initialized
2013-08-30 14:55:33 +03:00 --- debug: Auth Library loaded
2013-08-30 14:55:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:55:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:55:36 +03:00 --- debug: Database Library initialized
2013-08-30 14:55:36 +03:00 --- debug: Session Library initialized
2013-08-30 14:55:36 +03:00 --- debug: Auth Library loaded
2013-08-30 14:55:36 +03:00 --- debug: Pagination Library initialized
2013-08-30 14:55:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:55:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:55:37 +03:00 --- debug: Database Library initialized
2013-08-30 14:55:37 +03:00 --- debug: Session Library initialized
2013-08-30 14:55:37 +03:00 --- debug: Auth Library loaded
2013-08-30 14:55:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:55:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:55:39 +03:00 --- debug: Database Library initialized
2013-08-30 14:55:39 +03:00 --- debug: Session Library initialized
2013-08-30 14:55:39 +03:00 --- debug: Auth Library loaded
2013-08-30 14:56:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:56:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:56:26 +03:00 --- debug: Database Library initialized
2013-08-30 14:56:26 +03:00 --- debug: Session Library initialized
2013-08-30 14:56:26 +03:00 --- debug: Auth Library loaded
2013-08-30 14:56:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:56:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:56:51 +03:00 --- debug: Database Library initialized
2013-08-30 14:56:51 +03:00 --- debug: Session Library initialized
2013-08-30 14:56:51 +03:00 --- debug: Auth Library loaded
2013-08-30 14:59:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:59:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:59:35 +03:00 --- debug: Database Library initialized
2013-08-30 14:59:35 +03:00 --- debug: Session Library initialized
2013-08-30 14:59:35 +03:00 --- debug: Auth Library loaded
2013-08-30 14:59:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 14:59:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 14:59:35 +03:00 --- debug: Database Library initialized
2013-08-30 14:59:35 +03:00 --- debug: Session Library initialized
2013-08-30 14:59:35 +03:00 --- debug: Auth Library loaded
2013-08-30 15:00:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:00:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:00:01 +03:00 --- debug: Database Library initialized
2013-08-30 15:00:01 +03:00 --- debug: Session Library initialized
2013-08-30 15:00:01 +03:00 --- debug: Auth Library loaded
2013-08-30 15:00:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:00:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:00:01 +03:00 --- debug: Database Library initialized
2013-08-30 15:00:01 +03:00 --- debug: Session Library initialized
2013-08-30 15:00:01 +03:00 --- debug: Auth Library loaded
2013-08-30 15:00:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:00:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:00:50 +03:00 --- debug: Database Library initialized
2013-08-30 15:00:50 +03:00 --- debug: Session Library initialized
2013-08-30 15:00:50 +03:00 --- debug: Auth Library loaded
2013-08-30 15:00:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:00:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:00:51 +03:00 --- debug: Database Library initialized
2013-08-30 15:00:51 +03:00 --- debug: Session Library initialized
2013-08-30 15:00:51 +03:00 --- debug: Auth Library loaded
2013-08-30 15:02:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:02:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:02:22 +03:00 --- debug: Database Library initialized
2013-08-30 15:02:22 +03:00 --- debug: Session Library initialized
2013-08-30 15:02:22 +03:00 --- debug: Auth Library loaded
2013-08-30 15:02:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:02:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:02:22 +03:00 --- debug: Database Library initialized
2013-08-30 15:02:22 +03:00 --- debug: Session Library initialized
2013-08-30 15:02:22 +03:00 --- debug: Auth Library loaded
2013-08-30 15:02:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:02:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:02:43 +03:00 --- debug: Database Library initialized
2013-08-30 15:02:43 +03:00 --- debug: Session Library initialized
2013-08-30 15:02:43 +03:00 --- debug: Auth Library loaded
2013-08-30 15:03:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:03:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:03:05 +03:00 --- debug: Database Library initialized
2013-08-30 15:03:05 +03:00 --- debug: Session Library initialized
2013-08-30 15:03:05 +03:00 --- debug: Auth Library loaded
2013-08-30 15:03:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:03:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:03:39 +03:00 --- debug: Database Library initialized
2013-08-30 15:03:39 +03:00 --- debug: Session Library initialized
2013-08-30 15:03:39 +03:00 --- debug: Auth Library loaded
2013-08-30 15:03:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:03:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:03:47 +03:00 --- debug: Database Library initialized
2013-08-30 15:03:47 +03:00 --- debug: Session Library initialized
2013-08-30 15:03:47 +03:00 --- debug: Auth Library loaded
2013-08-30 15:04:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:04:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:04:26 +03:00 --- debug: Database Library initialized
2013-08-30 15:04:26 +03:00 --- debug: Session Library initialized
2013-08-30 15:04:26 +03:00 --- debug: Auth Library loaded
2013-08-30 15:04:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:04:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:04:33 +03:00 --- debug: Database Library initialized
2013-08-30 15:04:33 +03:00 --- debug: Session Library initialized
2013-08-30 15:04:33 +03:00 --- debug: Auth Library loaded
2013-08-30 15:04:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:04:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:04:36 +03:00 --- debug: Database Library initialized
2013-08-30 15:04:36 +03:00 --- debug: Session Library initialized
2013-08-30 15:04:36 +03:00 --- debug: Auth Library loaded
2013-08-30 15:05:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:05:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:05:04 +03:00 --- debug: Database Library initialized
2013-08-30 15:05:04 +03:00 --- debug: Session Library initialized
2013-08-30 15:05:04 +03:00 --- debug: Auth Library loaded
2013-08-30 15:05:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:05:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:05:37 +03:00 --- debug: Database Library initialized
2013-08-30 15:05:37 +03:00 --- debug: Session Library initialized
2013-08-30 15:05:37 +03:00 --- debug: Auth Library loaded
2013-08-30 15:05:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:05:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:05:43 +03:00 --- debug: Database Library initialized
2013-08-30 15:05:43 +03:00 --- debug: Session Library initialized
2013-08-30 15:05:43 +03:00 --- debug: Auth Library loaded
2013-08-30 15:05:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:05:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:05:51 +03:00 --- debug: Database Library initialized
2013-08-30 15:05:51 +03:00 --- debug: Session Library initialized
2013-08-30 15:05:51 +03:00 --- debug: Auth Library loaded
2013-08-30 15:05:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:05:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:05:56 +03:00 --- debug: Database Library initialized
2013-08-30 15:05:56 +03:00 --- debug: Session Library initialized
2013-08-30 15:05:56 +03:00 --- debug: Auth Library loaded
2013-08-30 15:05:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:05:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:05:57 +03:00 --- debug: Database Library initialized
2013-08-30 15:05:57 +03:00 --- debug: Session Library initialized
2013-08-30 15:05:57 +03:00 --- debug: Auth Library loaded
2013-08-30 15:05:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:05:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:05:58 +03:00 --- debug: Database Library initialized
2013-08-30 15:05:58 +03:00 --- debug: Session Library initialized
2013-08-30 15:05:58 +03:00 --- debug: Auth Library loaded
2013-08-30 15:05:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:05:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:05:59 +03:00 --- debug: Database Library initialized
2013-08-30 15:05:59 +03:00 --- debug: Session Library initialized
2013-08-30 15:05:59 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:00 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:00 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:00 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:01 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:01 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:01 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:02 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:02 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:02 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:02 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:02 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:02 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:03 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:03 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:03 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:05 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:05 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:05 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:12 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:12 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:12 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:13 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:13 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:13 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:31 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:31 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:31 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:31 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:31 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:33 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:33 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:33 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:35 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:35 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:35 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:37 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:37 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:37 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:50 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:50 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:50 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:51 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:51 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:51 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:53 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:53 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:53 +03:00 --- debug: Auth Library loaded
2013-08-30 15:06:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:06:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:06:53 +03:00 --- debug: Database Library initialized
2013-08-30 15:06:53 +03:00 --- debug: Session Library initialized
2013-08-30 15:06:53 +03:00 --- debug: Auth Library loaded
2013-08-30 15:07:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:07:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:07:18 +03:00 --- debug: Database Library initialized
2013-08-30 15:07:18 +03:00 --- debug: Session Library initialized
2013-08-30 15:07:18 +03:00 --- debug: Auth Library loaded
2013-08-30 15:07:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:07:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:07:20 +03:00 --- debug: Database Library initialized
2013-08-30 15:07:20 +03:00 --- debug: Session Library initialized
2013-08-30 15:07:20 +03:00 --- debug: Auth Library loaded
2013-08-30 15:10:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:10:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:10:44 +03:00 --- debug: Database Library initialized
2013-08-30 15:10:44 +03:00 --- debug: Session Library initialized
2013-08-30 15:10:44 +03:00 --- debug: Auth Library loaded
2013-08-30 15:10:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:10:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:10:45 +03:00 --- debug: Database Library initialized
2013-08-30 15:10:45 +03:00 --- debug: Session Library initialized
2013-08-30 15:10:45 +03:00 --- debug: Auth Library loaded
2013-08-30 15:10:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:10:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:10:47 +03:00 --- debug: Database Library initialized
2013-08-30 15:10:47 +03:00 --- debug: Session Library initialized
2013-08-30 15:10:47 +03:00 --- debug: Auth Library loaded
2013-08-30 15:10:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:10:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:10:47 +03:00 --- debug: Database Library initialized
2013-08-30 15:10:47 +03:00 --- debug: Session Library initialized
2013-08-30 15:10:47 +03:00 --- debug: Auth Library loaded
2013-08-30 15:11:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:11:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:11:38 +03:00 --- debug: Database Library initialized
2013-08-30 15:11:38 +03:00 --- debug: Session Library initialized
2013-08-30 15:11:38 +03:00 --- debug: Auth Library loaded
2013-08-30 15:11:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:11:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:11:39 +03:00 --- debug: Database Library initialized
2013-08-30 15:11:39 +03:00 --- debug: Session Library initialized
2013-08-30 15:11:39 +03:00 --- debug: Auth Library loaded
2013-08-30 15:11:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:11:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:11:39 +03:00 --- debug: Database Library initialized
2013-08-30 15:11:39 +03:00 --- debug: Session Library initialized
2013-08-30 15:11:39 +03:00 --- debug: Auth Library loaded
2013-08-30 15:11:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:11:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:11:41 +03:00 --- debug: Database Library initialized
2013-08-30 15:11:41 +03:00 --- debug: Session Library initialized
2013-08-30 15:11:41 +03:00 --- debug: Auth Library loaded
2013-08-30 15:11:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:11:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:11:41 +03:00 --- debug: Database Library initialized
2013-08-30 15:11:41 +03:00 --- debug: Session Library initialized
2013-08-30 15:11:41 +03:00 --- debug: Auth Library loaded
2013-08-30 15:11:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:11:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:11:42 +03:00 --- debug: Database Library initialized
2013-08-30 15:11:42 +03:00 --- debug: Session Library initialized
2013-08-30 15:11:42 +03:00 --- debug: Auth Library loaded
2013-08-30 15:11:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:11:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:11:42 +03:00 --- debug: Database Library initialized
2013-08-30 15:11:42 +03:00 --- debug: Session Library initialized
2013-08-30 15:11:42 +03:00 --- debug: Auth Library loaded
2013-08-30 15:13:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:13:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:13:57 +03:00 --- debug: Database Library initialized
2013-08-30 15:13:57 +03:00 --- debug: Session Library initialized
2013-08-30 15:13:57 +03:00 --- debug: Auth Library loaded
2013-08-30 15:14:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:14:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:14:22 +03:00 --- debug: Database Library initialized
2013-08-30 15:14:22 +03:00 --- debug: Session Library initialized
2013-08-30 15:14:22 +03:00 --- debug: Auth Library loaded
2013-08-30 15:14:25 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:14:25 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:14:25 +03:00 --- debug: Database Library initialized
2013-08-30 15:14:25 +03:00 --- debug: Session Library initialized
2013-08-30 15:14:25 +03:00 --- debug: Auth Library loaded
2013-08-30 15:14:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:14:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:14:26 +03:00 --- debug: Database Library initialized
2013-08-30 15:14:26 +03:00 --- debug: Session Library initialized
2013-08-30 15:14:26 +03:00 --- debug: Auth Library loaded
2013-08-30 15:14:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:14:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:14:40 +03:00 --- debug: Database Library initialized
2013-08-30 15:14:40 +03:00 --- debug: Session Library initialized
2013-08-30 15:14:40 +03:00 --- debug: Auth Library loaded
2013-08-30 15:19:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:19:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:19:40 +03:00 --- debug: Database Library initialized
2013-08-30 15:19:40 +03:00 --- debug: Session Library initialized
2013-08-30 15:19:40 +03:00 --- debug: Auth Library loaded
2013-08-30 15:19:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:19:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:19:40 +03:00 --- debug: Database Library initialized
2013-08-30 15:19:40 +03:00 --- debug: Session Library initialized
2013-08-30 15:19:40 +03:00 --- debug: Auth Library loaded
2013-08-30 15:19:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:19:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:19:44 +03:00 --- debug: Database Library initialized
2013-08-30 15:19:44 +03:00 --- debug: Session Library initialized
2013-08-30 15:19:44 +03:00 --- debug: Auth Library loaded
2013-08-30 15:19:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:19:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:19:44 +03:00 --- debug: Database Library initialized
2013-08-30 15:19:44 +03:00 --- debug: Session Library initialized
2013-08-30 15:19:44 +03:00 --- debug: Auth Library loaded
2013-08-30 15:19:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:19:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:19:54 +03:00 --- debug: Database Library initialized
2013-08-30 15:19:54 +03:00 --- debug: Session Library initialized
2013-08-30 15:19:54 +03:00 --- debug: Auth Library loaded
2013-08-30 15:19:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:19:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:19:54 +03:00 --- debug: Database Library initialized
2013-08-30 15:19:54 +03:00 --- debug: Session Library initialized
2013-08-30 15:19:54 +03:00 --- debug: Auth Library loaded
2013-08-30 15:19:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:19:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:19:57 +03:00 --- debug: Database Library initialized
2013-08-30 15:19:57 +03:00 --- debug: Session Library initialized
2013-08-30 15:19:57 +03:00 --- debug: Auth Library loaded
2013-08-30 15:19:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:19:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:19:57 +03:00 --- debug: Database Library initialized
2013-08-30 15:19:57 +03:00 --- debug: Session Library initialized
2013-08-30 15:19:57 +03:00 --- debug: Auth Library loaded
2013-08-30 15:20:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:20:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:20:06 +03:00 --- debug: Database Library initialized
2013-08-30 15:20:06 +03:00 --- debug: Session Library initialized
2013-08-30 15:20:06 +03:00 --- debug: Auth Library loaded
2013-08-30 15:20:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:20:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:20:07 +03:00 --- debug: Database Library initialized
2013-08-30 15:20:07 +03:00 --- debug: Session Library initialized
2013-08-30 15:20:07 +03:00 --- debug: Auth Library loaded
2013-08-30 15:20:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:20:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:20:09 +03:00 --- debug: Database Library initialized
2013-08-30 15:20:09 +03:00 --- debug: Session Library initialized
2013-08-30 15:20:09 +03:00 --- debug: Auth Library loaded
2013-08-30 15:20:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:20:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:20:09 +03:00 --- debug: Database Library initialized
2013-08-30 15:20:09 +03:00 --- debug: Session Library initialized
2013-08-30 15:20:09 +03:00 --- debug: Auth Library loaded
2013-08-30 15:22:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:22:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:22:28 +03:00 --- debug: Database Library initialized
2013-08-30 15:22:29 +03:00 --- debug: Session Library initialized
2013-08-30 15:22:29 +03:00 --- debug: Auth Library loaded
2013-08-30 15:22:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:22:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:22:29 +03:00 --- debug: Database Library initialized
2013-08-30 15:22:29 +03:00 --- debug: Session Library initialized
2013-08-30 15:22:29 +03:00 --- debug: Auth Library loaded
2013-08-30 15:22:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:22:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:22:47 +03:00 --- debug: Database Library initialized
2013-08-30 15:22:47 +03:00 --- debug: Session Library initialized
2013-08-30 15:22:47 +03:00 --- debug: Auth Library loaded
2013-08-30 15:22:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:22:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:22:59 +03:00 --- debug: Database Library initialized
2013-08-30 15:22:59 +03:00 --- debug: Session Library initialized
2013-08-30 15:22:59 +03:00 --- debug: Auth Library loaded
2013-08-30 15:24:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:24:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:24:49 +03:00 --- debug: Database Library initialized
2013-08-30 15:24:49 +03:00 --- debug: Session Library initialized
2013-08-30 15:24:49 +03:00 --- debug: Auth Library loaded
2013-08-30 15:24:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:24:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:24:50 +03:00 --- debug: Database Library initialized
2013-08-30 15:24:50 +03:00 --- debug: Session Library initialized
2013-08-30 15:24:50 +03:00 --- debug: Auth Library loaded
2013-08-30 15:24:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:24:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:24:53 +03:00 --- debug: Database Library initialized
2013-08-30 15:24:53 +03:00 --- debug: Session Library initialized
2013-08-30 15:24:53 +03:00 --- debug: Auth Library loaded
2013-08-30 15:25:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:25:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:25:00 +03:00 --- debug: Database Library initialized
2013-08-30 15:25:00 +03:00 --- debug: Session Library initialized
2013-08-30 15:25:00 +03:00 --- debug: Auth Library loaded
2013-08-30 15:25:00 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:25:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:25:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:25:00 +03:00 --- debug: Database Library initialized
2013-08-30 15:25:00 +03:00 --- debug: Session Library initialized
2013-08-30 15:25:00 +03:00 --- debug: Auth Library loaded
2013-08-30 15:25:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:25:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:25:42 +03:00 --- debug: Database Library initialized
2013-08-30 15:25:42 +03:00 --- debug: Session Library initialized
2013-08-30 15:25:42 +03:00 --- debug: Auth Library loaded
2013-08-30 15:25:42 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:25:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:25:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:25:43 +03:00 --- debug: Database Library initialized
2013-08-30 15:25:43 +03:00 --- debug: Session Library initialized
2013-08-30 15:25:43 +03:00 --- debug: Auth Library loaded
2013-08-30 15:27:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:27:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:27:34 +03:00 --- debug: Database Library initialized
2013-08-30 15:27:34 +03:00 --- debug: Session Library initialized
2013-08-30 15:27:34 +03:00 --- debug: Auth Library loaded
2013-08-30 15:27:34 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:27:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:27:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:27:34 +03:00 --- debug: Database Library initialized
2013-08-30 15:27:34 +03:00 --- debug: Session Library initialized
2013-08-30 15:27:34 +03:00 --- debug: Auth Library loaded
2013-08-30 15:27:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:27:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:27:59 +03:00 --- debug: Database Library initialized
2013-08-30 15:27:59 +03:00 --- debug: Session Library initialized
2013-08-30 15:27:59 +03:00 --- debug: Auth Library loaded
2013-08-30 15:27:59 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:28:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:28:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:28:00 +03:00 --- debug: Database Library initialized
2013-08-30 15:28:00 +03:00 --- debug: Session Library initialized
2013-08-30 15:28:00 +03:00 --- debug: Auth Library loaded
2013-08-30 15:28:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:28:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:28:17 +03:00 --- debug: Database Library initialized
2013-08-30 15:28:17 +03:00 --- debug: Session Library initialized
2013-08-30 15:28:17 +03:00 --- debug: Auth Library loaded
2013-08-30 15:28:17 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:28:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:28:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:28:17 +03:00 --- debug: Database Library initialized
2013-08-30 15:28:17 +03:00 --- debug: Session Library initialized
2013-08-30 15:28:17 +03:00 --- debug: Auth Library loaded
2013-08-30 15:28:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:28:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:28:27 +03:00 --- debug: Database Library initialized
2013-08-30 15:28:27 +03:00 --- debug: Session Library initialized
2013-08-30 15:28:27 +03:00 --- debug: Auth Library loaded
2013-08-30 15:28:27 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:28:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:28:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:28:28 +03:00 --- debug: Database Library initialized
2013-08-30 15:28:28 +03:00 --- debug: Session Library initialized
2013-08-30 15:28:28 +03:00 --- debug: Auth Library loaded
2013-08-30 15:31:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:31:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:31:12 +03:00 --- debug: Database Library initialized
2013-08-30 15:31:12 +03:00 --- debug: Session Library initialized
2013-08-30 15:31:12 +03:00 --- debug: Auth Library loaded
2013-08-30 15:31:12 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:31:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:31:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:31:12 +03:00 --- debug: Database Library initialized
2013-08-30 15:31:12 +03:00 --- debug: Session Library initialized
2013-08-30 15:31:12 +03:00 --- debug: Auth Library loaded
2013-08-30 15:31:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:31:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:31:21 +03:00 --- debug: Database Library initialized
2013-08-30 15:31:21 +03:00 --- debug: Session Library initialized
2013-08-30 15:31:21 +03:00 --- debug: Auth Library loaded
2013-08-30 15:31:22 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:31:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:31:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:31:22 +03:00 --- debug: Database Library initialized
2013-08-30 15:31:22 +03:00 --- debug: Session Library initialized
2013-08-30 15:31:22 +03:00 --- debug: Auth Library loaded
2013-08-30 15:31:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:31:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:31:41 +03:00 --- debug: Database Library initialized
2013-08-30 15:31:42 +03:00 --- debug: Session Library initialized
2013-08-30 15:31:42 +03:00 --- debug: Auth Library loaded
2013-08-30 15:31:42 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:31:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:31:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:31:42 +03:00 --- debug: Database Library initialized
2013-08-30 15:31:42 +03:00 --- debug: Session Library initialized
2013-08-30 15:31:42 +03:00 --- debug: Auth Library loaded
2013-08-30 15:31:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:31:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:31:49 +03:00 --- debug: Database Library initialized
2013-08-30 15:31:49 +03:00 --- debug: Session Library initialized
2013-08-30 15:31:49 +03:00 --- debug: Auth Library loaded
2013-08-30 15:32:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:32:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:32:19 +03:00 --- debug: Database Library initialized
2013-08-30 15:32:19 +03:00 --- debug: Session Library initialized
2013-08-30 15:32:19 +03:00 --- debug: Auth Library loaded
2013-08-30 15:32:19 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:32:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:32:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:32:20 +03:00 --- debug: Database Library initialized
2013-08-30 15:32:20 +03:00 --- debug: Session Library initialized
2013-08-30 15:32:20 +03:00 --- debug: Auth Library loaded
2013-08-30 15:32:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:32:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:32:21 +03:00 --- debug: Database Library initialized
2013-08-30 15:32:21 +03:00 --- debug: Session Library initialized
2013-08-30 15:32:21 +03:00 --- debug: Auth Library loaded
2013-08-30 15:32:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:32:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:32:22 +03:00 --- debug: Database Library initialized
2013-08-30 15:32:22 +03:00 --- debug: Session Library initialized
2013-08-30 15:32:22 +03:00 --- debug: Auth Library loaded
2013-08-30 15:32:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:32:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:32:22 +03:00 --- debug: Database Library initialized
2013-08-30 15:32:22 +03:00 --- debug: Session Library initialized
2013-08-30 15:32:22 +03:00 --- debug: Auth Library loaded
2013-08-30 15:32:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:32:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:32:29 +03:00 --- debug: Database Library initialized
2013-08-30 15:32:29 +03:00 --- debug: Session Library initialized
2013-08-30 15:32:29 +03:00 --- debug: Auth Library loaded
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: core.uncaught_exception
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 15:32:29 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 15:34:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:34:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:34:07 +03:00 --- debug: Database Library initialized
2013-08-30 15:34:07 +03:00 --- debug: Session Library initialized
2013-08-30 15:34:07 +03:00 --- debug: Auth Library loaded
2013-08-30 15:34:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:34:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:34:58 +03:00 --- debug: Database Library initialized
2013-08-30 15:34:58 +03:00 --- debug: Session Library initialized
2013-08-30 15:34:58 +03:00 --- debug: Auth Library loaded
2013-08-30 15:34:58 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:34:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:34:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:34:58 +03:00 --- debug: Database Library initialized
2013-08-30 15:34:58 +03:00 --- debug: Session Library initialized
2013-08-30 15:34:58 +03:00 --- debug: Auth Library loaded
2013-08-30 15:35:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:35:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:35:07 +03:00 --- debug: Database Library initialized
2013-08-30 15:35:07 +03:00 --- debug: Session Library initialized
2013-08-30 15:35:07 +03:00 --- debug: Auth Library loaded
2013-08-30 15:35:07 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:35:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:35:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:35:08 +03:00 --- debug: Database Library initialized
2013-08-30 15:35:08 +03:00 --- debug: Session Library initialized
2013-08-30 15:35:08 +03:00 --- debug: Auth Library loaded
2013-08-30 15:35:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:35:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:35:16 +03:00 --- debug: Database Library initialized
2013-08-30 15:35:16 +03:00 --- debug: Session Library initialized
2013-08-30 15:35:16 +03:00 --- debug: Auth Library loaded
2013-08-30 15:37:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:37:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:37:16 +03:00 --- debug: Database Library initialized
2013-08-30 15:37:16 +03:00 --- debug: Session Library initialized
2013-08-30 15:37:16 +03:00 --- debug: Auth Library loaded
2013-08-30 15:37:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:37:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:37:16 +03:00 --- debug: Database Library initialized
2013-08-30 15:37:16 +03:00 --- debug: Session Library initialized
2013-08-30 15:37:16 +03:00 --- debug: Auth Library loaded
2013-08-30 15:37:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:37:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:37:17 +03:00 --- debug: Database Library initialized
2013-08-30 15:37:17 +03:00 --- debug: Session Library initialized
2013-08-30 15:37:17 +03:00 --- debug: Auth Library loaded
2013-08-30 15:37:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:37:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:37:17 +03:00 --- debug: Database Library initialized
2013-08-30 15:37:17 +03:00 --- debug: Session Library initialized
2013-08-30 15:37:17 +03:00 --- debug: Auth Library loaded
2013-08-30 15:37:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:37:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:37:28 +03:00 --- debug: Database Library initialized
2013-08-30 15:37:28 +03:00 --- debug: Session Library initialized
2013-08-30 15:37:28 +03:00 --- debug: Auth Library loaded
2013-08-30 15:37:52 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:37:52 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:37:52 +03:00 --- debug: Database Library initialized
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: core.uncaught_exception
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 15:37:52 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 15:38:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:38:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:38:27 +03:00 --- debug: Database Library initialized
2013-08-30 15:38:27 +03:00 --- debug: Session Library initialized
2013-08-30 15:38:27 +03:00 --- debug: Auth Library loaded
2013-08-30 15:38:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:38:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:38:28 +03:00 --- debug: Database Library initialized
2013-08-30 15:38:28 +03:00 --- debug: Session Library initialized
2013-08-30 15:38:28 +03:00 --- debug: Auth Library loaded
2013-08-30 15:38:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:38:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:38:40 +03:00 --- debug: Database Library initialized
2013-08-30 15:38:40 +03:00 --- debug: Session Library initialized
2013-08-30 15:38:40 +03:00 --- debug: Auth Library loaded
2013-08-30 15:39:00 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:39:00 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:39:00 +03:00 --- debug: Database Library initialized
2013-08-30 15:39:00 +03:00 --- debug: Session Library initialized
2013-08-30 15:39:00 +03:00 --- debug: Auth Library loaded
2013-08-30 15:39:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:39:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:39:04 +03:00 --- debug: Database Library initialized
2013-08-30 15:39:04 +03:00 --- debug: Session Library initialized
2013-08-30 15:39:04 +03:00 --- debug: Auth Library loaded
2013-08-30 15:40:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:40:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:40:46 +03:00 --- debug: Database Library initialized
2013-08-30 15:40:46 +03:00 --- debug: Session Library initialized
2013-08-30 15:40:46 +03:00 --- debug: Auth Library loaded
2013-08-30 15:41:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:41:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:41:03 +03:00 --- debug: Database Library initialized
2013-08-30 15:41:03 +03:00 --- debug: Session Library initialized
2013-08-30 15:41:03 +03:00 --- debug: Auth Library loaded
2013-08-30 15:41:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:41:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:41:07 +03:00 --- debug: Database Library initialized
2013-08-30 15:41:07 +03:00 --- debug: Session Library initialized
2013-08-30 15:41:07 +03:00 --- debug: Auth Library loaded
2013-08-30 15:41:19 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:41:19 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:41:19 +03:00 --- debug: Database Library initialized
2013-08-30 15:41:19 +03:00 --- debug: Session Library initialized
2013-08-30 15:41:19 +03:00 --- debug: Auth Library loaded
2013-08-30 15:41:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:41:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:41:21 +03:00 --- debug: Database Library initialized
2013-08-30 15:41:21 +03:00 --- debug: Session Library initialized
2013-08-30 15:41:21 +03:00 --- debug: Auth Library loaded
2013-08-30 15:41:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:41:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:41:23 +03:00 --- debug: Database Library initialized
2013-08-30 15:41:23 +03:00 --- debug: Session Library initialized
2013-08-30 15:41:23 +03:00 --- debug: Auth Library loaded
2013-08-30 15:41:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:41:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:41:44 +03:00 --- debug: Database Library initialized
2013-08-30 15:41:44 +03:00 --- debug: Session Library initialized
2013-08-30 15:41:44 +03:00 --- debug: Auth Library loaded
2013-08-30 15:41:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:41:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:41:44 +03:00 --- debug: Database Library initialized
2013-08-30 15:41:44 +03:00 --- debug: Session Library initialized
2013-08-30 15:41:44 +03:00 --- debug: Auth Library loaded
2013-08-30 15:41:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:41:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:41:49 +03:00 --- debug: Database Library initialized
2013-08-30 15:41:49 +03:00 --- debug: Session Library initialized
2013-08-30 15:41:49 +03:00 --- debug: Auth Library loaded
2013-08-30 15:46:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:46:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:46:41 +03:00 --- debug: Database Library initialized
2013-08-30 15:46:41 +03:00 --- debug: Session Library initialized
2013-08-30 15:46:41 +03:00 --- debug: Auth Library loaded
2013-08-30 15:46:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:46:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:46:54 +03:00 --- debug: Database Library initialized
2013-08-30 15:46:54 +03:00 --- debug: Session Library initialized
2013-08-30 15:46:54 +03:00 --- debug: Auth Library loaded
2013-08-30 15:47:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:47:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:47:05 +03:00 --- debug: Database Library initialized
2013-08-30 15:47:05 +03:00 --- debug: Session Library initialized
2013-08-30 15:47:05 +03:00 --- debug: Auth Library loaded
2013-08-30 15:47:05 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:47:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:47:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:47:05 +03:00 --- debug: Database Library initialized
2013-08-30 15:47:05 +03:00 --- debug: Session Library initialized
2013-08-30 15:47:05 +03:00 --- debug: Auth Library loaded
2013-08-30 15:47:05 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:47:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:47:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:47:38 +03:00 --- debug: Database Library initialized
2013-08-30 15:47:38 +03:00 --- debug: Session Library initialized
2013-08-30 15:47:38 +03:00 --- debug: Auth Library loaded
2013-08-30 15:47:38 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:47:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:47:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:47:49 +03:00 --- debug: Database Library initialized
2013-08-30 15:47:49 +03:00 --- debug: Session Library initialized
2013-08-30 15:47:49 +03:00 --- debug: Auth Library loaded
2013-08-30 15:47:49 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: core.uncaught_exception
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 15:47:51 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 15:52:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:52:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:52:10 +03:00 --- debug: Database Library initialized
2013-08-30 15:52:10 +03:00 --- debug: Session Library initialized
2013-08-30 15:52:10 +03:00 --- debug: Auth Library loaded
2013-08-30 15:52:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:52:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:52:13 +03:00 --- debug: Database Library initialized
2013-08-30 15:52:13 +03:00 --- debug: Session Library initialized
2013-08-30 15:52:13 +03:00 --- debug: Auth Library loaded
2013-08-30 15:52:13 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:52:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:52:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:52:13 +03:00 --- debug: Database Library initialized
2013-08-30 15:52:13 +03:00 --- debug: Session Library initialized
2013-08-30 15:52:13 +03:00 --- debug: Auth Library loaded
2013-08-30 15:52:13 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:52:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:52:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:52:48 +03:00 --- debug: Database Library initialized
2013-08-30 15:52:48 +03:00 --- debug: Session Library initialized
2013-08-30 15:52:48 +03:00 --- debug: Auth Library loaded
2013-08-30 15:52:48 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:52:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:52:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:52:53 +03:00 --- debug: Database Library initialized
2013-08-30 15:52:53 +03:00 --- debug: Session Library initialized
2013-08-30 15:52:53 +03:00 --- debug: Auth Library loaded
2013-08-30 15:52:53 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:52:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:52:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:52:59 +03:00 --- debug: Database Library initialized
2013-08-30 15:52:59 +03:00 --- debug: Session Library initialized
2013-08-30 15:52:59 +03:00 --- debug: Auth Library loaded
2013-08-30 15:52:59 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:53:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:53:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:53:13 +03:00 --- debug: Database Library initialized
2013-08-30 15:53:13 +03:00 --- debug: Session Library initialized
2013-08-30 15:53:13 +03:00 --- debug: Auth Library loaded
2013-08-30 15:53:13 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:53:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:53:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:53:17 +03:00 --- debug: Database Library initialized
2013-08-30 15:53:17 +03:00 --- debug: Session Library initialized
2013-08-30 15:53:17 +03:00 --- debug: Auth Library loaded
2013-08-30 15:53:18 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:53:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:53:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:53:27 +03:00 --- debug: Database Library initialized
2013-08-30 15:53:27 +03:00 --- debug: Session Library initialized
2013-08-30 15:53:27 +03:00 --- debug: Auth Library loaded
2013-08-30 15:53:27 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:54:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:54:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:54:02 +03:00 --- debug: Database Library initialized
2013-08-30 15:54:02 +03:00 --- debug: Session Library initialized
2013-08-30 15:54:02 +03:00 --- debug: Auth Library loaded
2013-08-30 15:54:02 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:54:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:54:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:54:04 +03:00 --- debug: Database Library initialized
2013-08-30 15:54:04 +03:00 --- debug: Session Library initialized
2013-08-30 15:54:04 +03:00 --- debug: Auth Library loaded
2013-08-30 15:54:05 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:54:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:54:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:54:11 +03:00 --- debug: Database Library initialized
2013-08-30 15:54:11 +03:00 --- debug: Session Library initialized
2013-08-30 15:54:11 +03:00 --- debug: Auth Library loaded
2013-08-30 15:54:11 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:54:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:54:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:54:20 +03:00 --- debug: Database Library initialized
2013-08-30 15:54:20 +03:00 --- debug: Session Library initialized
2013-08-30 15:54:20 +03:00 --- debug: Auth Library loaded
2013-08-30 15:54:20 +03:00 --- debug: Captcha Library initialized
2013-08-30 15:54:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:54:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:54:55 +03:00 --- debug: Database Library initialized
2013-08-30 15:54:55 +03:00 --- debug: Session Library initialized
2013-08-30 15:54:55 +03:00 --- debug: Auth Library loaded
2013-08-30 15:54:55 +03:00 --- error: Missing i18n entry admin.dashboard for language uk_UA
2013-08-30 15:54:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:54:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:54:56 +03:00 --- debug: Database Library initialized
2013-08-30 15:54:56 +03:00 --- debug: Session Library initialized
2013-08-30 15:54:56 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:02 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:02 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:02 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.view for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.resource_not_found for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: core.uncaught_exception
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 15:55:02 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 15:55:02 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:02 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:02 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:02 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:02 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:17 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:17 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:17 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:17 +03:00 --- error: Missing i18n entry admin.dashboard for language uk_UA
2013-08-30 15:55:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:18 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:18 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:18 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:21 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:21 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:21 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:21 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:55:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:22 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:22 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:22 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:38 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:38 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:38 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:38 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:55:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:39 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:39 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:39 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:40 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:40 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:40 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:41 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:55:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:41 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:41 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:41 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:43 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:43 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:43 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:43 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:55:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:43 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:43 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:43 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:45 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:45 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:45 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:45 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:55:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:45 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:45 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:45 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:48 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:48 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:48 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:49 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:49 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:49 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:49 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:55:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:49 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:49 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:49 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:53 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:53 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:53 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:54 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:55:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:54 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:54 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:54 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:55 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:55 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:55 +03:00 --- debug: Auth Library loaded
2013-08-30 15:55:56 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:55:56 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:55:56 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:55:56 +03:00 --- debug: Database Library initialized
2013-08-30 15:55:56 +03:00 --- debug: Session Library initialized
2013-08-30 15:55:56 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:06 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:06 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:06 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:07 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:07 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:07 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:07 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:07 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:07 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:07 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:10 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:10 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:10 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:10 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:10 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:10 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:10 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:10 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:10 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:10 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:12 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:12 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:12 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:13 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:13 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:13 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:13 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:13 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:13 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:14 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:14 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:14 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:14 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:14 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:16 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:16 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:16 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:16 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:16 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:16 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:16 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:17 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:17 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:17 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:20 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:20 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:20 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:20 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:20 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:20 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:20 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:21 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:21 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:21 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:23 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:23 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:23 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:23 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:23 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:23 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:23 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:24 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:24 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:24 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:26 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:26 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:26 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:26 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:26 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:26 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:27 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:27 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:27 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:27 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:29 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:29 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:29 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:29 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:29 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:30 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:30 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:30 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:30 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:30 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:30 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:30 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:34 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:34 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:34 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:34 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:34 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:34 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:34 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:35 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:35 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:35 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:39 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:39 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:39 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:39 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:39 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:39 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:39 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:42 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:42 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:42 +03:00 --- debug: Auth Library loaded
2013-08-30 15:56:42 +03:00 --- debug: Pagination Library initialized
2013-08-30 15:56:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 15:56:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 15:56:43 +03:00 --- debug: Database Library initialized
2013-08-30 15:56:43 +03:00 --- debug: Session Library initialized
2013-08-30 15:56:43 +03:00 --- debug: Auth Library loaded
2013-08-30 16:03:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:03:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:03:46 +03:00 --- debug: Database Library initialized
2013-08-30 16:03:46 +03:00 --- debug: Session Library initialized
2013-08-30 16:03:46 +03:00 --- debug: Auth Library loaded
2013-08-30 16:03:46 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:03:46 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:03:46 +03:00 --- debug: Database Library initialized
2013-08-30 16:03:46 +03:00 --- debug: Session Library initialized
2013-08-30 16:03:46 +03:00 --- debug: Auth Library loaded
2013-08-30 16:04:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:04:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:04:11 +03:00 --- debug: Database Library initialized
2013-08-30 16:04:11 +03:00 --- debug: Session Library initialized
2013-08-30 16:04:11 +03:00 --- debug: Auth Library loaded
2013-08-30 16:05:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:05:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:05:01 +03:00 --- debug: Database Library initialized
2013-08-30 16:05:01 +03:00 --- debug: Session Library initialized
2013-08-30 16:05:01 +03:00 --- debug: Auth Library loaded
2013-08-30 16:05:01 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-30 16:05:01 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 16:05:01 +03:00 --- error: core.uncaught_exception
2013-08-30 16:05:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:05:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:05:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:05:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:05:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:05:01 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:05:01 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 16:05:01 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 16:05:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:05:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:05:01 +03:00 --- debug: Database Library initialized
2013-08-30 16:05:01 +03:00 --- debug: Session Library initialized
2013-08-30 16:05:01 +03:00 --- debug: Auth Library loaded
2013-08-30 16:07:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:07:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:07:37 +03:00 --- debug: Database Library initialized
2013-08-30 16:07:37 +03:00 --- debug: Session Library initialized
2013-08-30 16:07:37 +03:00 --- debug: Auth Library loaded
2013-08-30 16:07:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:07:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:07:37 +03:00 --- debug: Database Library initialized
2013-08-30 16:07:37 +03:00 --- debug: Session Library initialized
2013-08-30 16:07:37 +03:00 --- debug: Auth Library loaded
2013-08-30 16:07:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:07:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:07:47 +03:00 --- debug: Database Library initialized
2013-08-30 16:07:47 +03:00 --- debug: Session Library initialized
2013-08-30 16:07:47 +03:00 --- debug: Auth Library loaded
2013-08-30 16:07:48 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:07:48 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:07:48 +03:00 --- debug: Database Library initialized
2013-08-30 16:07:48 +03:00 --- debug: Session Library initialized
2013-08-30 16:07:48 +03:00 --- debug: Auth Library loaded
2013-08-30 16:08:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:08:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:08:09 +03:00 --- debug: Database Library initialized
2013-08-30 16:08:09 +03:00 --- debug: Session Library initialized
2013-08-30 16:08:09 +03:00 --- debug: Auth Library loaded
2013-08-30 16:08:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:08:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:08:09 +03:00 --- debug: Database Library initialized
2013-08-30 16:08:09 +03:00 --- debug: Session Library initialized
2013-08-30 16:08:09 +03:00 --- debug: Auth Library loaded
2013-08-30 16:08:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:08:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:08:10 +03:00 --- debug: Database Library initialized
2013-08-30 16:08:10 +03:00 --- debug: Session Library initialized
2013-08-30 16:08:10 +03:00 --- debug: Auth Library loaded
2013-08-30 16:08:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:08:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:08:11 +03:00 --- debug: Database Library initialized
2013-08-30 16:08:11 +03:00 --- debug: Session Library initialized
2013-08-30 16:08:11 +03:00 --- debug: Auth Library loaded
2013-08-30 16:08:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:08:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:08:32 +03:00 --- debug: Database Library initialized
2013-08-30 16:08:32 +03:00 --- debug: Session Library initialized
2013-08-30 16:08:32 +03:00 --- debug: Auth Library loaded
2013-08-30 16:08:32 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:08:32 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:08:32 +03:00 --- debug: Database Library initialized
2013-08-30 16:08:32 +03:00 --- debug: Session Library initialized
2013-08-30 16:08:32 +03:00 --- debug: Auth Library loaded
2013-08-30 16:08:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:08:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:08:57 +03:00 --- debug: Database Library initialized
2013-08-30 16:08:57 +03:00 --- debug: Session Library initialized
2013-08-30 16:08:57 +03:00 --- debug: Auth Library loaded
2013-08-30 16:08:58 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:08:58 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:08:58 +03:00 --- debug: Database Library initialized
2013-08-30 16:08:58 +03:00 --- debug: Session Library initialized
2013-08-30 16:08:58 +03:00 --- debug: Auth Library loaded
2013-08-30 16:08:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:08:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:08:59 +03:00 --- debug: Database Library initialized
2013-08-30 16:08:59 +03:00 --- debug: Session Library initialized
2013-08-30 16:08:59 +03:00 --- debug: Auth Library loaded
2013-08-30 16:09:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:09:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:09:11 +03:00 --- debug: Database Library initialized
2013-08-30 16:09:11 +03:00 --- debug: Session Library initialized
2013-08-30 16:09:11 +03:00 --- debug: Auth Library loaded
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.invalid_method for language uk_UA
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 16:09:11 +03:00 --- error: core.uncaught_exception
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 16:09:11 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 16:09:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:09:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:09:11 +03:00 --- debug: Database Library initialized
2013-08-30 16:09:11 +03:00 --- debug: Session Library initialized
2013-08-30 16:09:11 +03:00 --- debug: Auth Library loaded
2013-08-30 16:09:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:09:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:09:20 +03:00 --- debug: Database Library initialized
2013-08-30 16:09:20 +03:00 --- debug: Session Library initialized
2013-08-30 16:09:20 +03:00 --- debug: Auth Library loaded
2013-08-30 16:09:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:09:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:09:21 +03:00 --- debug: Database Library initialized
2013-08-30 16:09:21 +03:00 --- debug: Session Library initialized
2013-08-30 16:09:21 +03:00 --- debug: Auth Library loaded
2013-08-30 16:09:22 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:09:22 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:09:22 +03:00 --- debug: Database Library initialized
2013-08-30 16:09:22 +03:00 --- debug: Session Library initialized
2013-08-30 16:09:22 +03:00 --- debug: Auth Library loaded
2013-08-30 16:09:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:09:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:09:44 +03:00 --- debug: Database Library initialized
2013-08-30 16:09:44 +03:00 --- debug: Session Library initialized
2013-08-30 16:09:44 +03:00 --- debug: Auth Library loaded
2013-08-30 16:09:45 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-30 16:09:45 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 16:09:45 +03:00 --- error: core.uncaught_exception
2013-08-30 16:09:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:45 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:09:45 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 16:09:45 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 16:09:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:09:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:09:45 +03:00 --- debug: Database Library initialized
2013-08-30 16:09:45 +03:00 --- debug: Session Library initialized
2013-08-30 16:09:45 +03:00 --- debug: Auth Library loaded
2013-08-30 16:12:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:12:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:12:44 +03:00 --- debug: Database Library initialized
2013-08-30 16:12:44 +03:00 --- debug: Session Library initialized
2013-08-30 16:12:44 +03:00 --- debug: Auth Library loaded
2013-08-30 16:12:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:12:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:12:44 +03:00 --- debug: Database Library initialized
2013-08-30 16:12:44 +03:00 --- debug: Session Library initialized
2013-08-30 16:12:44 +03:00 --- debug: Auth Library loaded
2013-08-30 16:12:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:12:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:12:47 +03:00 --- debug: Database Library initialized
2013-08-30 16:12:47 +03:00 --- debug: Session Library initialized
2013-08-30 16:12:47 +03:00 --- debug: Auth Library loaded
2013-08-30 16:12:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:12:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:12:50 +03:00 --- debug: Database Library initialized
2013-08-30 16:12:50 +03:00 --- debug: Session Library initialized
2013-08-30 16:12:50 +03:00 --- debug: Auth Library loaded
2013-08-30 16:12:50 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:12:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:12:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:12:50 +03:00 --- debug: Database Library initialized
2013-08-30 16:12:50 +03:00 --- debug: Session Library initialized
2013-08-30 16:12:50 +03:00 --- debug: Auth Library loaded
2013-08-30 16:12:50 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:13:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:13:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:13:07 +03:00 --- debug: Database Library initialized
2013-08-30 16:13:07 +03:00 --- debug: Session Library initialized
2013-08-30 16:13:07 +03:00 --- debug: Auth Library loaded
2013-08-30 16:13:08 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:14:26 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:14:26 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:14:26 +03:00 --- debug: Database Library initialized
2013-08-30 16:14:26 +03:00 --- debug: Session Library initialized
2013-08-30 16:14:26 +03:00 --- debug: Auth Library loaded
2013-08-30 16:15:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:15:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:15:05 +03:00 --- debug: Database Library initialized
2013-08-30 16:15:05 +03:00 --- debug: Session Library initialized
2013-08-30 16:15:05 +03:00 --- debug: Auth Library loaded
2013-08-30 16:15:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:15:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:15:24 +03:00 --- debug: Database Library initialized
2013-08-30 16:15:24 +03:00 --- debug: Session Library initialized
2013-08-30 16:15:24 +03:00 --- debug: Auth Library loaded
2013-08-30 16:17:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:17:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:17:10 +03:00 --- debug: Database Library initialized
2013-08-30 16:17:10 +03:00 --- debug: Session Library initialized
2013-08-30 16:17:10 +03:00 --- debug: Auth Library loaded
2013-08-30 16:17:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:17:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:17:54 +03:00 --- debug: Database Library initialized
2013-08-30 16:17:54 +03:00 --- debug: Session Library initialized
2013-08-30 16:17:54 +03:00 --- debug: Auth Library loaded
2013-08-30 16:19:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:19:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:19:09 +03:00 --- debug: Database Library initialized
2013-08-30 16:19:09 +03:00 --- debug: Session Library initialized
2013-08-30 16:19:09 +03:00 --- debug: Auth Library loaded
2013-08-30 16:19:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:19:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:19:11 +03:00 --- debug: Database Library initialized
2013-08-30 16:19:11 +03:00 --- debug: Session Library initialized
2013-08-30 16:19:11 +03:00 --- debug: Auth Library loaded
2013-08-30 16:19:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:19:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:19:12 +03:00 --- debug: Database Library initialized
2013-08-30 16:19:12 +03:00 --- debug: Session Library initialized
2013-08-30 16:19:12 +03:00 --- debug: Auth Library loaded
2013-08-30 16:19:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:19:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:19:27 +03:00 --- debug: Database Library initialized
2013-08-30 16:19:27 +03:00 --- debug: Session Library initialized
2013-08-30 16:19:27 +03:00 --- debug: Auth Library loaded
2013-08-30 16:19:27 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:19:27 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:19:27 +03:00 --- debug: Database Library initialized
2013-08-30 16:19:27 +03:00 --- debug: Session Library initialized
2013-08-30 16:19:27 +03:00 --- debug: Auth Library loaded
2013-08-30 16:19:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:19:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:19:49 +03:00 --- debug: Database Library initialized
2013-08-30 16:19:49 +03:00 --- debug: Session Library initialized
2013-08-30 16:19:49 +03:00 --- debug: Auth Library loaded
2013-08-30 16:19:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:19:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:19:50 +03:00 --- debug: Database Library initialized
2013-08-30 16:19:50 +03:00 --- debug: Session Library initialized
2013-08-30 16:19:50 +03:00 --- debug: Auth Library loaded
2013-08-30 16:19:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:19:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:19:57 +03:00 --- debug: Database Library initialized
2013-08-30 16:19:57 +03:00 --- debug: Session Library initialized
2013-08-30 16:19:57 +03:00 --- debug: Auth Library loaded
2013-08-30 16:19:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:19:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:19:57 +03:00 --- debug: Database Library initialized
2013-08-30 16:19:57 +03:00 --- debug: Session Library initialized
2013-08-30 16:19:57 +03:00 --- debug: Auth Library loaded
2013-08-30 16:21:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:21:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:21:01 +03:00 --- debug: Database Library initialized
2013-08-30 16:21:01 +03:00 --- debug: Session Library initialized
2013-08-30 16:21:01 +03:00 --- debug: Auth Library loaded
2013-08-30 16:21:01 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:21:01 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:21:01 +03:00 --- debug: Database Library initialized
2013-08-30 16:21:01 +03:00 --- debug: Session Library initialized
2013-08-30 16:21:01 +03:00 --- debug: Auth Library loaded
2013-08-30 16:21:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:21:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:21:15 +03:00 --- debug: Database Library initialized
2013-08-30 16:21:15 +03:00 --- debug: Session Library initialized
2013-08-30 16:21:15 +03:00 --- debug: Auth Library loaded
2013-08-30 16:21:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:21:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:21:15 +03:00 --- debug: Database Library initialized
2013-08-30 16:21:15 +03:00 --- debug: Session Library initialized
2013-08-30 16:21:15 +03:00 --- debug: Auth Library loaded
2013-08-30 16:21:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:21:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:21:39 +03:00 --- debug: Database Library initialized
2013-08-30 16:21:39 +03:00 --- debug: Session Library initialized
2013-08-30 16:21:39 +03:00 --- debug: Auth Library loaded
2013-08-30 16:21:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:21:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:21:39 +03:00 --- debug: Database Library initialized
2013-08-30 16:21:39 +03:00 --- debug: Session Library initialized
2013-08-30 16:21:39 +03:00 --- debug: Auth Library loaded
2013-08-30 16:21:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:21:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:21:50 +03:00 --- debug: Database Library initialized
2013-08-30 16:21:50 +03:00 --- debug: Session Library initialized
2013-08-30 16:21:50 +03:00 --- debug: Auth Library loaded
2013-08-30 16:22:18 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:22:18 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:22:18 +03:00 --- debug: Database Library initialized
2013-08-30 16:22:18 +03:00 --- debug: Session Library initialized
2013-08-30 16:22:18 +03:00 --- debug: Auth Library loaded
2013-08-30 16:22:37 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:22:37 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:22:37 +03:00 --- debug: Database Library initialized
2013-08-30 16:22:37 +03:00 --- debug: Session Library initialized
2013-08-30 16:22:37 +03:00 --- debug: Auth Library loaded
2013-08-30 16:22:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:22:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:22:54 +03:00 --- debug: Database Library initialized
2013-08-30 16:22:54 +03:00 --- debug: Session Library initialized
2013-08-30 16:22:54 +03:00 --- debug: Auth Library loaded
2013-08-30 16:23:03 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:23:03 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:23:03 +03:00 --- debug: Database Library initialized
2013-08-30 16:23:03 +03:00 --- debug: Session Library initialized
2013-08-30 16:23:03 +03:00 --- debug: Auth Library loaded
2013-08-30 16:23:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:23:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:23:34 +03:00 --- debug: Database Library initialized
2013-08-30 16:23:34 +03:00 --- debug: Session Library initialized
2013-08-30 16:23:34 +03:00 --- debug: Auth Library loaded
2013-08-30 16:23:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:23:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:23:50 +03:00 --- debug: Database Library initialized
2013-08-30 16:23:50 +03:00 --- debug: Session Library initialized
2013-08-30 16:23:50 +03:00 --- debug: Auth Library loaded
2013-08-30 16:23:51 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:23:51 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:23:51 +03:00 --- debug: Database Library initialized
2013-08-30 16:23:51 +03:00 --- debug: Session Library initialized
2013-08-30 16:23:51 +03:00 --- debug: Auth Library loaded
2013-08-30 16:23:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:23:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:23:54 +03:00 --- debug: Database Library initialized
2013-08-30 16:23:54 +03:00 --- debug: Session Library initialized
2013-08-30 16:23:54 +03:00 --- debug: Auth Library loaded
2013-08-30 16:24:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:24:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:24:35 +03:00 --- debug: Database Library initialized
2013-08-30 16:24:35 +03:00 --- debug: Session Library initialized
2013-08-30 16:24:35 +03:00 --- debug: Auth Library loaded
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: core.uncaught_exception
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 16:24:35 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 16:24:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:24:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:24:35 +03:00 --- debug: Database Library initialized
2013-08-30 16:24:35 +03:00 --- debug: Session Library initialized
2013-08-30 16:24:35 +03:00 --- debug: Auth Library loaded
2013-08-30 16:24:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:24:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:24:43 +03:00 --- debug: Database Library initialized
2013-08-30 16:24:43 +03:00 --- debug: Session Library initialized
2013-08-30 16:24:43 +03:00 --- debug: Auth Library loaded
2013-08-30 16:24:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:24:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:24:43 +03:00 --- debug: Database Library initialized
2013-08-30 16:24:43 +03:00 --- debug: Session Library initialized
2013-08-30 16:24:43 +03:00 --- debug: Auth Library loaded
2013-08-30 16:24:49 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:24:49 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:24:49 +03:00 --- debug: Database Library initialized
2013-08-30 16:24:49 +03:00 --- debug: Session Library initialized
2013-08-30 16:24:49 +03:00 --- debug: Auth Library loaded
2013-08-30 16:26:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:26:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:26:09 +03:00 --- debug: Database Library initialized
2013-08-30 16:26:09 +03:00 --- debug: Session Library initialized
2013-08-30 16:26:09 +03:00 --- debug: Auth Library loaded
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.invalid_property for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: core.uncaught_exception
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 16:26:09 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 16:26:09 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:26:09 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:26:09 +03:00 --- debug: Database Library initialized
2013-08-30 16:26:09 +03:00 --- debug: Session Library initialized
2013-08-30 16:26:09 +03:00 --- debug: Auth Library loaded
2013-08-30 16:26:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:26:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:26:20 +03:00 --- debug: Database Library initialized
2013-08-30 16:26:20 +03:00 --- debug: Session Library initialized
2013-08-30 16:26:20 +03:00 --- debug: Auth Library loaded
2013-08-30 16:26:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:26:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:26:33 +03:00 --- debug: Database Library initialized
2013-08-30 16:26:33 +03:00 --- debug: Session Library initialized
2013-08-30 16:26:33 +03:00 --- debug: Auth Library loaded
2013-08-30 16:27:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:27:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:27:44 +03:00 --- debug: Database Library initialized
2013-08-30 16:27:44 +03:00 --- debug: Session Library initialized
2013-08-30 16:27:44 +03:00 --- debug: Auth Library loaded
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: core.uncaught_exception
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 16:27:44 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 16:27:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:27:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:27:44 +03:00 --- debug: Database Library initialized
2013-08-30 16:27:44 +03:00 --- debug: Session Library initialized
2013-08-30 16:27:44 +03:00 --- debug: Auth Library loaded
2013-08-30 16:27:53 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:27:53 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:27:53 +03:00 --- debug: Database Library initialized
2013-08-30 16:27:53 +03:00 --- debug: Session Library initialized
2013-08-30 16:27:53 +03:00 --- debug: Auth Library loaded
2013-08-30 16:28:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:28:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:28:16 +03:00 --- debug: Database Library initialized
2013-08-30 16:28:16 +03:00 --- debug: Session Library initialized
2013-08-30 16:28:16 +03:00 --- debug: Auth Library loaded
2013-08-30 16:28:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:28:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:28:16 +03:00 --- debug: Database Library initialized
2013-08-30 16:28:16 +03:00 --- debug: Session Library initialized
2013-08-30 16:28:16 +03:00 --- debug: Auth Library loaded
2013-08-30 16:29:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:29:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:29:10 +03:00 --- debug: Database Library initialized
2013-08-30 16:29:10 +03:00 --- debug: Session Library initialized
2013-08-30 16:29:10 +03:00 --- debug: Auth Library loaded
2013-08-30 16:29:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:29:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:29:10 +03:00 --- debug: Database Library initialized
2013-08-30 16:29:10 +03:00 --- debug: Session Library initialized
2013-08-30 16:29:10 +03:00 --- debug: Auth Library loaded
2013-08-30 16:29:17 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:29:17 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:29:17 +03:00 --- debug: Database Library initialized
2013-08-30 16:29:17 +03:00 --- debug: Session Library initialized
2013-08-30 16:29:17 +03:00 --- debug: Auth Library loaded
2013-08-30 16:29:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:29:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:29:50 +03:00 --- debug: Database Library initialized
2013-08-30 16:29:50 +03:00 --- debug: Session Library initialized
2013-08-30 16:29:50 +03:00 --- debug: Auth Library loaded
2013-08-30 16:33:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:33:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:33:06 +03:00 --- debug: Database Library initialized
2013-08-30 16:33:06 +03:00 --- debug: Session Library initialized
2013-08-30 16:33:06 +03:00 --- debug: Auth Library loaded
2013-08-30 16:33:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:33:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:33:07 +03:00 --- debug: Database Library initialized
2013-08-30 16:33:07 +03:00 --- debug: Session Library initialized
2013-08-30 16:33:07 +03:00 --- debug: Auth Library loaded
2013-08-30 16:33:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:33:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:33:47 +03:00 --- debug: Database Library initialized
2013-08-30 16:33:47 +03:00 --- debug: Session Library initialized
2013-08-30 16:33:47 +03:00 --- debug: Auth Library loaded
2013-08-30 16:34:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:34:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:34:05 +03:00 --- debug: Database Library initialized
2013-08-30 16:34:05 +03:00 --- debug: Session Library initialized
2013-08-30 16:34:05 +03:00 --- debug: Auth Library loaded
2013-08-30 16:34:23 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:34:23 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:34:23 +03:00 --- debug: Database Library initialized
2013-08-30 16:34:23 +03:00 --- debug: Session Library initialized
2013-08-30 16:34:23 +03:00 --- debug: Auth Library loaded
2013-08-30 16:35:36 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:35:36 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:35:36 +03:00 --- debug: Database Library initialized
2013-08-30 16:35:36 +03:00 --- debug: Session Library initialized
2013-08-30 16:35:36 +03:00 --- debug: Auth Library loaded
2013-08-30 16:36:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:36:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:36:59 +03:00 --- debug: Database Library initialized
2013-08-30 16:36:59 +03:00 --- debug: Session Library initialized
2013-08-30 16:36:59 +03:00 --- debug: Auth Library loaded
2013-08-30 16:37:16 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:37:16 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:37:16 +03:00 --- debug: Database Library initialized
2013-08-30 16:37:16 +03:00 --- debug: Session Library initialized
2013-08-30 16:37:16 +03:00 --- debug: Auth Library loaded
2013-08-30 16:38:11 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:38:11 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:38:11 +03:00 --- debug: Database Library initialized
2013-08-30 16:38:11 +03:00 --- debug: Session Library initialized
2013-08-30 16:38:11 +03:00 --- debug: Auth Library loaded
2013-08-30 16:38:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:38:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:38:28 +03:00 --- debug: Database Library initialized
2013-08-30 16:38:28 +03:00 --- debug: Session Library initialized
2013-08-30 16:38:28 +03:00 --- debug: Auth Library loaded
2013-08-30 16:38:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:38:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:38:42 +03:00 --- debug: Database Library initialized
2013-08-30 16:38:42 +03:00 --- debug: Session Library initialized
2013-08-30 16:38:42 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:04 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:39:04 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:39:04 +03:00 --- debug: Database Library initialized
2013-08-30 16:39:04 +03:00 --- debug: Session Library initialized
2013-08-30 16:39:04 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:39:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:39:08 +03:00 --- debug: Database Library initialized
2013-08-30 16:39:08 +03:00 --- debug: Session Library initialized
2013-08-30 16:39:08 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:08 +03:00 --- error: Missing i18n entry core.page_not_found for language uk_UA
2013-08-30 16:39:08 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 16:39:08 +03:00 --- error: core.uncaught_exception
2013-08-30 16:39:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:39:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:39:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:39:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:39:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:39:08 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:39:08 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 16:39:08 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 16:39:08 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:39:08 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:39:08 +03:00 --- debug: Database Library initialized
2013-08-30 16:39:08 +03:00 --- debug: Session Library initialized
2013-08-30 16:39:08 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:39:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:39:10 +03:00 --- debug: Database Library initialized
2013-08-30 16:39:10 +03:00 --- debug: Session Library initialized
2013-08-30 16:39:10 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:39:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:39:15 +03:00 --- debug: Database Library initialized
2013-08-30 16:39:15 +03:00 --- debug: Session Library initialized
2013-08-30 16:39:15 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:39:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:39:20 +03:00 --- debug: Database Library initialized
2013-08-30 16:39:20 +03:00 --- debug: Session Library initialized
2013-08-30 16:39:20 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:39:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:39:24 +03:00 --- debug: Database Library initialized
2013-08-30 16:39:24 +03:00 --- debug: Session Library initialized
2013-08-30 16:39:24 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:39:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:39:30 +03:00 --- debug: Database Library initialized
2013-08-30 16:39:30 +03:00 --- debug: Session Library initialized
2013-08-30 16:39:30 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:30 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:39:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:39:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:39:30 +03:00 --- debug: Database Library initialized
2013-08-30 16:39:30 +03:00 --- debug: Session Library initialized
2013-08-30 16:39:30 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:30 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:39:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:39:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:39:45 +03:00 --- debug: Database Library initialized
2013-08-30 16:39:45 +03:00 --- debug: Session Library initialized
2013-08-30 16:39:45 +03:00 --- debug: Auth Library loaded
2013-08-30 16:39:45 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:40:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:40:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:40:15 +03:00 --- debug: Database Library initialized
2013-08-30 16:40:15 +03:00 --- debug: Session Library initialized
2013-08-30 16:40:15 +03:00 --- debug: Auth Library loaded
2013-08-30 16:40:15 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:40:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:40:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:40:15 +03:00 --- debug: Database Library initialized
2013-08-30 16:40:15 +03:00 --- debug: Session Library initialized
2013-08-30 16:40:15 +03:00 --- debug: Auth Library loaded
2013-08-30 16:40:15 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:40:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:40:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:40:33 +03:00 --- debug: Database Library initialized
2013-08-30 16:40:33 +03:00 --- debug: Session Library initialized
2013-08-30 16:40:33 +03:00 --- debug: Auth Library loaded
2013-08-30 16:40:33 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:40:33 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:40:33 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:40:33 +03:00 --- debug: Database Library initialized
2013-08-30 16:40:33 +03:00 --- debug: Session Library initialized
2013-08-30 16:40:33 +03:00 --- debug: Auth Library loaded
2013-08-30 16:40:33 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:40:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:40:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:40:42 +03:00 --- debug: Database Library initialized
2013-08-30 16:40:42 +03:00 --- debug: Session Library initialized
2013-08-30 16:40:42 +03:00 --- debug: Auth Library loaded
2013-08-30 16:40:42 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:40:42 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:40:42 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:40:42 +03:00 --- debug: Database Library initialized
2013-08-30 16:40:42 +03:00 --- debug: Session Library initialized
2013-08-30 16:40:42 +03:00 --- debug: Auth Library loaded
2013-08-30 16:40:42 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:41:34 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:41:34 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:41:34 +03:00 --- debug: Database Library initialized
2013-08-30 16:41:34 +03:00 --- debug: Session Library initialized
2013-08-30 16:41:34 +03:00 --- debug: Auth Library loaded
2013-08-30 16:41:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:41:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:41:39 +03:00 --- debug: Database Library initialized
2013-08-30 16:41:39 +03:00 --- debug: Session Library initialized
2013-08-30 16:41:39 +03:00 --- debug: Auth Library loaded
2013-08-30 16:41:39 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:41:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:41:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:41:40 +03:00 --- debug: Database Library initialized
2013-08-30 16:41:40 +03:00 --- debug: Session Library initialized
2013-08-30 16:41:40 +03:00 --- debug: Auth Library loaded
2013-08-30 16:41:40 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:41:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:41:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:41:43 +03:00 --- debug: Database Library initialized
2013-08-30 16:41:43 +03:00 --- debug: Session Library initialized
2013-08-30 16:41:43 +03:00 --- debug: Auth Library loaded
2013-08-30 16:41:43 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:41:43 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:41:43 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:41:43 +03:00 --- debug: Database Library initialized
2013-08-30 16:41:43 +03:00 --- debug: Session Library initialized
2013-08-30 16:41:43 +03:00 --- debug: Auth Library loaded
2013-08-30 16:41:43 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:42:07 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:42:07 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:42:07 +03:00 --- debug: Database Library initialized
2013-08-30 16:42:07 +03:00 --- debug: Session Library initialized
2013-08-30 16:42:07 +03:00 --- debug: Auth Library loaded
2013-08-30 16:42:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:42:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:42:10 +03:00 --- debug: Database Library initialized
2013-08-30 16:42:10 +03:00 --- debug: Session Library initialized
2013-08-30 16:42:10 +03:00 --- debug: Auth Library loaded
2013-08-30 16:42:10 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:42:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:42:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:42:10 +03:00 --- debug: Database Library initialized
2013-08-30 16:42:10 +03:00 --- debug: Session Library initialized
2013-08-30 16:42:10 +03:00 --- debug: Auth Library loaded
2013-08-30 16:42:10 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:42:21 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:42:21 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:42:21 +03:00 --- debug: Database Library initialized
2013-08-30 16:42:21 +03:00 --- debug: Session Library initialized
2013-08-30 16:42:21 +03:00 --- debug: Auth Library loaded
2013-08-30 16:42:21 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:43:05 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:43:05 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:43:05 +03:00 --- debug: Database Library initialized
2013-08-30 16:43:05 +03:00 --- debug: Session Library initialized
2013-08-30 16:43:05 +03:00 --- debug: Auth Library loaded
2013-08-30 16:43:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:43:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:43:06 +03:00 --- debug: Database Library initialized
2013-08-30 16:43:06 +03:00 --- debug: Session Library initialized
2013-08-30 16:43:06 +03:00 --- debug: Auth Library loaded
2013-08-30 16:43:06 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:43:06 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:43:06 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:43:06 +03:00 --- debug: Database Library initialized
2013-08-30 16:43:06 +03:00 --- debug: Session Library initialized
2013-08-30 16:43:06 +03:00 --- debug: Auth Library loaded
2013-08-30 16:43:06 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:43:15 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:43:15 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:43:15 +03:00 --- debug: Database Library initialized
2013-08-30 16:43:15 +03:00 --- debug: Session Library initialized
2013-08-30 16:43:15 +03:00 --- debug: Auth Library loaded
2013-08-30 16:43:15 +03:00 --- debug: Captcha Library initialized
2013-08-30 16:43:20 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:43:20 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:43:20 +03:00 --- debug: Database Library initialized
2013-08-30 16:43:20 +03:00 --- debug: Session Library initialized
2013-08-30 16:43:20 +03:00 --- debug: Auth Library loaded
2013-08-30 16:43:45 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:43:45 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:43:45 +03:00 --- debug: Database Library initialized
2013-08-30 16:43:45 +03:00 --- debug: Session Library initialized
2013-08-30 16:43:45 +03:00 --- debug: Auth Library loaded
2013-08-30 16:43:50 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:43:50 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:43:50 +03:00 --- debug: Database Library initialized
2013-08-30 16:43:50 +03:00 --- debug: Session Library initialized
2013-08-30 16:43:50 +03:00 --- debug: Auth Library loaded
2013-08-30 16:43:59 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:43:59 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:43:59 +03:00 --- debug: Database Library initialized
2013-08-30 16:43:59 +03:00 --- debug: Session Library initialized
2013-08-30 16:43:59 +03:00 --- debug: Auth Library loaded
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.uncaught_exception for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: core.uncaught_exception
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry errors.4096 for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.error_file_line for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.stack_trace for language uk_UA
2013-08-30 16:44:00 +03:00 --- error: Missing i18n entry core.stats_footer for language uk_UA
2013-08-30 16:45:24 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:45:24 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:45:24 +03:00 --- debug: Database Library initialized
2013-08-30 16:45:24 +03:00 --- debug: Session Library initialized
2013-08-30 16:45:24 +03:00 --- debug: Auth Library loaded
2013-08-30 16:45:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:45:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:45:28 +03:00 --- debug: Database Library initialized
2013-08-30 16:45:28 +03:00 --- debug: Session Library initialized
2013-08-30 16:45:28 +03:00 --- debug: Auth Library loaded
2013-08-30 16:45:28 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:45:28 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:45:28 +03:00 --- debug: Database Library initialized
2013-08-30 16:45:28 +03:00 --- debug: Session Library initialized
2013-08-30 16:45:28 +03:00 --- debug: Auth Library loaded
2013-08-30 16:45:39 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:45:39 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:45:39 +03:00 --- debug: Database Library initialized
2013-08-30 16:45:39 +03:00 --- debug: Session Library initialized
2013-08-30 16:45:39 +03:00 --- debug: Auth Library loaded
2013-08-30 16:45:47 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:45:47 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:45:47 +03:00 --- debug: Database Library initialized
2013-08-30 16:45:47 +03:00 --- debug: Session Library initialized
2013-08-30 16:45:47 +03:00 --- debug: Auth Library loaded
2013-08-30 16:45:57 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:45:57 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:45:57 +03:00 --- debug: Database Library initialized
2013-08-30 16:45:57 +03:00 --- debug: Session Library initialized
2013-08-30 16:45:57 +03:00 --- debug: Auth Library loaded
2013-08-30 16:46:10 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:46:10 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:46:10 +03:00 --- debug: Database Library initialized
2013-08-30 16:46:10 +03:00 --- debug: Session Library initialized
2013-08-30 16:46:10 +03:00 --- debug: Auth Library loaded
2013-08-30 16:46:54 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:46:54 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:46:54 +03:00 --- debug: Database Library initialized
2013-08-30 16:46:54 +03:00 --- debug: Session Library initialized
2013-08-30 16:46:54 +03:00 --- debug: Auth Library loaded
2013-08-30 16:47:30 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:47:30 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:47:30 +03:00 --- debug: Database Library initialized
2013-08-30 16:47:30 +03:00 --- debug: Session Library initialized
2013-08-30 16:47:30 +03:00 --- debug: Auth Library loaded
2013-08-30 16:47:35 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:47:35 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:47:35 +03:00 --- debug: Database Library initialized
2013-08-30 16:47:35 +03:00 --- debug: Session Library initialized
2013-08-30 16:47:35 +03:00 --- debug: Auth Library loaded
2013-08-30 16:47:38 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:47:38 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:47:38 +03:00 --- debug: Database Library initialized
2013-08-30 16:47:38 +03:00 --- debug: Session Library initialized
2013-08-30 16:47:38 +03:00 --- debug: Auth Library loaded
2013-08-30 16:47:55 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:47:55 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:47:55 +03:00 --- debug: Database Library initialized
2013-08-30 16:47:55 +03:00 --- debug: Session Library initialized
2013-08-30 16:47:55 +03:00 --- debug: Auth Library loaded
2013-08-30 16:48:12 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:48:12 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:48:12 +03:00 --- debug: Database Library initialized
2013-08-30 16:48:12 +03:00 --- debug: Session Library initialized
2013-08-30 16:48:12 +03:00 --- debug: Auth Library loaded
2013-08-30 16:48:40 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:48:40 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:48:40 +03:00 --- debug: Database Library initialized
2013-08-30 16:48:41 +03:00 --- debug: Session Library initialized
2013-08-30 16:48:41 +03:00 --- debug: Auth Library loaded
2013-08-30 16:48:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:48:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:48:41 +03:00 --- debug: Database Library initialized
2013-08-30 16:48:41 +03:00 --- debug: Session Library initialized
2013-08-30 16:48:41 +03:00 --- debug: Auth Library loaded
2013-08-30 16:48:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:48:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:48:41 +03:00 --- debug: Database Library initialized
2013-08-30 16:48:41 +03:00 --- debug: Session Library initialized
2013-08-30 16:48:41 +03:00 --- debug: Auth Library loaded
2013-08-30 16:48:41 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:48:41 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:48:41 +03:00 --- debug: Database Library initialized
2013-08-30 16:48:41 +03:00 --- debug: Session Library initialized
2013-08-30 16:48:41 +03:00 --- debug: Auth Library loaded
2013-08-30 16:48:44 +03:00 --- debug: Global GET, POST and COOKIE data sanitized
2013-08-30 16:48:44 +03:00 --- debug: MySQL Database Driver Initialized
2013-08-30 16:48:44 +03:00 --- debug: Database Library initialized
2013-08-30 16:48:44 +03:00 --- debug: Session Library initialized
2013-08-30 16:48:44 +03:00 --- debug: Auth Library loaded
