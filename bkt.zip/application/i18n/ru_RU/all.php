<?php 


	$lang = array(
	
		"fio" 		=> "Ф.И.О.",
		"phone" 	=> "Контактный телефон",
		"sale_code" => "Код на скидку(если знаете)",
		"course"	=> "Курс",
		"courses"	=> "Курсы",
		"group" 	=> "Груповой",
		"goup" 		=> "Группа",
		"name"      => "Имя",
		"discount_imposible" => "Данный купон уже использован.",
		"reg_complite" => "Спасибо за обращение ,в ближайшее время с Вами свяжутся.",
		"discount_imposible_cupon_bad" => "Данный купон не действительный.",
		"discount_posible" => "Выполучили скидку в размере:",
		"menu_1" => "Учебные курсы",
		"menu_2" => "Онлайн запись",
		"menu_3" => "Отзывы",
		"menu_header" => "НАПРАВЛЕНИЯ ОБУЧЕНИЯ",
		"Naiblyzhchi_hrupy" => "Ближайшие группы",
		"address" => "Наш адресс",
		"where_it" => "где это?",
		"_address" => "г. Львов,<br>ул. Т. Костюшка 18",
		"_address_" => "Львов, ул. Т. Костюшка 18",
		"vdosk_znannya" => "Вдоскональте свої знання разом з нами!",
		"po4_zan" => "Начало",
		"4as_zan" => "Время",
		"days" => "Дни",
		"k_t_ludey" => "Людей",
		"captcha" => "Код с картинки",
		"captha_reload" => "Обновить",
		"zap_na_kurs" => "Записаться на курс",
		"send" => "Написать", 
		"do_send" => "Отправить",
		"thanks_text" => "Будем благодарны за Ваше мнение",
		"_groups_skoro" => "Ближайшие группы",
		"zapus" => "Запись",
		"price" => "Цена",
		"course_program" => "Программа курса",
		"truv_cursu" => "Продолжительность курса ",
		"ak_god" => " ак. час.",
		"vart_ind_course" => "Стоимость индивидуального курса ",
		"ind_zapus" => "Запись на индивидуальный курс",
		"program" => "Программа",
		"__price" => "Стоимость",
		"rozklad" => "Рассписание",
		"pidgotovka" => "Подготовка",
		"vkaz_nom_tel" => "Укажите Ваш номер телефона и имя, Мы к вам перезвоним",
		"send_comment" => "Комментировать",



		"ind_desc" => "Также Вы можете заниматься по индивидуальной программе, или сформировать свою собственную группу для обучения, за подробной информацией обращайтесь к нашим менеджерам.",
"pidg" => "Требуемая подготовка",
		"ind_course" => "Индивидуальные занятия",
		"ind_course_count" => "Базовый курс, к-во ак. часов",
		"price_uah" => "Цена грн.",
		"price_uah_for_1" => "(стоимость курса за одного человека)",

		"group_lessons" => "Гроповые занятия  <br>(до 8 людей в групе)",
		"people_count" => "(к-во.чел. в груп.)",
		
		"" => "",





	"get_call_back_" => '<div class="sh_help_button_text">C</div>
			<div class="sh_help_button_text">A</div>
			<div class="sh_help_button_text">L</div>
			<div class="sh_help_button_text">L</div>
			<div class="sh_help_button_text"></div>
			<div class="sh_help_button_text">B</div>
			<div class="sh_help_button_text">A</div>
			<div class="sh_help_button_text">C</div>
			<div class="sh_help_button_text">K</div>'
	
	);
?>