<?php



$config['kcaptcha'] = array(
	"style"		=> "kcaptcha",
	"alphabet"	=> "0123456789abcdefghijklmnopqrstuvwxyz",
	"allowed_symbols"	=> "23456789abcdeghkmnpqsuvxyz",
	"fontsdir"	=> SYSPATH."fonts",
	"length" => mt_rand(5,6),
	"width" => 120,
	"height" => 60,
	"fluctuation_amplitude" => 5,
	"no_spaces" => true,
	"foreground_color" => array(mt_rand(0,100), mt_rand(0,100), mt_rand(0,100)),
	"background_color" => array(mt_rand(200,255), mt_rand(200,255), mt_rand(200,255)),
	"jpeg_quality" => 90

);

$config['default_driver'] = 'kcaptcha';