<?php

$config['top'] = 100;
$config['start_font_size'] = 10;
$config['end_font_size'] = 36;
$config['size_lifetime'] = 3400000;

$config['top_addevent_tags'] = 10;
$config['top_addevent_lifetime'] = 350000;

$config['user_max_tags'] = 50;