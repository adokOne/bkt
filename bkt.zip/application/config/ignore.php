<?php
    $config['ignore_uri'] = array(
    );
?>